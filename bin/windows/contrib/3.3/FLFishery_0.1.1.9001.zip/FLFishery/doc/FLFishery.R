## ---- setup, echo=FALSE, results='hide', message=FALSE----
library(knitr)
opts_chunk$set(dev='png', cache=TRUE, fig.width=4.5, fig.height=4.5, tidy=TRUE)
options(width=50)

## ---- load, echo=FALSE, results='hide', message=FALSE----
library(FLFishery)

## ---- devtools, echo=TRUE, eval=FALSE-----------
#  	library(devtools)
#  	install_github('iagomosqueira/FLFishery')

## ----setupf, ref.label='setup', echo=2, eval=FALSE----
#  library(knitr)
#  opts_chunk$set(dev='png', cache=TRUE, fig.width=4.5, fig.height=4.5, tidy=TRUE)
#  options(width=50)

