## ---- pkgs, echo=FALSE, message=FALSE, warnings=FALSE-----
library(FLasher)
library(ggplotFL)
library(knitr)
opts_chunk$set(dev='png', cache=FALSE, fig.width=4, fig.height=4, tidy=TRUE, dpi=72)
options(width=60)

## ---- eval=FALSE------------------------------------------
#  # Will not work
#  out <- fwd(stock, control, sr=srrbits, sr.residuals=residuals)
#  # Will work
#  out <- fwd(stock, control=control, sr=srrbits, deviances=deviances)

