## ---- pkgs, echo=FALSE, message=FALSE-----------------------------------------
library(knitr)
opts_chunk$set(echo=FALSE, message=FALSE, warning=FALSE,
  fig.width=5, fig.height=4.5)

## ---- eval=FALSE--------------------------------------------------------------
#  install.packages("ss3om", repos=structure(c(CRAN="https://cloud.r-project.org/",
#    FLR="https://flr-project.org/R")))

## ---- eval=FALSE--------------------------------------------------------------
#  remotes::install_github("r4ss/r4ss")
#  remotes::install_github("flr/ss3om")

## ----loadpkg------------------------------------------------------------------
library(ss3om)

## ----setpwd-------------------------------------------------------------------
dir <- system.file("ext-data/herring", package="ss3om")

## ----readfls------------------------------------------------------------------
albio <- readFLSss3(dir, name="HER")
range(albio) <- c(minfbar=3, maxfbar=7)

plot(albio)

