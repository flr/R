### Name: FLSTF.control-class
### Title: Class FLSTF.control for use as a control object for class FLSTF
### Aliases: FLSTF.control FLSTF.control-class show,FLSTF.control-method
### Keywords: classes

### ** Examples

# Create a control object with only default values:
c <- FLSTF.control()

# Create a control object with specified recruitment:
c <- FLSTF.control(rec = c(500000,450000,300000))

# Create a control object with a different range for selection pattern calculation and a catch constraint:
c <- FLSTF.control(fbar.min=4, fbar.max=8, catch.constraint = 50000)



