### Name: flc2flq-methods
### Title: Coerce "FLCohort" to "FLQuant"
### Aliases: flc2flq-methods flc2flq flc2flq,FLCohort-method
### Keywords: methods

### ** Examples

data(ple4)
flc <- FLCohort(catch.n(ple4))
flq <- flc2flq(flc)
all.equal(flq, catch.n(ple4))



