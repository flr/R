### Name: splom-method
### Title: Splom plots for FLQuants and FLCohorts
### Aliases: splom-method splom,formula-method splom,formula,FLQuant-method
###   splom,formula,FLCohort-method
### Keywords: methods

### ** Examples

data(ple4)
# fine tune plot
ttl <- list("BTS age pairwise plot for plaice in IV", cex=1)
xttl <- list("age", cex=0.8)
yttl <- list("age", cex=0.8)
# panel function
pfun <- function(x,y,...){
          panel.splom(x,y, ...)
          panel.lmline(x,y, lty=1)
        }
# plot
splom(~data, data=catch.n(ple4), panel=pfun, pscales=0, main=ttl,
      xlab=xttl, ylab=yttl, pch=19, cex=0.3)
 



