### Name: nay-class
### Title: Class "nay" for normalisation at age per year
### Aliases: nay-class nay nay-methods nay,FLQuant-method
### Keywords: classes

### ** Examples

data(ple4sex)
# compute catch proportions at age
ple4sex.nay <- nay(ple4sex@catch.n)
# fine tune 
ttl <- list(label="Catch proportion at age for Plaice in IV", cex=1)
yttl <- list(label="age", cex=0.8)
xttl <- list(cex=0.8)
ax <- list(cex=0.7)
# plot
bubbles(age~year|unit, ple4sex.nay,  main=ttl, ylab=yttl, xlab=xttl, scales=ax)



