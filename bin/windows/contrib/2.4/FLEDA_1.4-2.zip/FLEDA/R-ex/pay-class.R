### Name: pay-class
### Title: Class "pay" for proportion at age per year
### Aliases: pay-class pay pay-methods pay,FLQuant-method
### Keywords: classes

### ** Examples

data(ple4sex)
# compute catch proportions at age
ple4sex.pay <- pay(ple4sex@catch.n)
# fine tune 
ttl <- list(label="Catch proportion at age for Plaice in IV", cex=1)
yttl <- list(label="age", cex=0.8)
xttl <- list(cex=0.8)
ax <- list(cex=0.7)
# plot
bubbles(age~year|unit, ple4sex.pay,  main=ttl, 
        ylab=yttl, xlab=xttl, scales=ax)



