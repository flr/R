### Name: read.FLIndices
### Title: Import FLIndices data from a file
### Aliases: read.FLIndices read.FLIndex
### Keywords: IO

### ** Examples
## Not run: 
##D ## Supposing you have a VPA suite data in youe working directory
##D ## and indices datasets are in the file 'fleet', then:
##D 
##D # my.indices <- read.Indices("fleet")
##D 
##D ## should import these data into an FLIndices object
## End(Not run)


