### Name: write.FLStock
### Title: Write FLStock data to a file
### Aliases: write.FLStock
### Keywords: IO

### ** Examples

## If the variable 'my.stk' contains an FLStock object, then

# write.FLStock(my.stk, file="c:/mydata/index")

## creates a VPA SUITE series a files containing stock data from 'my.stk'



