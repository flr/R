### Name: sr
### Title: Stock-recruitment model function
### Aliases: sr ricker bevholt segreg qhstk
### Keywords: models

### ** Examples




