### Name: setPlusGroup
### Title: setPlusgroup for FLStock
### Aliases: setPlusGroup
### Keywords: manip

### ** Examples




