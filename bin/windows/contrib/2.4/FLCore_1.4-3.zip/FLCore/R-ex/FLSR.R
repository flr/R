### Name: FLSR
### Title: FLSR
### Aliases: FLSR FLSR-methods
### Keywords: classes methods

### ** Examples


    flsr <- FLSR()
    flsr <- FLSR(name = "Hake", desc = "An empty 'FLSR' object")

    data(ple4)
    ssb <- ssb(ple4)
    rec <- stock.n(ple4)[1,]

    flsr <- FLSR(name = "Plaice", desc = "Plaice in area IV, data obtained from 'ple4' 'FLSTock' object",
        ssb = ssb)
    flsr <- FLSR(name = "Plaice", desc = "Plaice in area IV, data obtained from 'ple4' 'FLSTock' object",
        ssb = ssb, rec = rec)
    flsr <- FLSR(name = "Plaice", desc = "Plaice in area IV, data obtained from 'ple4' 'FLSTock' object",
        model = "ricker", params = matrix(c(3.7, 3.3e-6,NA),1))



