### Name: FLQuant
### Title: FLQuant class and methods
### Aliases: FLQuant-class show,FLQuant-method [,FLQuant-method
###   [<-,FLQuant-method summary,FLQuant-method quant,FLQuant-method
###   quant<-,FLQuant-method plot,FLQuant,missing-method
###   names,FLQuant-method dimnames<-,FLQuant-method trim,FLQuant-method
###   catch,FLQuant-method tofrm,FLQuant-method discards,FLQuant-method
###   landings,FLQuant-method apply,FLQuant,ANY,ANY-method
###   as.data.frame,FLQuant,ANY,ANY-method
### Keywords: classes methods

### ** Examples

# Generate an array containing random numbers, and convert it into an FLQuant
sq <- FLQuant(array(rnorm(120, mean=2), dim=c(20,3,2,1,1),
      dimnames=list(age=as.character(1:20), 
                    year=c("1999", "2000", "2001"), 
                    unit=c("male", "female"), 
                    season="all", area="all")), units="Tons")
summary(sq)
show(sq)
dims(sq)
names(sq)
sq <- sq[1:12,,1]



