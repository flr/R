### Name: units
### Title: Extract and modify the units slot of an object
### Aliases: units units<- units-methods "units<-"-methods
###   units,FLQuant-method units<-,FLQuant,character-method
###   units,FLStock-method units<-,FLStock,list-method
### Keywords: methods

### ** Examples

    flq <- FLQuant()
    units(flq)
    units(flq) <- "kg"

    data(ple4)
    units(ple4)
    units(ple4) <- list(harvest="f")

    my.FLStock <- FLStock()
    units(my.FLStock) <- units(ple4)




