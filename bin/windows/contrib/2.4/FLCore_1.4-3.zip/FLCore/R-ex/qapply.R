### Name: qapply
### Title: Apply a Function over the FLQuant slots of an FLR S4 object
### Aliases: qapply
### Keywords: methods

### ** Examples

fli <- FLIndex(index=FLQuant(rnorm(30), dim=c(3,10)))
summary(qapply(fli, window, start=3, end=5))
is.list(qapply(fli, quant))



