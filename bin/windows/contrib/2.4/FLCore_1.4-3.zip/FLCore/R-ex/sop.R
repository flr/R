### Name: sop
### Title: Calculates the sum of products correction
### Aliases: sop
### Keywords: methods

### ** Examples

data(ple4)
sop(ple4,"catch")



