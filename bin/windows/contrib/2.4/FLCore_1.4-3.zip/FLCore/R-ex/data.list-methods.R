### Name: data.list-methods
### Title: Creates data.frame with list of values
### Aliases: data.list-methods data.list data.list,FLQuants-method
###   data.list,list-method
### Keywords: methods

### ** Examples

data(ple4)
flqs <- FLQuants(list(catch.n(ple4), landings.n(ple4), discards.n(ple4)))
data.list(flqs)



