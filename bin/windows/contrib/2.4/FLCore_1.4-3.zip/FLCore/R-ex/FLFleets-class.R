### Name: FLFleets-class
### Title: Class FLFleets
### Aliases: FLFleets FLFleets-class summary,FLFleets-method
###   as.FLStock,FLFleets-method
### Keywords: classes methods

### ** Examples

    # Create an empty FLFleet object from two empty FLFleet obejects.
   iniFLQuantCatch = FLQuant(160, dim = c(8,20,1,1,1))
   iniFLQuant = FLQuant(10, dim = c(1,20,1,1,1))
   my.fleets <-FLFleets() 
   my.fleets[[1]] <- FLFleet(iniFLQuantCatch=iniFLQuantCatch, iniFLQuant=iniFLQuant, name = "Otter trawl", desc = "Just an example...")
   my.fleets[[2]] <- FLFleet(iniFLQuantCatch=iniFLQuantCatch, iniFLQuant=iniFLQuant, name = "Trawl", desc = "Just an example...")

   is.FLFleets(my.fleets)



