### Name: is.FLIndices
### Title: FLIndices
### Aliases: is.FLIndices
### Keywords: classes manip

### ** Examples




