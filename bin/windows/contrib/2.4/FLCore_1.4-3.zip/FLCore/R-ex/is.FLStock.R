### Name: is.FLStock
### Title: FLStock
### Aliases: is.FLStock
### Keywords: classes manip

### ** Examples
## Not run: 
##D     data(ple4)
##D     is.FLStock(ple4)
## End(Not run)



