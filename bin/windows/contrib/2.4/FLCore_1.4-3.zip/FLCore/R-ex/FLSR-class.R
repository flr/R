### Name: FLSR-class
### Title: Class FLSR
### Aliases: FLSR-class plot,FLSR,missing-method predict,FLSR-method
###   summary,FLSR-method params,FLSR-method params<-,FLSR-method
###   params<-,FLSR,vector-method params<-,FLSR,matrix-method
###   name,FLSR-method name<-,FLSR,character-method desc,FLSR-method
###   desc<-,FLSR,character-method model,FLSR-method
###   model<-,FLSR,character-method ssb,FLSR-method
###   ssb<-,FLSR,FLQuant-method rec,FLSR-method rec<-,FLSR,FLQuant-method
###   rechat,FLSR-method rechat<-,FLSR,FLQuant-method residuals,FLSR-method
###   residuals<-,FLSR,FLQuant-method params,FLSR-method
###   params<-,FLSR,matrix-method se,FLSR-method se<-,FLSR,numeric-method
###   covar,FLSR-method covar<-,FLSR,matrix-method
###   var,FLSR,missing,missing,missing-method var<- "var<-"-methods
###   var<-,FLSR,numeric-method varacorr,FLSR-method
###   varacorr<-,FLSR,numeric-method aic,FLSR-method
###   aic<-,FLSR,numeric-method mcmc,FLSR-method mcmc<-,FLSR,list-method
###   qapply,FLSR,function-method
### Keywords: classes methods

### ** Examples

    data(ple4)

    fsr <- as.FLSR(ple4, model = "ricker")
    fsr <- sr(fsr)
    plot(fsr)
    params(fsr)




