### Name: FLCore lattice-methods
### Title: FLCore lattice methods
### Aliases: xyplot,formula,FLQuant-method xyplot,formula,FLQuants-method
###   bwplot,formula,FLQuant-method dotplot,formula,FLQuant-method
###   barchart,formula,FLQuant-method stripplot,formula,FLQuant-method
###   histogram,formula,FLQuant-method
### Keywords: methods

### ** Examples

data(ple4sex)
# plot the ages per year for males
xyplot(data~age|year, data=trim(ple4sex@catch.n, unit="male"), type="b")
# use boxplots to explore the variability along the years
bwplot(data~age|unit, data=ple4sex@catch.n)
# or just take a look at all results
dotplot(data~age|unit, data=ple4sex@catch.n)
# plot the age frequencies per year for males
barchart(data~age|year, data=trim(ple4sex@catch.n, unit="male"))
# or compare the last 10 years per sex
barchart(data~age|year*unit, data=trim(ple4sex@catch.n, year=1990:2000))
# be carefull with what you do with histogram ...
# probably it makes sense for simulation situations ...
histogram(~data|year, data=ple4sex@catch.n)



