### Name: FLCatch-class
### Title: Class FLCatch
### Aliases: FLCatch-class FLCatch summary,FLCatch-method
###   plot,FLCatch,missing-method transform,FLCatch-method
###   computeCatch,FLCatch-method computeLandings,FLCatch-method
###   computeDiscards,FLCatch-method name,FLCatch-method
###   name<-,FLCatch,character-method gear,FLCatch-method
###   gear<-,FLCatch,character-method range,FLCatch-method
###   range<-,FLCatch,numeric-method catch,FLCatch-method
###   catch<-,FLCatch,FLQuant-method catch.n,FLCatch-method
###   catch.n<-,FLCatch,FLQuant-method catch.wt,FLCatch-method
###   catch.wt<-,FLCatch,FLQuant-method catch.sel,FLCatch-method
###   catch.sel<-,FLCatch,FLQuant-method landings,FLCatch-method
###   landings<-,FLCatch,FLQuant-method landings.n,FLCatch-method
###   landings.n<-,FLCatch,FLQuant-method landings.wt,FLCatch-method
###   landings.wt<-,FLCatch,FLQuant-method landings.sel,FLCatch-method
###   landings.sel<-,FLCatch,FLQuant-method discards,FLCatch-method
###   discards<-,FLCatch,FLQuant-method discards.n,FLCatch-method
###   discards.n<-,FLCatch,FLQuant-method discards.wt,FLCatch-method
###   discards.wt<-,FLCatch,FLQuant-method discards.sel,FLCatch-method
###   discards.sel<-,FLCatch,FLQuant-method catchability,FLCatch-method
###   catchability<-,FLCatch,FLQuant-method price,FLCatch-method
###   price<-,FLCatch,FLQuant-method
### Keywords: classes methods

### ** Examples




