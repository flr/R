### Name: createFLAccesors
### Title: Create accesor and replecement methods for slots of complex
###   classes
### Aliases: createFLAccesors
### Keywords: methods utilities

### ** Examples

        ## Not run: 
##D         setClass("example", representation(name="character", quantity="vector"))
##D         ex <- new("example", name="example", quantity=rnorm(10))
##D         createFLAccesors(ex)
##D         quantity(ex)
##D         name(ex) <- 'Modified example'
##D         name(ex)
##D         
## End(Not run)



