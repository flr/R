### Name: tofrm
### Title: Method for generating fromulas from FLQuant objects.
### Aliases: tofrm tofrm-methods
### Keywords: methods

### ** Examples

# load ple4
data(ple4)
tofrm(catch.n(ple4))




