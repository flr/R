### Name: as.FLFleet
### Title: as.FLFleet method
### Aliases: as.FLFleet as.FLFleet-method as.FLFleet,FLStock-method
### Keywords: methods manip

### ** Examples




