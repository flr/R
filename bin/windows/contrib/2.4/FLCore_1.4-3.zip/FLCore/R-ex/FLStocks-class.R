### Name: FLStocks-class
### Title: Class FLStocks
### Aliases: FLStocks FLStocks-class summary,FLStocks-method
### Keywords: classes

### ** Examples

    # Create a new empty stock, giving a name and desc.
    my.ple <- FLStock(name = "plaice", desc = "Just an example...")
    summary(my.ple)
    
    # Create an FLStock with the same dimensions as the FLQuant object catch.
    catch <- FLQuant(array(round(rnorm(120, 5000,500)), dim=c(12,10,1,1,1),
              dimnames=list(age=as.character(1:12), year=as.character(c(1991:2000)),
              unit="all", season="all", area="all")))
    my.stock <- FLStock(name = "My Stock", desc = "Just an example...", iniFLQuant=catch)
    my.stock@catch <- catch
    
    # Colletc both stocks together.
    my.stocks <- FLStocks(my.ple, my.stock)



