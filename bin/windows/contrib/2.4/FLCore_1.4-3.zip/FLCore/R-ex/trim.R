### Name: trim
### Title: Method for trimming FLQuant objects.
### Aliases: trim trim-methods
### Keywords: methods

### ** Examples

# load ple4
data(ple4)
# subset catches
trim(ple4@catch.n, age=2:7, year=1970:1980)
# now with unit dimension
example("FLQuant")
trim(sq, unit="female")



