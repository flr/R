### Name: is.FLStocks
### Title: FLStocks
### Aliases: is.FLStocks
### Keywords: classes manip

### ** Examples
## Not run: 
##D     data(ple4)
##D     fl <- FLStocks()
##D     fl[[1]] <- ple4
##D     is.FLStocks(fl)
## End(Not run)



