### Name: FLCore-package
### Title: Core package of FLR, fisheries modelling in R.
### Aliases: FLCore-package FLCore
### Keywords: package

### ** Examples




