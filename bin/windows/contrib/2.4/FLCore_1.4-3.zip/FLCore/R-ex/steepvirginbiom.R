### Name: steepvirginbiom
### Title: Change to steepness/virgin biomass parameterisation
### Aliases: steepvirginbiom
### Keywords: models

### ** Examples




