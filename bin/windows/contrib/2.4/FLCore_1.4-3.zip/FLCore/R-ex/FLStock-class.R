### Name: FLStock-class
### Title: Class FLStock for fish stock data and modelling output
### Aliases: FLStock FLStock-class plot,FLStock,missing-method
###   as.FLSR,FLStock-method trim,FLStock-method summary,FLStock-method
###   [,FLStock-method [<-,FLStock-method update,FLStock-method
###   catch,FLStock-method landings,FLStock-method discards,FLStock-method
###   units,FLStock,list-method transform,FLStock-method
###   as.data.frame,FLStock,ANY,ANY-method qapply,FLStock,function-method
###   ssb,FLStock-method name,FLStock-method desc,FLStock-method
###   range,FLStock-method catch,FLStock-method catch.n,FLStock-method
###   catch.wt,FLStock-method discards,FLStock-method
###   discards.n,FLStock-method discards.wt,FLStock-method
###   landings,FLStock-method landings.n,FLStock-method
###   landings.wt,FLStock-method stock,FLStock-method
###   stock.n,FLStock-method stock.wt,FLStock-method m,FLStock-method
###   mat,FLStock-method harvest,FLStock-method harvest.spwn,FLStock-method
###   ssbpurec,FLStock-method m.spwn,FLStock-method
###   name<-,FLStock,character-method desc<-,FLStock,character-method
###   range<-,FLStock,numeric-method catch<-,FLStock,FLQuant-method
###   catch<-,FLStock,FLQuants-method catch.n<-,FLStock,FLQuant-method
###   catch.wt<-,FLStock,FLQuant-method discards<-,FLStock,FLQuant-method
###   discards.n<-,FLStock,FLQuant-method
###   discards.wt<-,FLStock,FLQuant-method
###   landings<-,FLStock,FLQuant-method landings.n<-,FLStock,FLQuant-method
###   landings.wt<-,FLStock,FLQuant-method stock<-,FLStock,FLQuant-method
###   stock.n<-,FLStock,FLQuant-method stock.wt<-,FLStock,FLQuant-method
###   m<-,FLStock,FLQuant-method mat<-,FLStock,FLQuant-method
###   harvest<-,FLStock,FLQuant-method harvest<-,FLStock,character-method
###   harvest.spwn<-,FLStock,FLQuant-method m.spwn<-,FLStock,FLQuant-method
###   apply,FLStock,vector,function-method
###   harvest<-,FLStock,character-method
### Keywords: classes

### ** Examples

# Create a new empty stock, giving a name and desc.
my.ple <- FLStock(name = "plaice", desc = "Just an example...")
summary(my.ple)

# Create an FLStock with the same dimensions as the FLQuant object catch.
catch.n <- FLQuant(array(round(rnorm(120, 5000,500)), dim=c(12,10,1,1,1),
          dimnames=list(quant=as.character(1:12), year=as.character(c(1991:2000)),
          unit="all", season="all", area="all")))
my.stock <- FLStock(name = "My Stock", desc = "Just an example...", catch.n=catch.n)



