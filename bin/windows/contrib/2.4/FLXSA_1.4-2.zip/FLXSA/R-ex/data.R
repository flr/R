### Name: data
### Title: FLXSA data sets
### Aliases: cod4 cod4.indices cod4.stock cod4.xsa.control cod4.xsa.ref
###   her4 her4.indices her4.stock her4.xsa.control her4.xsa.ref ple7a
###   ple7a.indices ple7a.stock ple7a.xsa.control ple7a.xsa.ref
### Keywords: data

### ** Examples




