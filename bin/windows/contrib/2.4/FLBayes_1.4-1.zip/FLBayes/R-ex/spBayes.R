### Name: spBayes
### Title: A Bayesian Schaefer/Pella-Tomlinson surplus production model.
### Aliases: spBayes mclist.spBayes
### Keywords: models methods

### ** Examples
## Not run: 
##D data(alb)
##D mclist <- mclist.spBayes()
##D mclist$pinit[['Q']] <- 60
##D mclist$pinit[['r']] <- 0.5
##D mclist$pinit[['K']] <- 250
##D mclist$pinit[['sigmas']] <- 0.1
##D mclist$Q.mean <- 0
##D mclist$Q.var <- 100
##D mclist$K.mean <- log(250)
##D mclist$K.var <- 0.25
##D mclist$r.mean <- log(0.5)
##D mclist$r.var <- 0.1
##D mclist$sigma.shape <- 2
##D mclist$sigma.rate <- 1
##D mclist$nChains <- 1
##D mclist$nIter <- 10000
##D mclist$burnin <- 1000
##D mclist$thin <- 1
##D mclist$MCvar <- c(0.02,200)
##D sp.alb <- spBayes(alb$catch, alb$cpue, 0, 2, 1, mclist)
##D estimate(sp.alb)
##D sp.alb@parameters
## End(Not run)



