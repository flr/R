### Name: FLSP-class
### Title: Class FLSP
### Aliases: FLSP-class FLSP plot,FLSP,missing-method predict,FLSP-method
###   summary,FLSP-method
### Keywords: classes methods

### ** Examples




