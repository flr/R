### Name: bevholtBayes
### Title: Beverton and Holt stock-recruitment fit in a Bayesian setting
### Aliases: bevholtBayes
### Keywords: models methods

### ** Examples

## Not run: 
##D data(cod)
##D mclist <- list(pinit=list(S0init=70,hinit=0.8,siginit=0.25),S0.mean=4,S0.sd=.5,h.alpha=1,h.beta=1,sigma.shape=3,sigma.rate=1,nIter=1000,nChains=1,SSBperRec=3.118,MCvar=c(200,0.02),burnin=100,thin=1)
##D pla <- bevholtBayes(as.vector(cod$rec),as.vector(cod$ssb),mclist,plot=TRUE,conv=TRUE)
## End(Not run)



