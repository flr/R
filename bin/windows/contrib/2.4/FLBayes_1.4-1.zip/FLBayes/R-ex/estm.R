### Name: estm
### Title: Estimating (single-valued) natural mortality from mean life-span
### Aliases: estm
### Keywords: models methods

### ** Examples
## Not run: 
##D 
##D # expected life-span of 10 years
##D 
##D lbar <- 10
##D 
##D # initial guess (usually try 1/lbar)
##D 
##D minit <- 1/lbar
##D 
##D # call the function
##D 
##D m <- estm(lbar,minit)
## End(Not run)



