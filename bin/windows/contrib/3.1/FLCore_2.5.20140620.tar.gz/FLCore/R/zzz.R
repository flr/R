# zzz.R
# FLCore/R/zzz.R

# Copyright 2003-2008 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, JRC
# $Id: zzz.R 1635 2012-06-12 09:20:08Z imosqueira $


.onAttach <- function(lib,pkg) {
  packageStartupMessage("FLCore 2.5.0 development version\n", appendLF = TRUE)
#  cat("---------------------------------------------------------\n")
#  cat("* Note that FLR packages are under constant development,\n") 
#  cat("    please report bugs to flr-team@flr-project.org.\n")
#  cat("* For more information go to http:\\\\flr-project.org or\n")
#  cat("    subscribe the mailing list flr-list@flr-project.org.\n")
#  cat("---------------------------------------------------------\n")
}

# ac
ac <- function(x, ...)
  as.character(x, ...)

# an
an <- function(x, ...)
  as.numeric(x, ...)
