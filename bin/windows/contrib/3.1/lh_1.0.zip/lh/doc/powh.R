## ----initKnitr, echo=FALSE, results="asis"-------------------------------
library(knitr)

#output: rmarkdown::tufte_handout

# output:
#   rmdformats::html_clean:
#     fig_width: 6
#     fig_height: 6
#     highlight: pygments

## Global options
options(max.print="75")
opts_chunk$set(fig.path="out/",
               echo =TRUE,
               eval=TRUE,
               cache=!TRUE,
               cache.path="cache/",
               prompt=FALSE,
               tidy=FALSE,
               comment=NA,
               message=FALSE,
               warning=FALSE,
               fig.margin=TRUE, 
               fig.height=6, 
               fig.width=4)

opts_knit$set(width=75)

## ------------------------------------------------------------------------
library(lh)

## ------------------------------------------------------------------------
data(lhPel)
names(lhPel)

## ------------------------------------------------------------------------
data(bonLn)

## ------------------------------------------------------------------------
library(ggplot2)

## ----fig.cap="Length frequencies",fig.height=4---------------------------
ggplot(bonLn)+
  geom_histogram(aes(len,weight=n,fill=month))+
  scale_y_continuous(breaks=c(1))+
  theme_bw()+
  xlab("Length")+ylab("Proportion")

## ------------------------------------------------------------------------
rslt=with(bonLn, powh(len,n))

## ------------------------------------------------------------------------
rslt$params

## ----fig.height=4--------------------------------------------------------
ggplot(rslt$data)+
  geom_path(aes(len,diff),col="grey75")+
  geom_point(aes(len,diff),size=1)+
  geom_path(aes(len,hat),col="blue")+
  theme_bw()

## ------------------------------------------------------------------------
subset(lhPel,name=="Sarda sarda")[,c("name","linf","k")]

## ------------------------------------------------------------------------
rslt$params["zk"]*subset(lhPel,name=="Sarda sarda")[,"k"]

## ----eval=FALSE,echo=FALSE-----------------------------------------------
#  [^books_be]: http://www.edwardtufte.com/tufte/books_be
#  
#  # Sidenotes
#  
#  sidenote. ^[This is a sidenote that was entered using a footnote.]
#  
#  \marginnote{This is a margin note.  Notice that there isn't a number preceding the note.}
#  
#  Beverton, R. J. H., and S. J. Holt. "A review of methods for estimating mortality rates in exploited fish populations, with special reference to sources of bias in catch sampling." Rapp. P.-v. R??un. Ciem 140 (1956).

