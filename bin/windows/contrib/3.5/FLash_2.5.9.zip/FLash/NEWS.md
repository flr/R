# FLash 2.5.9

## USER-VISIBLE CHANGES

- FLash is now 64 bit, as the version of the AdolC library used to compile has been updated.
