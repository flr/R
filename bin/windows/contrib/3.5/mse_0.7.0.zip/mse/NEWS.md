# mse 0.0.4

## USER-VISIBLE CHANGES

- Methods moved to FLCore: rnoise, rlnoise

## BUG FIXES

## UTILITIES

## DOCUMENTATION

## DEPRECATED & DEFUNCT
