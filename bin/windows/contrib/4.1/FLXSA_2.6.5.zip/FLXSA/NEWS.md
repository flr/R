# FLXSA 2.6.1

## BUG FIXES

- units of slots vin FLXSA are now correct 

## USER-VISIBLE CHANGES

- FLXSA now compiles in both 32 and 64 bit R, for Linux and Windows
