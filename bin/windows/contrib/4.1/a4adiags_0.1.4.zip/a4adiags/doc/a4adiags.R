## ---- pkgs, echo=FALSE, message=FALSE-----------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")

## ----fit----------------------------------------------------------------------
library(a4adiags)
library(FLa4a)
data("sol274")

# fmodel, mimics AAP

fmod <- ~te(replace(age, age > 8, 8), year, k = c(4, 22)) +
  s(replace(age, age > 8, 8), k=4) +
  s(year, k=22, by=as.numeric(age==1))

# qmodel (GAM, SNS)

qmod <- list(~s(age, k=3), ~s(age, k=3))

# vmodel (catch, GAM, SNS)

vmod <- list(
  ~s(age, k=3),
  ~s(age, k=3),
  ~s(age, k=3))

# srmodel

srmod <- ~factor(year)

# fit

fit <- sca(stock, indices[c("BTS", "SNS")],
  srmodel=srmod, fmodel=fmod, qmodel=qmod, vmodel=vmod)

## ----parallel, eval=FALSE-----------------------------------------------------
#  library(doParallel)
#  ncores <- floor(detectCores() * .75)
#  
#  if(Sys.info()["sysname"] %in% c("Darwin", "Linux")) {
#    registerDoParallel(ncores)
#  } else if(Sys.info()["sysname"] %in% c("Windows")) {
#    cl <- makeCluster(ncores)
#    clusterEvalQ(cl = cl, expr = { library(FLa4a); library(FLasher) })
#    registerDoParallel(cl)
#  }

## ----xval---------------------------------------------------------------------
xval <- a4ahcxval(stock, indices, nyears=5, nsq=3, srmodel=srmod, fmodel=fmod,
  qmodel=qmod, vmodel=vmod)

## ----mase---------------------------------------------------------------------
mase(indices, xval$indices[-1])

## ----plotxval-----------------------------------------------------------------
plotXval(xval$indices)
plotXval(indices, xval$indices)
plotXval(indices, xval$indices[-1])
plotXval(xval$indices[["data"]], xval$indices[-1])
plotXval(xval$indices[["data"]], xval$indices)

## ----retro--------------------------------------------------------------------
plot(xval$stocks)
mohnMatrix(xval$stocks, ssb)
icesAdvice::mohn(mohnMatrix(xval$stocks, ssb))
icesAdvice::mohn(mohnMatrix(xval$stocks, fbar))

## ----runstest-----------------------------------------------------------------
plotRunstest(fit, indices)

## ----runstest_age-------------------------------------------------------------
plotRunstest(fit, indices, combine=FALSE)

## ---- devtools, echo=TRUE, eval=FALSE-----------------------------------------
#  	library(devtools)
#  	install_github('flr/a4adiags')

