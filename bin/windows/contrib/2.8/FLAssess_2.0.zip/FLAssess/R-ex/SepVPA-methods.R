### Name: SepVPA-methods
### Title: Separable Virtual Population Analysis in FLR
### Aliases: SepVPA SepVPA-methods SepVPA,FLStock-method
###   assess,FLSepVPA.control-method
### Keywords: methods models

### ** Examples

# Example based on ple4 dataset
data(ple4)
# Set up stock with correct dimensions
my.stock <- FLStock(catch.n(ple4))
my.stock@range["plusgroup"] <- 15
#load catch data and mortality
my.stock@catch.n <- ple4@catch.n
my.stock@catch.n[my.stock@catch.n==0] <- 1
my.stock@m <- ple4@m
my.control <- FLSepVPA.control(sep.age = 5)
# Set up in final year
my.stock@stock.n[,"2001"] <- ple4@stock.n[,"2001"]
# Run SepVPA
my.stock.SepVPA <- SepVPA(my.stock, my.control, fit.plusgroup=TRUE)



