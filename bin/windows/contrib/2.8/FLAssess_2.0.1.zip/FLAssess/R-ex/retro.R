### Name: retro-methods
### Title: Retrospective stock assessment in FLR
### Aliases: retro retro-methods retro,FLStock,FLIndex,ANY,numeric-method
###   retro,FLStock,FLIndices,ANY,numeric-method
### Keywords: models

### ** Examples

# Using the deprecated retro method
# library(FLXSA)
# data(ple4)
# data(ple4.indices)
# retro(ple4,ple4.indices,FLXSA.control(),4)

# Example using ''tapply'' and specifying the range of years.
# This example uses FLXSA
#ple4 <- ple4+FLXSA(ple4,ple4.indices,FLXSA.control())
#retro.years <- 2004:2008
#ple4.retro  <-tapply(retro.years,1:length(retro.years),function(x)
#return(window(ple4,end=x)+FLXSA(window(ple4,end=x),ple4.indices)))

# coerce into FLStocks object
# ple4.retro <- FLStocks(ple4.retro)
# full retrospective summary plot
# plot(ple4.retro)

# SPECIFIC RETROSPECTIVE PATTERNS
# SSB
#ylab <- 'SSB'
#xlab <- 'Year'
#mainttl <- 'SSB retrospective'
#xyplot(data~year,groups=qname,data=lapply(ple4.retro,ssb),xlab=xlab,ylab=ylab,main=mainttl,type="l")
 
# FBAR
#ylab <- expression(bar(F))
#xlab <- 'Year'
#mainttl <- 'mean F retrospective'
#xyplot(data~year,groups=qname,data=lapply(ple4.retro,fbar),xlab=xlab,ylab=ylab,main=mainttl,type="l")
 
# RECRUITS
#ple4.retro.rec <- list()
#for(i in 1:length(ple4.retro))
#   ple4.retro.rec[[i]] <- stock.n(ple4.retro[[i]])[1,]
#ple4.retro.rec <- FLQuants(mcf(ple4.retro.rec))
#ylab <- 'Recruits'
#xlab <- 'Year'
#mainttl <- 'Recruitment retrospective'
#xyplot(data~year,groups=qname,data=ple4.retro.rec,xlab=xlab,ylab=ylab,main=mainttl,type="l")



