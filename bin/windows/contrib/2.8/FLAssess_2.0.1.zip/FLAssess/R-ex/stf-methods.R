### Name: stf-methods
### Title: Projection preparation for FLR
### Aliases: stf stf-methods stf,FLAssess-method stf,FLBiol-method
###   stf,FLStock-method
### Keywords: methods

### ** Examples

# load ple4
data(ple4)
# stf with default settings
ple4.stf <- stf(ple4, nyears=3, wts.nyears=4, fbar.nyears=3)



