### Name: logr-class
### Title: Class "logr" for log ratio at age per cohort
### Aliases: logr-class logr logr-methods logr,FLQuant-method
### Keywords: classes

### ** Examples

require(FLEDA)
data(ple4)
myp <- logr(catch.n(ple4))
plot(myp)
# now trimming years
myp <- logr(catch.n(ple4), year=c(1990:2000))
plot(myp)



