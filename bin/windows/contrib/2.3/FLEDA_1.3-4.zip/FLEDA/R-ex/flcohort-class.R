### Name: FLCohort-class
### Title: Class "FLCohort" for information by cohort
### Aliases: FLCohort-class FLCohort FLCohort-methods
###   FLCohort,FLQuant-method as.data.frame,FLCohort-method
###   [,FLCohort-method quant,FLCohort-method trim,FLCohort-method
###   units,FLCohort-method units<-,FLCohort,character-method
### Keywords: classes

### ** Examples

data(ple4)
flc <- FLCohort(catch.n(ple4))
plot(flc)


