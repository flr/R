### Name: FLFleet-class
### Title: FLFleet class and methods
### Aliases: FLFleet FLFleet-class summary,FLFleet-method
###   plot,FLFleet,missing-method transform,FLFleet-method
###   revenue,FLFleet-method name,FLFleet-method
###   name<-,FLFleet,character-method desc,FLFleet-method
###   desc<-,FLFleet,character-method effort,FLFleet-method
###   effort<-,FLFleet,FLQuant-method
### Keywords: classes

### ** Examples
   

# Create a new fleet
catch <- FLQuant(NA, dimnames=list(age=as.character(1:12), year=as.character(c(1991:2000)),
          unit="all", season="all", area="all"))
fleet <- FLQuant(NA, dimnames=list(quant="all", year=as.character(c(1991:2000)),
          unit="all", season="all", area="all"))
my.fleet <- FLFleet(iniFLQuantFleet=fleet, iniFLQuantCatch=catch, catchname="examplecatch",
desc="Just an examplefleet")
my.effort <- FLQuant(matrix(rpois(20,120), nrow=1))
my.range <- c(1, 8, 8, 1980, 2000)
my.fleet@effort <- my.effort
my.fleet@catches[[1]]@range <- my.range
summary(my.fleet)



