### Name: revenue
### Title: Calculate the revenue of a fleet
### Aliases: revenue
### Keywords: methods

### ** Examples

 data(bt4)
 bt4@catches[[1]]@price[] <- 3
 bt4@catches[[2]]@price[] <- 6
 revenue(bt4, type="gross")



