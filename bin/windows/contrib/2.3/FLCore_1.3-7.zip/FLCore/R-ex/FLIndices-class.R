### Name: FLIndices-class
### Title: Class FLIndices
### Aliases: FLIndices-class FLIndices summary,FLIndices-method
###   plot,FLIndices,missing-method trim,FLIndices-method
###   [,FLIndices-method
### Keywords: classes methods

### ** Examples
## Not run: 
##D # Create two FLIndex objects, and collect them together in an FLIndices collection
##D my.index1 <- FLIndex(name="index #1", method="Lognormal GLM")
##D my.index2 <- FLIndex(name="index #2", method="Poisson GLM")
##D my.indices <- FLIndices(my.index1, my.index2, desc="An example of an FLIndices object")
##D summary(my.indices)
##D 
##D # We do not need individual components any more
##D rm(my.index1, my.index2)
##D 
##D # To access one index, use:
##D my.indices[[2]] # Get the second index dataset in the collection
##D 
##D is.FLIndices(my.indices)
## End(Not run)



