### Name: is.FLSR
### Title: FLSR
### Aliases: is.FLSR
### Keywords: classes manip

### ** Examples




