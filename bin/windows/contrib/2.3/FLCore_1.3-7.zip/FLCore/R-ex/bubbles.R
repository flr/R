### Name: bubbles-methods
### Title: Lattice style bubble plots
### Aliases: bubbles bubbles-methods bubbles,FLQuant-method
###   bubbles,FLQuants-method bubbles,formula,FLQuant-method bkey
###   bkey-methods bkey,list-method
### Keywords: methods

### ** Examples

data(ple4sex)
# let's see how it looks
bubbles(age~year|unit, data=ple4sex@catch.n/1000, bub.scale=5)
# what about the log scale ?
bubbles(age~year|unit, data=log(ple4sex@catch.n))



