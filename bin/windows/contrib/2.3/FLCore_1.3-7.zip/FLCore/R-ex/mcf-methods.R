### Name: mcf-methods
### Title: Make compatible "FLQuant" objects
### Aliases: mcf-methods mcf mcf,FLQuants-method mcf,list-method
### Keywords: methods

### ** Examples

data(ple4)
mcf(list(catch.n(ple4), landings.n(ple4), discards.n(ple4)))



