### Name: is.FLIndex
### Title: FLIndex
### Aliases: is.FLIndex
### Keywords: classes manip

### ** Examples

        # This is TRUE
        is.FLIndex(FLIndex())



