### Name: quant
### Title: Common summary operations for FLQuants
### Aliases: quantSums quantMeans yearSums yearMeans unitSums unitMeans
###   seasonSums seasonMeans areaSums areaMeans yearTotals quantTotals
###   dimSums
### Keywords: manip

### ** Examples




