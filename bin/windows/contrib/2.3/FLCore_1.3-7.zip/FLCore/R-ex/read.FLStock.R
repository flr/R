### Name: read.FLStock
### Title: Import stock data from a file
### Aliases: read.FLStock read.VPAFile
### Keywords: IO

### ** Examples

## Supposing the directory c:/mydata contains some VPA suite data, use:

# my.stock <- read.FLStock("c/mydata/index")

## to import stock data into the variable 'my.stock'



