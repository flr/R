### Name: as.FLBiol
### Title: Method for creating an FLBiol object from other classes
### Aliases: as.FLBiol as.FLBiol-methods as.FLBiol,FLBiol-method
### Keywords: methods

### ** Examples




