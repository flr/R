### Name: FLIndex-class
### Title: Class FLIndex
### Aliases: FLIndex-class FLIndexSurvey-class FLIndexAcoustic-class
###   FLIndex FLIndexSurvey FLIndexAcoustic
###   apply,FLIndex,list,function-method plot,FLIndex,missing-method
###   summary,FLIndex-method transform,FLIndex-method name,FLIndex-method
###   name<-,FLIndex,character-method desc,FLIndex-method
###   desc<-,FLIndex,character-method distribution,FLIndex-method
###   distribution<-,FLIndex,character-method index,FLIndex-method
###   index<-,FLIndex,FLQuant-method index.var,FLIndex-method
###   index.var<-,FLIndex,FLQuant-method catch.n,FLIndex-method
###   catch.n<-,FLIndex,FLQuant-method catch.wt,FLIndex-method
###   catch.wt<-,FLIndex,FLQuant-method effort,FLIndex-method
###   effort<-,FLIndex,FLQuant-method index.q,FLIndex-method
###   index.q<-,FLIndex,FLQuant-method sel.pattern,FLIndex-method
###   sel.pattern<-,FLIndex,FLQuant-method trim,FLIndex-method
### Keywords: classes methods

### ** Examples

fi <- FLIndex(name = 'index', desc = 'An index', index=FLQuant(dim=c(5,10,1,1,1)))
summary(fi)



