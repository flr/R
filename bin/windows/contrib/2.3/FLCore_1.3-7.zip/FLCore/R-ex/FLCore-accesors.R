### Name: FLCore-accesors
### Title: Accesor and replacement methods for slots of complex objects
### Aliases: FLCore-accesors name name-methods name<- "name<-"-methods desc
###   desc-methods desc<- "desc<-"-methods distribution
###   distribution-methods distribution<- "distribution<-"-methods index
###   index-methods index<- "index<-"-methods index.var index.var-methods
###   index.var<- "index.var<-"-methods n n-methods n<- "n<-"-methods m
###   m-methods m<- "m<-"-methods wt wt-methods wt<- "wt<-"-methods fec
###   fec-methods fec<- "fec<-"-methods spwn spwn-methods spwn<-
###   "spwn<-"-methods model model-methods model<- "model<-"-methods
###   ssb-methods ssb<- "ssb<-"-methods rec rec-methods rec<-
###   "rec<-"-methods rechat rechat-methods rechat<- "rechat<-"-methods
###   residuals residuals-methods residuals<- "residuals<-"-methods params
###   params-methods params<- "params<-"-methods se se-methods se<-
###   "se<-"-methods covar covar-methods covar<- "covar<-"-methods varacorr
###   varacorr-methods varacorr<- "varacorr<-"-methods aic aic-methods
###   aic<- "aic<-"-methods mcmc mcmc-methods mcmc<- "mcmc<-"-methods
###   catch.n catch.n-methods catch.wt catch.wt-methods effort effort<-
###   effort-methods "effort<-"-methods sel.pattern sel.pattern-methods
###   index.q index.q-methods catch catch-methods catch.n catch.n-methods
###   catch.wt catch.wt-methods catch<- "catch<-"-methods catch.n<-
###   "catch.n<-"-methods catch.wt<- "catch.wt<-"-methods discards
###   discards-methods discards<- "discards<-"-methods discards.n
###   discards.n-methods discards.n<- "discards.n<-"-methods discards.wt
###   discards.wt-methods discards.wt<- "discards.wt<-"-methods landings
###   landings-methods landings.n landings.n-methods landings.wt
###   landings.wt-methods landings<- "landings<-"-methods landings.n<-
###   "landings.n<-"-methods landings.wt<- "landings.wt<-"-methods mat
###   mat-methods mat<- "mat<-"-methods m.spwn m.spwn-methods m.spwn<-
###   "m.spwn<-"-methods stock stock-methods stock<- "stock<-"-methods
###   stock.n stock.n-methods stock.n<- "stock.n<-"-methods stock.wt
###   stock.wt-methods stock.wt<- "stock.wt<-"-methods harvest
###   harvest-methods harvest<- "harvest<-"-methods harvest.spwn
###   harvest.spwn-methods harvest.spwn<- "harvest.spwn<-"-methods
###   catch.sel catch.sel-methods catch.sel<- "catch.sel<-"-methods
###   catchability catchability-methods catchability<-
###   "catchability<-"-methods discards.sel discards.sel-methods
###   discards.sel<- "discards.sel<-"-methods gear gear-methods gear<-
###   "gear<-"-methods landings.sel landings.sel-methods landings.sel<-
###   "landings.sel<-"-methods price price-methods price<-
###   "price<-"-methods
### Keywords: methods

### ** Examples




