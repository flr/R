### Name: as.FLQuant
### Title: as.FLQuant
### Aliases: is.FLQuant as.FLQuant as.FLQuant-methods
###   as.FLQuant,data.frame-method as.FLQuant,vector-method
###   as.FLQuant,matrix-method as.FLQuant,array-method
###   as.FLQuant,FLQuant-method
### Keywords: classes manip

### ** Examples

# Generate an array containing random numbers, and convert it into an FLQuant
sq <- FLQuant(array(rnorm(120, mean=2), dim=c(20,3,2,1,1),
      dimnames=list(age=as.character(1:20), 
                    year=c("1999", "2000", "2001"), 
                    unit=c("male", "female"), 
                    season="all", area="all")), units="Tons")
summary(sq)

# as.FLQuant
arr <- array(rnorm(24), dim=c(3, 4, 2))
class(arr)
flq <- as.FLQuant(arr, units='kg')
summary(flq)
class(flq)

is.FLQuant(flq)        # Yes



