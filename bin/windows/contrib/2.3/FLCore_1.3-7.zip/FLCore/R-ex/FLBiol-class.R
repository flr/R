### Name: FLBiol-class
### Title: Class FLBiol
### Aliases: FLBiol-class FLBiol as.FLSR,FLBiol-method
###   apply,FLBiol,list,function-method setunits,FLBiol-method
###   summary,FLBiol-method plot,FLBiol,missing-method
###   transform,FLBiol-method name,FLBiol-method
###   name<-,FLBiol,character-method desc,FLBiol-method
###   desc<-,FLBiol,character-method n,FLBiol-method
###   n<-,FLBiol,FLQuant-method m,FLBiol-method m<-,FLBiol,FLQuant-method
###   wt,FLBiol-method wt<-,FLBiol,FLQuant-method fec,FLBiol-method
###   fec<-,FLBiol,FLQuant-method spwn,FLBiol-method
###   spwn<-,FLBiol,FLQuant-method
### Keywords: classes

### ** Examples




