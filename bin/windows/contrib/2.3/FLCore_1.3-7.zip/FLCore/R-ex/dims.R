### Name: dims
### Title: Provide information onn the dimensions and range of an object
### Aliases: dims dims-methods dims,FLQuant-method dims,FLIndex-method
### Keywords: methods

### ** Examples

        dims(FLQuant(rnorm(10), dim=c(2,5,1,1,1), quant='age'))



