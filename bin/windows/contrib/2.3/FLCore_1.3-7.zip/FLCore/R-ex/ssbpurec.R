### Name: ssbpurec
### Title: Method for calculating Spawning Stock Biomass per unit recruit
### Aliases: ssbpurec
### Keywords: methods

### ** Examples
## Not run: 
##D data(ple4)
##D spur.ple4 <- ssbpurec(ple4,start=1957,end=1966,type='non-param',plusgroup=FALSE)
## End(Not run)



