### Name: srlkhd
### Title: Likelihood of the S-R parameters
### Aliases: srlkhd
### Keywords: models

### ** Examples




