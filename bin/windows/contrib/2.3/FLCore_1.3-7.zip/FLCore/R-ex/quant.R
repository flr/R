### Name: quant
### Title: Quant, first dimension of FLQuant
### Aliases: quant quant<- quant-methods "quant<-"-methods
### Keywords: methods

### ** Examples

        flq <- FLQuant(rnorm(20), dim=c(6,10,1,1,1), quant='age')
        quant(flq)
        quant(flq) <- 'length'



