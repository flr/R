### Name: is.FLBiol
### Title: FLBiol
### Aliases: is.FLBiol
### Keywords: classes manip

### ** Examples
## Not run: 
##D     ple4.popln<-FLBiol(data(ple4))
##D     is.FLBiol(ple4.popln)
## End(Not run)



