### Name: FLQuant
### Title: FLQuant
### Aliases: FLQuant FLQuant-methods FLQuant,missing-method
###   FLQuant,vector-method FLQuant,matrix-method FLQuant,array-method
###   FLQuant,FLQuant-method
### Keywords: classes manip

### ** Examples

# Generate an array containing random numbers, and convert it into an FLQuant
sq <- FLQuant(array(rnorm(120, mean=2), dim=c(20,3,2,1,1),
      dimnames=list(age=as.character(1:20), 
                    year=c("1999", "2000", "2001"), 
                    unit=c("male", "female"), 
                    season="all", area="all")), units="Tons")



