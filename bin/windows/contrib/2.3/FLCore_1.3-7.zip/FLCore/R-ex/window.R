### Name: window
### Title: window for FLQuants based classes
### Aliases: window window-methods window,FLStock-method
###   window,FLIndices-method window,FLQuant-method window,FLBiol-method
###   window,FLCatch-method window,FLFleet-method window,FLIndex-method
### Keywords: methods

### ** Examples

data(ple4)
ple490 <- window(ple4, 1990, 2000)



