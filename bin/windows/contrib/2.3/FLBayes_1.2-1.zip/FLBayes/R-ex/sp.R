### Name: sp
### Title: FLSP - an FLR class for applying the Schaefer/Pella-Tomlinson
###   surplus-production model
### Aliases: sp spm splkhd
### Keywords: models

### ** Examples




