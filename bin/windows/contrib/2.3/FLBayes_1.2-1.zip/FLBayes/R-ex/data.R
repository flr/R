### Name: data
### Title: FLBayes datasets
### Aliases: sp.ple4 alb alb.sp
### Keywords: datasets

### ** Examples




