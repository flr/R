### Name: msy-class
### Title: Class msy
### Aliases: msy-class msy,FLSP-method
### Keywords: classes methods

### ** Examples




