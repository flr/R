### Name: correctIndex
### Title: Corrects index for VPA
### Aliases: correctIndex
### Keywords: manip

### ** Examples




