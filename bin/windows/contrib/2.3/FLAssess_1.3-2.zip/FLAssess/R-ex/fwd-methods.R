### Name: fwd-methods
### Title: Forward projection for FLR
### Aliases: fwd fwd-methods
### Keywords: methods

### ** Examples

# load ple4
data(ple4)
# stf with default settings - extends the stock object by three years
ple4.stf <- stf(ple4,nyrs=3, wts.nyrs=4, f.nyrs=3, disc.nyrs=3)
# run a standard three year projection, with fixed recruitment for all years
ple4.fwd <- fwd(ple4.stf, year=as.character(2002:2004), sr.model="mean", sr.param=250000)
# Or can fix catch numbers
ple4.catch <- ple4.stf
ple4.catch@catch[,as.character(2002:2004)] <- c(60000,60000,60000)
ple4.catch.fwd <- fwd(ple4.catch, year=as.character(2002:2004), sr.model="mean", sr.param=250000)



