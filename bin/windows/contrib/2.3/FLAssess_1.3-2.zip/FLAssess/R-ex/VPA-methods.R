### Name: VPA-methods
### Title: Virtual Population Analysis in FLR
### Aliases: VPA VPA-methods VPA,FLStock-method
### Keywords: methods models

### ** Examples

library(FLCore)
library(FLAssess)
# use the ple4 data set
data(ple4)
# Set up stock
my.stock<-FLStock(iniFLQuant = FLQuant(dim=c(15,45,1,1,1),
  dimnames = list (age=as.character(1:15),
  year = as.character(c(1957:2001)))))
my.stock@range["plusgroup"] <- 15
my.stock@catch.n <- ple4@catch.n
# replace zeros in catch as 1
my.stock@catch.n[my.stock@catch.n==0] <- 1
my.stock@m <- ple4@m
# Set initial fishing mortality in the final ages of each year and for all ages in the final year:
my.stock@harvest[15,,,,] <- ple4@harvest[15,,,,]
my.stock@harvest[,45,,,] <- ple4@harvest[,45,,,]
# Run VPA
my.stock.VPA <- VPA(my.stock, fit.plusgroup=TRUE)



