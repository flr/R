### Name: is.FLAssess
### Title: is.FLAssess
### Aliases: is.FLAssess
### Keywords: classes manip

### ** Examples
## Not run: 
##D     is.FLAssess(new('FLAssess'))
## End(Not run)



