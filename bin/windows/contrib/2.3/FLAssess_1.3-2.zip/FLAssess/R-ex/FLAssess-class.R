### Name: FLAssess
### Title: FLAssess class and methods
### Aliases: FLAssess-class show,FLAssess-method units,FLAssess-method
###   units<-,FLAssess,list-method window,FLAssess-method
###   summary,FLAssess-method +,FLAssess,FLStock-method
###   +,FLStock,FLAssess-method update,FLAssess-method
###   plot,FLAssess,missing-method
### Keywords: classes methods

### ** Examples




