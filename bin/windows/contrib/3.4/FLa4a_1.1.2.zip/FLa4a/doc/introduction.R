## ----eval=FALSE----------------------------------------------------------
#  # from CRAN
#  install.packages(c("copula","triangle", "coda"))
#  # from FLR
#  install.packages(c("FLCore", "FLa4a"), repos="http://flr-project.org/R")

## ----load_libraries, message=FALSE, warning=FALSE------------------------
# libraries
library(FLa4a)
library(XML)
library(reshape2)
library(latticeExtra)
# datasets
data(ple4)
data(ple4.indices)
data(ple4.index)
data(rfLen)

## ------------------------------------------------------------------------
packageVersion("FLCore")
packageVersion("FLa4a")

## ----lattice_opts, echo=FALSE, message=FALSE, warning=FALSE--------------
a4a.theme = trellis.par.get()
a4a.theme$strip.background$col <- "gray90"
trellis.par.set(a4a.theme)

