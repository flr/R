## ---- setup, echo=FALSE, results='hide', message=FALSE----
library(knitr)
opts_chunk$set(dev='png', fig.width=4.5, fig.height=4.5, tidy=TRUE)
options(width=50)

## ---- load, echo=FALSE, results='hide', message=FALSE, warnings=FALSE----
library(FLFishery)

## ---- coerceFLStoFLC----------------------------
# Load an FLStock
data(ple4)
# Make an FLCatch
flc <- as(ple4, "FLCatch")
summary(flc)

## ---- coerceFLStoFLF----------------------------
# Load an FLStock
data(ple4)
# Make an FLFishery
flf <- as(ple4, "FLFishery")

## -----------------------------------------------
summary(flf[[1]])

## ---- devtools, echo=TRUE, eval=FALSE-----------
#  	library(devtools)
#  	install_github('iagomosqueira/FLFishery')

## ----setupf, ref.label='setup', echo=2, eval=FALSE----
#  library(knitr)
#  opts_chunk$set(dev='png', fig.width=4.5, fig.height=4.5, tidy=TRUE)
#  options(width=50)

