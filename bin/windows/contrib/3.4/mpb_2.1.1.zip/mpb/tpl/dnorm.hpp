#include <admodel.h>
dvariable dnorm(const double&, const dvariable&, const dvariable&);
dvariable dnorm(prevariable&, double&, double&);
dvariable dnorm(const dvector&, const dvar_vector&, const dvar_vector&);
