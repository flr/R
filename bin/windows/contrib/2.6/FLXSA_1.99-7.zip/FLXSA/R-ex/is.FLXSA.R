### Name: is.FLXSA
### Title: is.FLXSA
### Aliases: is.FLXSA is.FLXSA.control
### Keywords: attribute

### ** Examples

xsa <- FLXSA.control()
is.FLXSA.control(xsa)



