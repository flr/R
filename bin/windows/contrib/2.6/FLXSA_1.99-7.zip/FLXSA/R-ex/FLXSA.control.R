### Name: FLXSA.control
### Title: Create a new FLXSA.control object
### Aliases: FLXSA.control
### Keywords: classes

### ** Examples

        # To create a new FLXSA.control object with default parameters:
        my.xsa.control <- FLXSA.control()
        my.xsa.control
        # Same, but changing values of some parameters
        my.xsa.control <- FLXSA.control(maxit=50, shk.f=FALSE)
        my.xsa.control



