## ---- pkgs, echo=FALSE, message=FALSE, warning=FALSE--------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>", warning=FALSE)
library(bbm)
set.seed(987)
# LOAD other packages, including bbm, here

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#    install.packages('TMB')
#    install.packages(c("FLCore"), repos="http://flr-project.org/R")

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#    install.packages(c("bbm"), repos="http://flr-project.org/R")

## ---- devtools, echo=TRUE, eval=FALSE-----------------------------------------
#  	library(devtools)
#  	install_github('flr/bbm')

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
	library(bbm)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  data(ane)

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#    ?ane

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  class(catch.ane)
  dim(catch.ane)
  catch.ane

## ---- echo=TRUE, eval=TRUE, fig.width = 8, fig.height = 5---------------------
  xyplot(data~year|age+season, data=catch.ane, type="l", main="Total Catch (t)")

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  nyrs <- dim(catch.ane)[2]  
  nyrs
  years <- dimnames(catch.ane)$year

## ---- echo=TRUE, eval=TRUE, , fig.width = 8, fig.height = 5-------------------
  xyplot( data~year|season,
          data=FLQuants(period1=catch.ane[1,,,1,,]/quantSums(catch.ane[,,,1,,]),
                        period2=catch.ane[1,1:(nyrs-1),,2,,]/quantSums(catch.ane[,1:(nyrs-1),,2,,])),
          type="l", main="Catch proportion of recruits by period", ylab="")


## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  length(indicesB.ane)
  names(indicesB.ane)  
  lapply(indicesB.ane, index)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  length(indicesP.ane)
  names(indicesP.ane)  
  lapply(indicesP.ane, index)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  lapply(indicesB.ane, range)
  lapply(indicesP.ane, range)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  findicesB.ane <- unlist(lapply(indicesB.ane, function(x) return(mean(range(x)[c('startf','endf')])))) 
  findicesB.ane
  findicesP.ane <- unlist(lapply(indicesP.ane, function(x) return(mean(range(x)[c('startf','endf')])))) 
  findicesP.ane

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  per <- periods(findicesB=findicesB.ane, findicesP=findicesP.ane)
  per 

## ---- echo=TRUE, eval=TRUE, fig.width = 8, fig.height = 5---------------------
  dat <- FLQuants()
  for (i in 1:length(indicesB.ane)) dat[[i]] <- index(indicesB.ane[[i]])
  names(dat) <- names(indicesB.ane)
  xyplot( data~year|qname, data=dat,
          type="b", main="Total biomass by survey", ylab="Total biomass (t)")

## ---- echo=TRUE, eval=TRUE, fig.width = 8, fig.height = 5---------------------
  dat <- FLQuants()
  for (i in 1:length(indicesP.ane)) dat[[i]] <- index(indicesP.ane[[i]])
  names(dat) <- names(indicesP.ane)
  xyplot( data~year|qname, data=dat,
          type="b", main="Recruits' biomass proportion by survey", ylab="")

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
class(control.ane)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
slotNames(control.ane)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
control.ane@g

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
class(control.ane@param.fix)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
control.ane@param.fix

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
sum(control.ane@param.fix==1) # number of fixed parameters

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
class(inits.ane)
inits.ane

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
out <- calcPop(g=control.ane@g, f=per$f, catch=catch.ane, inits=inits.ane)
names(out)
out$ok
out$stock.bio

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  run <- bbm(catch.ane, 
             indicesB=FLQuants(depm=index(indicesB.ane[[1]]), acoustic=index(indicesB.ane[[2]])), 
             indicesP=FLQuants(depm=index(indicesP.ane[[1]]), acoustic=index(indicesP.ane[[2]])),         
             findicesB=findicesB.ane, 
             findicesP=findicesP.ane,
             control=control.ane, inits=inits.ane)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  class(run)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  slotNames(run)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  run@convergence

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  params(run)
  params.se(run)
  vcov(run)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  logLik(run)
  AIC(run)
  BIC(run)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
   stock.bio(run)
   indicesB(run)
   indicesP(run)

## ---- echo=TRUE, eval=TRUE, fig.width = 8, fig.height = 5---------------------
   plot(run) 

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  res <- residuals(run)
  res

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  class(res)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  slotNames(res)
  res@residuals.B$depm

## ---- echo=TRUE, eval=TRUE, fig.width = 8, fig.height = 5---------------------
   plot(res) 
   #qqmath(res)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
inits.ane2 <- bbmFLPar( years=dimnames(catch.ane)$year, namesB=names(indicesB.ane), namesP=names(indicesP.ane),
                        niter=dim(catch.ane)[6])

inits.ane2[] <- c( 0.6, 0.6, 100, 100, 3, 3, 60000, rep(40000, nyrs), 10, 2)
inits.ane2

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
inits.ane3 <- createInits( catch.ane, indicesB=indicesB.ane, indicesP=indicesP.ane, 
                           g=control.ane@g)
inits.ane3

## ---- echo=TRUE, eval=TRUE, results="hide"------------------------------------
  run1 <- bbm(catch.ane, indicesB=indicesB.ane, indicesP=indicesP.ane, control=control.ane, inits=inits.ane)
  run2 <- bbm(catch.ane, indicesB=indicesB.ane, indicesP=indicesP.ane, control=control.ane, inits=inits.ane2)
  run3 <- bbm(catch.ane, indicesB=indicesB.ane, indicesP=indicesP.ane, control=control.ane, inits=inits.ane3)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  params(run1)
  params(run2)
  params(run3)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  AIC(run1)
  AIC(run2)
  AIC(run3)

## ---- echo=TRUE, eval=TRUE, fig.width = 8, fig.height = 5---------------------
parnames <- sapply(dimnames(run1@params)$params, function(x) unlist(strsplit(x,split="_"))[1])
dat <- cbind( run1=c(params(run1)[parnames %in% "R"]), run2=c(params(run2)[parnames %in% "R"]), 
              run3=c(params(run3)[parnames %in% "R"]))
rownames(dat) <- years

matplot( dat, type="l", ylab="R (t)", xlab="year", lty=1, col=c('black','red','green'), xaxt = "n")
axis(1, at=1:nyrs, labels=years)
legend( "topright", paste("run",1:3,sep=""), lty=1:3, col=c('black','red','green'), bty="n")

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
param.fix <- bbmFLPar( 0, years=dimnames(catch.ane)$year, niter=dim(catch.ane)[6], 
                       namesB=names(indicesB.ane), namesP=names(indicesP.ane)) 
param.fix['q_depm'] <- 1

control.ane2 <- bbmControl(g=c(rec=0.68, adult=0.68), param.fix=param.fix)

## ---- echo=TRUE, eval=TRUE, results="hide"------------------------------------
  run4 <- bbm( catch.ane, indicesB=indicesB.ane, indicesP=indicesP.ane, 
               control=control.ane2, inits=inits.ane)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  params(run4)
  params.se(run4)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
  inits.ane$q_depm
  run4@params$q_depm
  run4@params.se$q_depm

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
data(ple4)

aux <- landings.n(ple4)*landings.wt(ple4)
catch.ple4 <- FLQuant(NA, dim=c(2, dim(landings.n(ple4))[2], 1, 2, 1, 1), dimnames=list(year=dimnames(landings.n(ple4))$year))
catch.ple4[1, , ,1:2, ,] <- aux[1,]/2
catch.ple4[2, , ,1:2, , ] <- quantSums(aux[-1,])/2
catch.ple4

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
rr <- rlnorm(dim(catch.ple4)[2], log(300000), 1/sqrt(3))
par.ple4 <- bbmFLPar(years=dimnames(catch.ple4)$year, namesB=c("Mysurvey"), namesP=c("Mysurvey"), niter=1)
par.ple4[] <- c(1, 200, 4, 200000, rr, log(250000), 3)
par.ple4

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
g <- c(rec=0.3, adult=0.25)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
pop.ple4 <- calcPop(g=g, f=c(0.5, 0.5), catch=catch.ple4, inits=par.ple4)
pop.ple4

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
indices.ple4 <- simIndices( catch.ple4, g=g, inits=par.ple4, 
                         findicesB=c(Mysurvey=0.5), findicesP=c(Mysurvey=0.5) )

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
length(indices.ple4)
names(indices.ple4)

lapply(indices.ple4$Btot, index)
lapply(indices.ple4$Btot, range)
lapply(indices.ple4$Prec, index)
lapply(indices.ple4$Prec, range)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------

param.fix <- par.ple4
param.fix[] <- 0 # dummy FLPar indicating which parameters are fixed (0 estimated and 1 fixed)

control.ple4 <- new( "bbmControl", g=g, param.fix=param.fix)  # bbmControl. We assumed g is known exactly 

inits.ple4 <- createInits(catch.ple4, indicesB=indices.ple4$Btot, indicesP=indices.ple4$Prec, g=g) # create automatic initial parameters

## ---- echo=TRUE, eval=TRUE, results="hide"------------------------------------
fit.ple4 <- bbm(catch.ple4, indicesB=indices.ple4$Btot, indicesP=indices.ple4$Prec, 
                control=control.ple4, inits=inits.ple4)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
params(fit.ple4)
params.se(fit.ple4)
logLik(fit.ple4)
AIC(fit.ple4)
BIC(fit.ple4)

## ---- echo=TRUE, eval=TRUE----------------------------------------------------
(params(fit.ple4) - par.ple4)/par.ple4

## ---- echo=TRUE, eval=TRUE, fig.width = 8, fig.height = 5---------------------
res <- residuals(fit.ple4)
plot(res)
qqmath(res)

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#  	library(devtools)
#  	#install_github('flr/bbm')

