### Name: brp
### Title: ~~function to calculate reference points ~~
### Aliases: brp FLBRP
### Keywords: models

### ** Examples

## load example FLStock object from FLCore
    data(ple4)
        
    ## create a corresponding FLBRP object
    ple4.brp<-FLBRP(ple4)

    ## calculate reference points
    ple4.brp<-brp(ple4.brp)
    
    ## get reference points
    ple4.brp@refpts




