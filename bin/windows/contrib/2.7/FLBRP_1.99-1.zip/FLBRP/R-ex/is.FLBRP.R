### Name: is.FLBRP
### Title: ~~function to do ... ~~
### Aliases: is.FLBRP
### Keywords: classes manip

### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function(x)
        return(inherits(x, "FLBRP"))



