### Name: FLBRP-class
### Title: Class FLBRP: fish stock equilibrium analysis and reference point
###   calculation
### Aliases: FLBRP-class plot,FLBRP,missing-method summary,FLBRP-method
###   name,FLBRP-method name<-,FLBRP,character-method desc,FLBRP-method
###   desc<-,FLBRP,character-method price,FLBRP-method
###   price<-,FLBRP,FLQuant-method cost,FLBRP-method
###   cost<-,FLBRP,numeric-method
### Keywords: classes methods

### ** Examples


    ## load example FLStock object from FLCore
    data(ple4)
        
    ## create a corresponding FLBRP object
    ple4.brp<-FLBRP(ple4)
        
    ## get the slots that will hold the reference points
    ple4.brp@refpts
        
    ## calculate reference points
    ple4.brp<-brp(ple4.brp)
    
    ## get reference points again
    ple4.brp@refpts
        
    ## plot per recruit values
    plot(ple4.brp)
    
    ## plot it against historical data
    # first set recruitment to mean
    ple4.brp@sr.params[]<-mean(ple4.brp@rec.obs) 
    #redo brp
    ple4.brp<-brp(ple4.brp)
    plot(brp(ple4.brp),obs=TRUE)
    
    ## Two sex example
    data(ple4sex)
    brp(FLBRP(ple4sex))@refpts
    
    ## changing slots when creating
    new.mat<-FLQuant(c(rep(0,4),rep(1,11)),dimnames=dimnames(ple4.brp@mat))
    FLBRP(ple4,mat=new.mat,harvest=c(Fpa=0.6))
    
    ## adding new reference points
    FLBRP(ple4,harvest=c(Fpa=0.6))




