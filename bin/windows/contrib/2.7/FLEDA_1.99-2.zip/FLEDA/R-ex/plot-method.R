### Name: plot-method
### Title: Plot for class "FLCohort"
### Aliases: plot-method plot,FLCohort-method
### Keywords: methods

### ** Examples

data(ple4)
flc <- FLCohort(catch.n(ple4))
plot(flc)



