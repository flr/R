### Name: rpay-class
### Title: Class "rpay" for relative proportion at age per year
### Aliases: rpay-class rpay rpay-methods rpay,FLQuant-method
### Keywords: classes

### ** Examples

data(ple4sex)
# compute relative catch proportion at age
ple4sex.rpay <- rpay(ple4sex@catch.n)
# fine tune 
ttl <- list(label="Relative catch proportion at age for Plaice in IV", cex=1)
yttl <- list(label="age", cex=0.8)
xttl <- list(cex=0.8)
ax <- list(cex=0.7)
# plot
bubbles(age~year|unit, ple4sex.rpay,  main=ttl, 
        ylab=yttl, xlab=xttl, scales=ax)



