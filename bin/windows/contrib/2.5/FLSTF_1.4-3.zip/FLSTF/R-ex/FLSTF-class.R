### Name: FLSTF-class
### Title: Short Term Forecasting for FLStocks
### Aliases: FLSTF FLSTF-class as.FLStock,FLSTF-method update,FLSTF-method
###   summary,FLSTF-method
### Keywords: classes

### ** Examples


library(FLSTF)
data(ple4)
# default 3 year forecast
ple4.stf.control <- FLSTF.control()
ple4.stf.control # returns summary of control object using the overwritten "show" method.
ple4.stf         <- FLSTF(ple4, ple4.stf.control) # creates new FLSTF object and runs forecast
ple4.stf@stock.n

# 10 year forecast
ple4.stf.control <- FLSTF.control(nyrs=10)
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ple4.stf@stock.n

# specify year range for gm recruitment estimate
ple4.stf.control <- FLSTF.control(rec.yrs=c(1990,2001))
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ple4.stf@stock.n

# Specify recruitment for the forecast years
ple4.stf.control <- FLSTF.control(nyrs=4, rec = c(200000,300000,400000,500000))
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ple4.stf@stock.n

# standard 3 year forecast with a catch constraint applied to the first forecast year
ple4.stf.control <- FLSTF.control(catch.constraint = 50000)
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ple4.stf@catch

# 4 year forecast with fixed recruitment for all years and an SSB constraint in the final year
ple4.stf.control <- FLSTF.control(rec = 400000,ssb.constraint = 300000)
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ssb(ple4.stf)
ple4.stf@stock.n

# Setting survivors using an FLQuant
ple4.stf.control <- FLSTF.control()
# randomly set survivors - not realistic - just for demonstration
survivors <- FLQuant(abs(rnorm(14,mean = 5000, sd = 1000)),dim=c(1,14,1,1,1))
ple4.stf <- FLSTF(ple4,ple4.stf.control,survivors = survivors)

# Setting survivors as a vector
ple4.stf.control <- FLSTF.control()
# all survivors set at same value - bit stupid but just to demonstrate how it works
ple4.stf <- FLSTF(ple4,ple4.stf.control,survivors = rep(2000,14))
ple4.stf@stock.n



