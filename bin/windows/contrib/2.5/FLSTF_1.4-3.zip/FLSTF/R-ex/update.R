### Name: update
### Title: update method for FLSTF
### Aliases: update
### Keywords: classes

### ** Examples


library(FLSTF)
data(ple4)

ple4.stf  <- FLSTF(ple4, FLSTF.control())
ple4.stf2 <- update(ple4.stf, fbar.max=5)




