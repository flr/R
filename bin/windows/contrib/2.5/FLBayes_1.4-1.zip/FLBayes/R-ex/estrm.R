### Name: estrm
### Title: Estimating maximum reproductive rate from life-history
###   parameters
### Aliases: estrm
### Keywords: models methods

### ** Examples
## Not run: 
##D data(ple4)
##D sr.ple4 <- sr(FLSR(ple4,model='ricker'))
##D alpha <- sr.ple4@params[,'alpha']
##D M <- quantMeans(m(ple4)[,1])
##D rho <- as.double(ssbpurec(ple4))
##D amat <- 2
##D rm <- estrm(M,amat,alpha,rho,0.7)
## End(Not run)



