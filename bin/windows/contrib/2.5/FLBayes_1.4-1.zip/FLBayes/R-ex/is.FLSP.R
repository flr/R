### Name: is.FLSP
### Title: is.FLSP
### Aliases: is.FLSP
### Keywords: methods

### ** Examples

fsp <- FLSP()
is.FLSP(fsp)



