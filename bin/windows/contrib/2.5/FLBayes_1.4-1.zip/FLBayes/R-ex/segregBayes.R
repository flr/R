### Name: segregBayes
### Title: Hockey stick/segmented regression stock-recruitment function in
###   a Bayesian implementation
### Aliases: segregBayes
### Keywords: methods models

### ** Examples

## Not run: 
##D data(cod)
##D mclist <- list(pinit=list(alpha=2.5,beta=4.5,sigma=0.25)logalp.mean=0,logalp.var=100,beta.mean=log(3),beta.var=0.4,sigma.shape=3,sigma.rate=1,nIter=1000,nChains=1,MCvar=c(0.1),burnin=100,thin=1)
##D pla <- qhstkBayes(as.vector(cod$rec),as.vector(cod$ssb),mclist,plot=TRUE,conv=TRUE)
## End(Not run)



