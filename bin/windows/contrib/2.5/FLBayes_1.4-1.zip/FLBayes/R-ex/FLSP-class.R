### Name: FLSP-class
### Title: Class FLSP
### Aliases: FLSP-class FLSP mclist plot,FLSP,missing-method
###   predict,FLSP-method summary,FLSP-method
### Keywords: classes methods

### ** Examples




