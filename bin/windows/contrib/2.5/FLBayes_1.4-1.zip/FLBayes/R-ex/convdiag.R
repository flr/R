### Name: convdiag
### Title: convdiag
### Aliases: convdiag
### Keywords: methods

### ** Examples




