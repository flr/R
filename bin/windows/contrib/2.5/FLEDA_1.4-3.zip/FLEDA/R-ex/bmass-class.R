### Name: bmass-class
### Title: Class "bmass" for mature and immature biomass
### Aliases: bmass-class bmass bmass-methods bmass,FLStock-method
### Keywords: classes

### ** Examples

data(ple4)
# compute mature and immature biomass
ple4.bmass <- bmass(ple4)
# tune plot
ttl <- list(label="Trends in biomass for mature and immature plaice in IV", cex=1)
yttl <- list(label="relative biomass", cex=0.8)
xttl <- list(cex=0.8)
ax <- list(cex=0.8)
akey <- simpleKey(text=c("mature", "immature"), points=FALSE, lines=TRUE)
# plot
xyplot(data~year, data=ple4.bmass, type="l", main=ttl,
       key=akey, ylab=yttl, xlab=xttl, scales=ax)



