.onLoad <- function(lib,pkg) {
	cat("FLEDA 2.4 \"The Duke's hobnobber\"\n")
  cat("------------------------------------\n")
}

