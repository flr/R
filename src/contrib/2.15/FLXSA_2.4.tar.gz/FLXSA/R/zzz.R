# zzz - �Short one line description�

# Author: Iago Mosqueira, AZTI Fundazioa
# Additions:
# Last Change: 02 Ago 2005 13:33
# $Id: zzz.R,v 1.2 2005/08/02 11:39:20 iagoazti Exp $

# Reference:
# Notes:

# TODO Ven 22 Abr 2005 08:27:40 BST iagoazti:

#options(warn.FPU=FALSE)

.onLoad <- function(lib,pkg) {
	require(methods)
	cat("FLXSA 2.4 \n")
	cat("This package is not maintained anymore.\n")
	cat("Would YOU like the job?\n")
	cat("------------------------------------\n")


}
