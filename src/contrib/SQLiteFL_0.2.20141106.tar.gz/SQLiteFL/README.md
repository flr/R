SQLiteFL
========

FLR package for storing S4 classes in an SQLite database
