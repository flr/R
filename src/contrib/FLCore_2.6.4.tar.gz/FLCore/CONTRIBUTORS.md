# CONTRIBUTORS to FLCore

- Dorleta GARCIA
- Philippe GROSJEAN
- Ernesto JARDIM
- Laurence KELL
- Iago MOSQUEIRA
- Finlay SCOTT
- Robert SCOTT
- Jose DE OLIVEIRA

