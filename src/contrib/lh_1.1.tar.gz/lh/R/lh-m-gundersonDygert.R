#http://icesjms.oxfordjournals.org/content/66/9/1978.full
#http://onlinelibrary.wiley.com/doi/10.1111/j.1467-2979.2009.00350.x/full

## Constant values
gundersonDygert=function(par)
  0.03 + 1.68*params["gsi"]
