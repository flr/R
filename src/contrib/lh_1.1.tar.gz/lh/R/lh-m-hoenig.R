hoenig=function(par,age=NULL) #amax)
   4.22/params["amax"]
