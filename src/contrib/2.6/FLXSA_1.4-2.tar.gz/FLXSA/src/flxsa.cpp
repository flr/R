#include <math.h>
#include <float.h>

#ifdef WIN32
   #include <windows.h>
   #define SEXPDLLExport __declspec(dllexport) SEXP __cdecl    
#else
   #define SEXPDLLExport SEXP    
#endif

#include "flrxsa.hpp"

extern "C" SEXPDLLExport FLXSA(SEXP Stock, SEXP CPUE, SEXP Control) 
   {
   int MinAge, MaxAge, Plusgroup, MinYear, MaxYear;

   //Input Catch Data
   CatchDataR Catch(PROTECT(duplicate(GET_SLOT(Stock, install("catch.n"))))); 
   UNPROTECT(1);      
   if (Catch.Error != FiFiErrNull)
      return ReturnError("Error in FLXSA.control");

   //Input Tuning Data
   TuningFleetsR TuningData(CPUE, &Catch);       
   if (TuningData.Error != FiFiErrNull)
      return ReturnError("Error in FLIndices");
      
   //Input XSAControls
   ExtendedSurvivorsAnalysisR XSA(Control, PROTECT(duplicate(GET_SLOT(Stock, install("m")))), &Catch, &TuningData); 
   UNPROTECT(1);      
   if (XSA.Error != FiFiErrNull)
      return ReturnError("Error in FLXSA.control");

   InputRange(PROTECT(duplicate(GET_SLOT(Stock, install("range")))), &MinAge, &MaxAge, &Plusgroup, &MinYear, &MaxYear);
   UNPROTECT(1);      
    
   //Run XSA
   //if N & F supplied then do not iterate
  // XSA.InputNF(Stock);


    SEXP v = R_NilValue;   

   if (!XSA.Run()) 
       return ReturnError("Error in running XSA");

   //Results  
   return XSA.Return(MaxYear); 
   }



