# bevholtBayes = 

# Author: Richard Hillary, Imperial College
#         Iago Mosqueira, AZTI Fundazioa 
# Last Change: 01 feb 2007 11:51
# $Id: bevholtBayes.R,v 1.10.2.1 2007/02/01 11:26:54 ejardim Exp $

# Notes:

bevholtBayes <- function(rec,ssb,mclist,plot=TRUE,conv=TRUE)
{
	# coerce rec and ssb into vectors

	if(!is.vector(rec)) rec <- as.vector(rec)
	if(!is.vector(ssb)) ssb <- as.vector(ssb)
	
	# check the required elements in mclist for bevholtBayes
	# are not NA

	if(!is.list(mclist))
		stop("Control list not a list")

	if(!is.na(mclist$pinit[['S0']]))
		S0init <- mclist$pinit[['S0']]
	else stop("Initial S0 missing")

	if(!is.na(mclist$pinit[['h']]))
		hinit <- mclist$pinit[['h']]
	else stop("Initial h missing") 

	if(!is.na(mclist$pinit[['sigma']]))
		siginit <- mclist$pinit[['sigma']]
	else stop("Initial sigma missing") 
	
	if(!is.na(mclist$S0.mean)) 
		S0.mean <- mclist$S0.mean
	else stop("Prior S0.mean missing")
	
	if(!is.na(mclist$S0.var)) 
		S0.var <- mclist$S0.var
	else stop("Prior S0.var missing")

	if(!is.na(mclist$h.alpha)) 
		h.alpha <- mclist$h.alpha
	else stop("Prior h.alpha missing")

	if(!is.na(mclist$h.beta)) 
		h.beta <- mclist$h.beta
	else stop("Prior h.beta missing")

	if(!is.na(mclist$sigma.shape)) 
		sigma.shape <- mclist$sigma.shape
	else stop("Prior sigma.shape missing") 

	if(!is.na(mclist$sigma.rate)) 
		sigma.rate <- mclist$sigma.rate
	else stop("Prior sigma.rate missing") 

	if(!is.na(mclist$nIter)) 
		nIter <- mclist$nIter
	else stop("Number of iterations missing")

 	if(!is.na(mclist$nChains)) 
		nChains <- mclist$nChains
	else stop("Number of Chains missing") 

	if(!is.na(mclist$thin))
		thin <- mclist$thin
	else stop("Thinning factor missing")
	
	if(!is.na(mclist$MCvar[1]) && !is.na(mclist$MCvar[2]))
		MCvar <- mclist$MCvar
	else stop("Random walk variance(s) missing")

	if(!is.na(mclist$SSBperRec))
		SSBperRec <- mclist$SSBperRec
	else stop("SSB per unit recruit missing")

	if(!is.na(mclist$burnin))
		burnin <- mclist$burnin
	else stop("Burn-in length missing")
	
	# call bevholtBayes
	res <- .Call("bevholtBayes", rec, ssb, c(S0.mean,S0.var,h.alpha,h.beta,sigma.shape,sigma.rate),
		c(S0init,hinit,siginit), as.integer(nIter), as.integer(burnin), as.integer(thin), 
		as.integer(nChains), MCvar, SSBperRec)

	names(res) <- 'params'

	# standard plot for first chain only

	if(plot == TRUE) {
		par(mfrow=c(3,2))
		ts.plot(res[[1]][,1],ylab=expression(S[0]))
		hist(res[[1]][,1],yaxt="n",xlab=expression(S[0]),main=" ")
		ts.plot(res[[1]][,2],ylab=expression(h))
		hist(res[[1]][,2],yaxt="n",xlab=expression(h),main=" ")
		ts.plot(res[[1]][,5],ylab=expression(sigma[r]^2))
		hist(res[[1]][,5],yaxt="n",xlab=expression(sigma[r]^2),main=" ")
		for(i in 1:length(res))
			colnames(res[[i]]) <- c("S0", "h", "alpha", "beta", "sigma")
	}
	
	# convergence diagnostic check on the S0 parameter if requested

	if(conv==TRUE) {
		conv <- list(length=length(res))
		for(i in 1:length(res))
			conv[[i]] <- res[[i]][,'S0']
		convstat <- convdiag(conv)
		cat("Convergence statistic:\n")
		print(convstat) 
	} 
	
	# create a new list that discards the burnin

	return(res) 
}
