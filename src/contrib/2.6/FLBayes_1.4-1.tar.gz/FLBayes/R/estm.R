# Front end to the mest C++ code, used for (Monte Carlo) estimation
# of the single-values natural mortality, given the average life-span of a species 
# Richard Hillary <r.hillary@imperial.ac.uk>
# ::
# $Id: estm.R,v 1.1 2007/01/15 14:19:18 rmh1977 Exp $

estm <- function(lbar,minit) {

	# coerce everything to vectors

	lbar <- as.vector(lbar)
	
	# check for negative values...

	if(!all(lbar[lbar > 0]))
		stop("Error in estm: one or more of the inputs are negative")

	if(minit <= 0)
		stop("Error in estm: initial estimate is not positive")

	# call the C++ solver code

	m <- .Call("mest",lbar,as.double(minit))
	
	return (m)
}
