# MCMC convergence diagnostic code for FLBayes

# Author: Richard Hillary, Imperial College
#         Iago Mosqueira, AZTI Fundazioa 
# Last Change: 28/07/2005
# Reference:
# $Id: convdiag.R,v 1.2 2005/08/02 10:01:23 rmh1977 Exp $

# Notes:

convdiag <- function(conv) 
{
	# check conv is a list

	if(!is.list(conv))
		stop("List of Markov chains not a list!")

	# if only one chain => split into two and use the Brooks and Roberts
	# interval quantile method

	if(length(conv) == 1) {
		
		if(length(conv[[1]]) %% 2 == 0) 
			nits <- length(conv[[1]])
		else nits <- length(conv[[1]])-1

		if(length(conv[[1]])<2)
			stop("Number of MCMC samples less than 2!")

		theta1 <- conv[[1]][1:as.integer(nits/2)]
		theta2 <- conv[[1]][as.integer(nits/2+1):nits]
		del1 <- quantile(theta1,0.975,names=FALSE)-quantile(theta1,0.025,names=FALSE)
		del2 <- quantile(theta2,0.975,names=FALSE)-quantile(theta2,0.025,names=FALSE)
		theta3 <- as.vector(cbind(theta1,theta2))
		del3 <- quantile(theta3,0.975,names=FALSE)-quantile(theta3,0.025,names=FALSE)
		convstat <- del3/(0.5*(del1+del2))
	} 

	# if more than one chain => use Brooks and Roberts 
	# interval quantile length method

	if(length(conv) > 1) {
	
		M <- length(conv)
		N <- length(conv[[1]])
		theta <- matrix(nrow=N,ncol=M)
		del <- vector(length=M)
		for(j in 1:M) 
			theta[,j] <- conv[[j]]
		theta_tot <- as.vector(theta)
		del <- apply(theta,2,function(x) quantile(x,0.975,names=FALSE)-quantile(x,0.025,names=FALSE))
		del_tot <- quantile(theta_tot,0.975,names=FALSE)-quantile(theta_tot,0.025,names=FALSE)
		convstat <- del_tot/mean(del)
	}

	return(convstat)
}
