# FLSP.R - FLSP class and methods for applying the Schaefer model with catch and effort data

# Author: Richard Hillary (Imperial College) & Iago Mosqueira (AZTI Fundazioa)
# Maintainer: Richard Hillary
# Additions:
# Last Change: 08 Ago 2005 12:50
# $Id: FLSP.R,v 1.33 2006/11/28 12:40:19 rmh1977 Exp $

# Reference:
# Notes:

## class :: FLSP                   {{{
setClass("FLSP",
	representation(
 		name     = "character",
		desc     = "character",
		catch    = "FLQuant",
		index    = "FLQuant",
		bhat     = "FLQuant",
		residuals= "FLQuant",
		harvest	 = "FLQuant",
		estim    = "character",
		eps      = "numeric",
		params   = "matrix",
		mpar     = "numeric",
		delta    = "numeric",
		se       = "numeric",
		covar    = "matrix",
		var      = "numeric",
        	mcmc     = "list"),
	prototype=prototype(
		name     = character(0),
		desc     = character(0),
		catch    = new("FLQuant"), 
		index    = new("FLQuant"),
		bhat     = new("FLQuant"),
		residuals= new("FLQuant"),
		harvest  = new("FLQuant"),
		estim    = "mle",
		eps      = as.double(0),
		params   = matrix(NA, ncol=3, dimnames=list("", c('Q','r','K'))),
		mpar     = as.double(2),
		delta    = as.double(1),
        se       = unlist(list(Q=as.double(NA), r=as.double(NA), K=as.double(NA))),
        covar    = matrix(rep(NA, 9), nrow=3, ncol=3, 
            		dimnames = list(c("Q", "r", "K"), c("Q", "r", "K"))),
        var      = as.double(NA),
		mcmc     = list(params=list(),
					pinit=unlist(list(Q=as.double(NA),r=as.double(NA),K=as.double(NA),sigmas=as.double(NA))),
					logQ.mean=as.double(NA),logQ.var=as.double(NA),r.mean=as.double(NA),r.var=as.double(NA),
					K.mean=as.double(NA),K.var=as.double(NA),sigma.shape=as.double(NA),sigma.rate=as.double(NA),
					nIter=as.integer(NA),nChains=as.integer(NA),burnin=as.integer(NA),
					thin=as.integer(NA),MCvar=as.vector(NA)))
)   # }}}

# FLSP()      {{{
FLSP <- function(catch="missing", index="missing",...) {
	
	if(is.FLStock(catch) && is.FLIndex(index)) {
		
		sp <- new("FLSP")
		
		if(length(catch@catch[1,,1,1,1]) < length(index@index[1,,1,1,1]))
			stop("Catch series shorter than the abundance index series")
		
		slot(sp, "catch") <- catch@catch
		slot(sp, "index") <- index@index
		slot(sp, "bhat") <- FLQuant(catch@catch)
		slot(sp, "harvest") <- FLQuant(catch@catch,units="hr")
		slot(sp, "residuals") <- FLQuant(index@index)
	}

	else if (is.FLQuant(catch) && is.FLQuant(index)) {

		sp <- new("FLSP")

		if(length(catch[1,,1,1,1]) < length(index[1,,1,1,1]))
			stop("Catch series shorter than the abundance index series") 
		
		slot(sp, "catch") <- catch
		slot(sp, "index") <- index
		slot(sp, "bhat") <- FLQuant(catch)
		slot(sp, "harvest") <- FLQuant(catch,units="hr")
		slot(sp, "residuals") <- FLQuant(index)
	}

	else {
		sp <- new("FLSP")
	}

	# define extra slot attributes if supplied
	
	args <- list(...)
    	if(length(args) > 0) {
        	for (i in 1:length(args)) {
            		try(slot(sp, names(args)[i]) <- args[[i]], silent=TRUE)
        	}
    	} 
	return(sp)
} # }}}

## is.FLSP()                  {{{
is.FLSP <- function(x) {
	return(inherits(x,"FLSP"))
} # }}}

# summary :: FLSP             {{{
if (!isGeneric("summary")) {
	setGeneric("summary", useAsDefault = summary)
}
setMethod("summary", signature(object="FLSP"),
	function(object, ...) {
		cat("An object of class \"FLSP\" with: \n\n")
		cat("Name: ",slot(object, "name"), "\n")
		cat("Desc: ", slot(object, "desc"), "\n")
		cat("Catch: [", dim(slot(object, "catch")),"], units=", slot(object, "catch")@units, "\n")
		cat("Index: [", dim(slot(object, "index")),"], units=", slot(object, "index")@units, "\n") 
		cat("-----\n")
		cat("Estimation method applied:", slot(object, "estim"), "\n")
		cat("Pella-Tomlinson parameter used:", slot(object, "mpar"), "\n")
		cat("Ratio of B0 to K:", slot(object, "delta"), "\n") 
		cat("Parameter estimates:\n")
        	show(slot(object, "params"))
        	if(length(object@mcmc$params) > 0)
            		cat("McMC chains: ", length(object@mcmc$params), "\n") 
	}
) # }}}

## predict :: Generic           {{{
if (!isGeneric("predict")) {
    setGeneric("predict", function(object, ...){
	    value <- standardGeneric("predict")
	    value
    })
} # }}}

## predict :: FLSP		{{{
setMethod("predict", signature(object="FLSP"),
	function(object, catch="missing", ...){
		
		if(missing(catch))
			.catch <- as.vector(object@catch)
		else if (is.FLQuant(catch))
			.catch <- as.vector(quantSums(catch))
		else {
			if(!is.vector(catch))
				stop("Catches given to predict not given as vector or FLQuant")
		}
		.mpar <- slot(object, "mpar")
		if(is.na(object@params[,'r']) || is.na(object@params[,'K']))
			stop("Parameter estimates missing")
		
		.biom <- vector(length=length(.catch))
		.biom[1] <- object@delta
		for(i in 2:length(.catch)) {
			.biom[i] <- .biom[i-1] + object@params[,'r']*.biom[i-1]*(1-(.biom[i-1])^(.mpar-1))-.catch[i]/object@params[,'K']
			if(.biom[i] <= 0)
				.biom[i] <- 1.0e-3
		}
		
		return(.biom)
	}
) # }}}

## plot :: Generic		{{{
if (!isGeneric("plot")) {
	setGeneric("plot", useAsDefault = plot)
}
setMethod("plot", signature(x="FLSP",y="missing"),
	function(x,y,type=c("all","bhat","ivsqb","Res.AR","Res.t","Harv","QQ")) {
		
		if(is.na(x@var)) {
			
			if(is.na(x@params[,'Q']) | is.na(x@params[,'r']) | is.na(x@params[,'K']))
				stop("Initial parameter estimates missing")

			.bhat <- as.vector(predict(x))
			.ind <- as.vector(x@index)
			.c <- as.vector(x@catch)
			.indhat <- vector(length=length(.ind))
			.diff <- length(.c)-length(.ind)
			.mpar <- slot(x, "mpar")
			iyear <- as.vector(dimnames(x@index)$year)
			for(i in 1:length(.indhat))
				.indhat[i] <- .bhat[i+.diff]*x@params[,'Q']
			plot(iyear,.ind,ylim=c(0,max(.ind,.indhat)),xlab="Years",ylab="CPUE",main="Initial guess predicted vs. obs CPUE")
			lines(iyear,.indhat,col="red")

		} else { 
			bhat <- x@bhat[1,,,,drop=TRUE]
			ind <- x@index[1,,,,drop=TRUE]
			catch <- x@catch[1,,,,drop=TRUE]
			params <- x@params
			resid <- x@residuals[1,,,,drop=TRUE]
			byear <- as.integer(dimnames(x@bhat)$year)
			iyear <- as.integer(dimnames(x@index)$year)

			# biomass plot

			SPBhatplot <- function(bhat,byear) {
				plot(byear,bhat,ylim=c(0,max(bhat)+5),xlab="Years",ylab="Biomass",main="Historical biomass dynamics",type="l")
				invisible()
			}

			# Prediceted vs observed cpue

			SPIvsQBplot <- function(bhat,ind,params,iyear,byear) {
				.diff <- length(bhat)-length(ind)
				.bhat <- vector(length=length(ind)) 
				for(i in 1:length(ind))	
					.bhat[i] <- bhat[i+.diff]
				.indhat <- .bhat*(params[,'Q']/params[,'K']) 
				imax <- max(.indhat,ind)				 
				plot(iyear,ind,ylim=c(0,imax),xlab="Years",ylab="Index of abundance",main="Predicted vs. observed CPUE",type="p")
				lines(iyear,.indhat,col="red")
				invisible()
			}

			# Residual autocorrelation plot

			SPResARplot <- function(resid) {
				plot(resid[1:(length(resid)-1)],resid[2:length(resid)],
					xlab="Residuals at time t",ylab="Residuals at time t+1",
					main="AR(1) Residuals")
				resid.lm <- lm(as.vector(resid[1:(length(resid)-1)]) ~ as.vector(resid[2:length(resid)]))
				abline(resid.lm,col="red")
				invisible()
			}

			# Residuals for the predicted and observed CPUE

			SPResIQBplot <- function(resid,iyear) {
				plot(iyear,resid,xlab="Years",ylab="Residuals",main="CPUE residuals by year")
				lines(lowess(iyear,resid), col="red")
				abline(h=0,lty=2)
				invisible()
			}

			# Harvest rate

			SPHarvestplot <- function(catch,bhat,byear) {
				plot(byear,catch/bhat,xlab="Years",ylab="Harvest rate",ylim=c(0,max(catch/bhat)+0.1),
				main="Historical harvest rate",type="l")
				invisible()
			}

			# QQ plot for the resisuals
			
			SPQQplot <- function(resid) {
				x <- (resid-mean(resid))/(var(resid)^0.5)
				n  <-  length(x)
				seq.length<-min(1000,n) 
				SD<-sqrt(var(x)*(n+1)/n)
				SEQ<-seq(1,2*n+1,length=seq.length)/2
    			U<-qnorm(qbeta(0.975,SEQ,rev(SEQ)))
   				L<-qnorm(qbeta(0.025,SEQ,rev(SEQ))) 
				X<-qnorm((SEQ-0.25)/(n+0.5))
				M<-mean(x)+SD*qt(qbeta(0.5,SEQ,rev(SEQ)),n-1) 
  				qqnorm(x,main="QQplot with median and CI")
  				lines(X,U,lty=2)
  				lines(X,L,lty=2) 
				lines(X,M,type="l",col='red') 
				#invisible()
			}

			# all option plot

			SPPlots <- function(bhat,ind,catch,resid,params,byear,iyear) {
				par(mfrow=c(3,2))
				SPBhatplot(bhat,byear)
				SPIvsQBplot(bhat,ind,params,iyear,byear)
				SPResARplot(resid)
				SPResIQBplot(resid,iyear)
				SPHarvestplot(catch,bhat,byear)
				SPQQplot(resid)
				invisible()
			}

			# to chose your plot

			opar <- par(no.readonly=TRUE)
			on.exit(par(opar))
			par(mfrow=c(1,1))
			switch(as.character(type[1]), 
				"all"=SPPlots(bhat,ind,catch,resid,params,byear,iyear),
				"bhat"=SPBhatplot(bhat,byear),
				"ivsqb"=SPIvsQBplot(bhat,ind,params,iyear,byear),
				"Res.AR"=SPResARplot(resid),
				"Res.t"=SPResIQBplot(resid,iyear),
				"Harv"=SPHarvestplot(catch,bhat,byear),
				"QQ"=SPQQplot(resid),
				stop("type must be 'all', 'bhat', 'ivsqb', 'Res.AR', 'Res.t', 'Harv' or 'QQ'"))
				invisible()
		}
	}
) # }}}

## lkhd		{{{
# computes the log-likelihood of the given data and parameter estimates in 
# the FLSP object. The higher the logL, the better the estimate...

splkhd <- function(x) {

	if(!is.FLSP(x))
		stop("Error: object passed is not of class FLSP")
	
	if(is.na(x@params[,'Q']) | is.na(x@params[,'r']) | is.na(x@params[,'K']))
		stop("Error: check parameter estimates are present")
	
	.biom <- predict(x)
	.indx <- as.vector(x@index)
	.diff <- length(.biom)-length(.indx)
	if(.diff < 0) 
		stop("Error: abundance index longer than the catch series")
	.res <- vector(length=length(.indx))
	for(i in 1:length(.indx))
		.res[i] <- log(.indx[i])-log(.biom[i+.diff])
	.var <- var(.res)
	logL <- 0
	for(i in 1:length(.indx))
		logL <- logL + dnorm(log(.indx[i]),log(x@params[,'Q']*.biom[i+.diff]),sqrt(.var),TRUE)
	names(logL)  <- 'logL'
	return(logL)
}	# }}}

## spm		{{{
# function to compute the MLE for Q, r and K in the re-scaled Schafer model

spm <- function(catch,index,eps,mpar,delta,params,rfix) {

	if(!is.vector(catch) | !is.vector(index))
		stop("Inputs not vectors")
	if(missing(params))
		stop("Initial estimate missing")
	
	.c <- catch
	.i <- index

	# create the output list

	res <- list(bhat=as.vector(NA),
		residuals=as.vector(NA),
		harvest=as.vector(NA),
		params=matrix(NA, ncol=3, dimnames=list("", c('Q','r','K'))), 
		se=unlist(list(Q=as.double(NA),r=as.double(NA),K=as.double(NA))),
		covar=matrix(rep(NA,9),nrow=3,ncol=3,dimnames=list(c("Q","r","K"),
		c("Q","r","K"))),
		var=as.double(NA))
	
	.bhat <- vector(length=length(.c))
	.ihat <- vector(length=c(.i))
	.diff <- length(.c)-length(.i)
	.res <- vector(length=length(.i)) 
	if(.diff < 0)
		stop("Length of biomass index longer than the catch data")

	# simple if loop for r variable or r fixed

	if(!rfix) {

		fn <- function(x) {
			.Q <- x[1]
			.r <- x[2]
			.K <- x[3]
			.bhat[1] <- delta
			for(i in 2:length(.c)) {
				.bhat[i] <- .bhat[i-1] + .r*.bhat[i-1]*(1-(.bhat[i-1])^(mpar-1))-.c[i]/.K
				if(.bhat[i] <= 0)
					.bhat[i] <- 1.0e-3
			} 
			.res <- vector(length=length(.i))
			for(i in 1:length(.i))
				.res[i] <- log(.i[i])-log(.Q*.bhat[i+.diff])
			.var <- var(.res) 
			logL <- 0
			for(i in 1:length(.i))
				logL <- logL - dnorm(log(.i[i]),log(.Q*.bhat[i+.diff]),sqrt(.var),TRUE) 
		}
	
		# initial guess must be supplied 

		param <- numeric(3)
		lower <- numeric(3)
		upper <- numeric(3)

		param[1] <- params[,'Q']
		param[2] <- params[,'r']
		param[3] <- params[,'K'] 
		lower[1] <- 0.00001
		lower[2] <- 0.00001 
		lower[3] <- 0.00001
		upper[1] <- Inf
		upper[2] <- Inf 
		upper[3] <- Inf 
	
		resop <- optim(param,fn,
				   lower = lower,
				   upper = upper,
			   	   method = "L-BFGS-B",
			   	   hessian = TRUE,
			   	   control = list(trace=1)) 

		.bhat[1] <- delta
		for(i in 2:length(.c)) {
			.bhat[i] <- .bhat[i-1] + resop$par[2]*.bhat[i-1]*(1-(.bhat[i-1])^(mpar-1))-.c[i]/resop$par[3]
			if(.bhat[i] <= 0)
				.bhat[i] <- 1.0e-3
		}
		res$bhat <- .bhat*resop$par[3]
		for(i in 1:length(.i))
			.res[i] <- log(.i[i])-log(resop$par[1]*.bhat[i+.diff])
		res$residuals <- .res
		res$harvest <- .c/(.bhat*resop$par[3])
		res$params[,'Q'] <- resop$par[1]
		res$params[,'r'] <- resop$par[2] 
		res$params[,'K'] <- resop$par[3] 
		res$var <- var(.res)
		if(det(resop$hessian) != 0) {
			res$covar <- solve(resop$hessian)
			res$se[[1]] <- sqrt(res$covar[1,1])
			res$se[[2]] <- sqrt(res$covar[2,2]) 
			res$se[[3]] <- sqrt(res$covar[3,3]) 
		} else print("Hessian singular - no covariance estimate possible")
	} else {
		 
		fn <- function(x) {
			.Q <- x[1]
			.r <- params[,'r']
			.K <- x[2]
			.bhat[1] <- delta
			for(i in 2:length(.c)) {
				.bhat[i] <- .bhat[i-1] + .r*.bhat[i-1]*(1-(.bhat[i-1])^(mpar-1))-.c[i]/.K
				if(.bhat[i] <= 0)
					.bhat[i] <- 1.0e-3
			} 
			.res <- vector(length=length(.i))
			for(i in 1:length(.i))
				.res[i] <- log(.i[i])-log(.Q*.bhat[i+.diff])
			.var <- var(.res) 
			logL <- 0
			for(i in 1:length(.i))
				logL <- logL - dnorm(log(.i[i]),log(.Q*.bhat[i+.diff]),sqrt(.var),TRUE) 
		}
	
		# initial guess must be supplied 

		param <- numeric(2)
		lower <- numeric(2)
		upper <- numeric(2)

		param[1] <- params[,'Q']
		param[2] <- params[,'K']
		lower[1] <- 0.00001
		lower[2] <- 0.00001 
		upper[1] <- Inf
		upper[2] <- Inf 
	
		resop <- optim(param,fn,
				   lower = lower,
				   upper = upper,
			   	   method = "L-BFGS-B",
			   	   hessian = TRUE,
			   	   control = list(trace=1)) 


		.bhat[1] <- delta
		for(i in 2:length(.c)) {
			.bhat[i] <- .bhat[i-1] + params[,'r']*.bhat[i-1]*(1-(.bhat[i-1])^(mpar-1))-.c[i]/resop$par[2]
			if(.bhat[i] <= 0)
				.bhat[i] <- 1.0e-3
		}
		res$bhat <- .bhat*resop$par[2]
		for(i in 1:length(.i))
			.res[i] <- log(.i[i])-log(resop$par[1]*.bhat[i+.diff])
		res$residuals <- .res
		res$harvest <- .c/(.bhat*resop$par[2])
		res$params[,'Q'] <- resop$par[1]
		res$params[,'r'] <- params[,'r'] 
		res$params[,'K'] <- resop$par[2] 
		res$var <- var(.res)
		if(det(resop$hessian) != 0) {
			res$covar <- solve(resop$hessian)
			tmp <- matrix(NA,ncol=3,nrow=3)
			tmp[c(1,3),c(1,3)] <- res$covar[1:2,1:2]
			res$covar <- tmp 
			res$se[[1]] <- sqrt(res$covar[1,1])
			res$se[[2]] <- NA
			res$se[[3]] <- sqrt(res$covar[3,3]) 
		} else print("Hessian singular - no covariance estimate possible") 
	}
	
	return(res)
}	# }}}

## sp()		{{{		
sp <- function(data,rfix = FALSE,...) {

	sp <- data
	estim <- sp@estim
	params <- sp@params
	mclist <- sp@mcmc
	eps <- sp@eps
	mpar <- sp@mpar
	delta <- sp@delta

	if(is.FLSP(sp)) {
		catch <- as.vector(sp@catch)
		index <- as.vector(sp@index)
	} else stop("Object is not of type FLSP")
	
	if(estim == "mle") {
		res <- spm(catch,index,eps,mpar,delta,params,rfix)
	} else if(estim == "Bayes") {
		res <- spBayes(catch,index,eps,mpar,delta,mclist)
	}

	# MLE output

	if(estim == "mle") {
		for(i in 1:length(res)) {
			if(is.FLQuant(slot(sp, names(res)[i]))) {
				
				# create temporary FLQuants from res and then 
				# assign them to the relevant slots in sr object
				
				.units <- slot(sp, names(res)[i])@units
				.nm <- dimnames(slot(sp, names(res)[i]))
				tmpflq <- FLQuant(res[[i]],dim=c(1,length(res[[i]]),1,1,1),dimnames=.nm,units=.units)
        			slot(sp, names(res)[i]) <- tmpflq
			} else {
            			try(slot(sp, names(res)[i]) <- res[[i]], silent=TRUE)
			}
    		}  
	} else if(estim == "Bayes")
		sp@mcmc$params <- res

	return(sp)

} #}}}

## msy {{{
setClass("msy",
	representation(	
		name 	   = "character",
		desc       = "character",
		bmsy       = "numeric",
		cmsy       = "numeric",
		hmsy       = "numeric",
		bmsy.ratio = "FLQuant",
		cmsy.ratio = "FLQuant",
		hmsy.ratio = "FLQuant"),
	prototype=prototype(
		name       = character(0),
		desc       = character(0),
		bmsy       = 0,
		cmsy       = 0,
		hmsy       = 0,
		bmsy.ratio = FLQuant(),
		cmsy.ratio = FLQuant(),
		hmsy.ratio = FLQuant())
)

if (!isGeneric("msy")) {
    setGeneric("msy", function(object, ...){
	    value <- standardGeneric("msy")
	    value
    })
}

setMethod("msy",signature(object="FLSP"),
	function(object, ...) {

		est <- slot(object, "estim")
		biom  <- slot(object, "bhat")
		catch  <- slot(object, "catch")
		harv   <- slot(object, "harvest")
		mpar  <- slot(object, "mpar")
		r  <- object@params[,"r"]
		K   <- object@params[,"K"]

		x  <- new("msy")

		# Calculate Bmsy, Cmsy & Hmsy for Pella-Tomlinson model
		
		if(est == 'mle') {
			bmsy  <- K / (mpar^{1/(mpar-1)})
			cmsy  <- ((r * K) / (mpar^{1/(mpar-1)})) * (1-mpar^{-1})
			hmsy  <- ifelse(cmsy/bmsy <= 1,cmsy/bmsy,1)
			brat  <- biom[1,,1,1,1]/bmsy
			crat  <- catch[1,,1,1,1]/cmsy
			hrat  <- harv[1,,1,1,1]/hmsy
		} else {
			bmsy  <- K / (mpar^{1/(mpar-1)})
			cmsy  <- ((r * K) / (mpar^{1/(mpar-1)})) * (1-mpar^{-1})
			hmsy  <- ifelse(cmsy/bmsy <= 1,cmsy/bmsy,1)

			# ratios
			
			dimn <- dimnames(biom) 
			dm <- dim(biom)
			xx <- apply(biom@.Data,1:5,function(x,bmsy){x <- x/bmsy},bmsy)
			xx  <-  aperm(xx,c(2,3,4,5,6,1))
			brat <-  FLQuant(quant='all',dim=dm,dimnames=dimn)
			brat@.Data <- xx
			
			catch <- propagate(catch,'all',dm[6])
			xx <- apply(catch@.Data,1:5,function(x,cmsy){x <- x/cmsy},cmsy)
			xx  <-  aperm(xx,c(2,3,4,5,6,1))
			crat <- FLQuant(quant='all',dim=dm,dimnames=dimn)
			crat@.Data <- xx

			harv <- catch/biom
			harv <- apply(harv,1:6,function(x){ifelse(x > 1,1,x)})
			xx <- apply(harv@.Data,1:5,function(x,hmsy){x <- x/hmsy},hmsy)
			xx  <-  aperm(xx,c(2,3,4,5,6,1))
			hrat <- FLQuant(quant='all',dim=dm,dimnames=dimn)
			hrat@.Data <- xx
			rm(xx)
		}
	
		# add these to their slots

		slot(x, "bmsy")  <- bmsy
		slot(x, "cmsy")  <- cmsy
		slot(x, "hmsy")  <- hmsy 
		slot(x, "bmsy.ratio")  <- brat
		slot(x, "cmsy.ratio")  <- crat
		slot(x, "hmsy.ratio")  <- hrat 

		# all the other slots if info submitted...

		args <- list(...)
    	if(length(args) > 0) {
        	for (i in 1:length(args)) {
            		try(slot(x, names(args)[i]) <- args[[i]], silent=TRUE)
        	}
    	} 

		return(x)
	}
) ## }}}
