# FLBayes - �Short one line description�

# Author: Iago Mosqueira, AZTI Fundazioa
# Additions:
# Last Change: 10 jul 2006 14:06
# $Id: FLBayes.R,v 1.5 2007/01/24 16:00:20 imosqueira Exp $

# Reference:
# Notes:

# TODO Lun 18 Abr 2005 20:46:48 BST iagoazti:

library(FLBayes)

## spBayes

data(alb)

#sp.alb  <- sp(alb.sp)
