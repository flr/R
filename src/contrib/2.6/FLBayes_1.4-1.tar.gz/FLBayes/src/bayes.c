/*
 * bayes.c = 
 *
 * Author : Iago Mosqueira <imosqueira@suk.azti.es> AZTI Fundazioa 
 * Last Change: 02 Feb 2005 15:34
 * $Id: bayes.c,v 1.2 2005/02/02 14:34:22 iagoazti Exp $
 *
 */

#include <R.h>
#include <Rdefines.h>
#include <Rmath.h>
#define TINY 1.e-300;

/* beta_trunc = beta kernel truncated
 * for steepness to lie between 0.2 and 1
 * beta_trunc(1,1) equivalent to uniform
 * distribution on [0.2,1]
 */

double uform(double pval,double pmin,double pmax)
{
  double uprior;
  
  if(pval >= pmin && pval <= pmax) uprior =1.0/(pmax-pmin);
  else uprior = TINY;
  
  return uprior;
}

double beta_trunc(double pval,double a,double b)
{
  double mu=0.2;
  double pwa=a-1.0,pwb=b-1.0;
  
  if((pow(pval-mu,pwa)*pow(1-pval,pwb) != 0.0) && (pval >= mu) && (pval <= 1.0)) return (pow(pval-mu,pwa)*pow(1-pval,pwb));
  else return TINY;
}
