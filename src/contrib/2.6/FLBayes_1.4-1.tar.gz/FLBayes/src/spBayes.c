/*
 * spbayes.c = Bayesian surplus production model with Metropolis-Hastings
 *             MCMC sampler.
 *
 * Author : Richard Hillary (Imperial College)
 * 			Iago Mosqueira <imosqueira@suk.azti.es> AZTI Fundazioa 
 * Last Change: 20 feb 2007 16:23
 * $Id: spBayes.c,v 1.10 2006/07/04 12:31:04 rmh1977 Exp $
 *
 */

#include <R.h>
#include <Rdefines.h>
#include <Rmath.h>
#include "bayes.h"


/* function prototypes */

void pdyn(double,double,double,double,double *,double *, int);
double funcrk(double,double,double,double,double,double,double *,double *,double *,double *,double,int, int, int, double *);

/* Function SEXP foo(SEXP x, y, priors, nIter, chains) {{{ */
SEXP spBayes(SEXP Rcatch, SEXP Rcpue, SEXP Rinit, SEXP Rpriors, SEXP Reps, SEXP Rmpar, SEXP Rdelta, SEXP RnIter, SEXP Rburnin, SEXP Rthin, SEXP Rchains, SEXP Rmvar)
{
	/* initialise variables */
	SEXP Rval = R_NilValue;
	SEXP Rlist = R_NilValue;
	GetRNGstate(); 

	int T = LENGTH(Rcatch);
	int Ts = LENGTH(Rcpue);
	int nc = INTEGER(Rchains)[0];
        int ni = INTEGER(RnIter)[0]*INTEGER(Rthin)[0];
	int nj = 4+T;	
	int nt = INTEGER(Rthin)[0];
	int nb = INTEGER(Rburnin)[0];
	int ntemp,nk;
	int c,i,t,DS;
	double *I, *C, B[T], Bsurv[T], *priors;
	double Q, lnQ, K, r, sigmas, knew, rnew;
	double pival1, pival2, acp=0.;
	double dummy1,dummy2,res;
	double accpt,uvar;
	double eps = REAL(Reps)[0];
	double mpar = REAL(Rmpar)[0];
	double delta = REAL(Rdelta)[0];
	double rvar = REAL(Rmvar)[0];
	double kvar = REAL(Rmvar)[1];

	PROTECT(Rlist = NEW_LIST(nc));

	/* data */
	
	I = REAL(Rcpue);
	C = REAL(Rcatch);
	priors = REAL(Rpriors);
	for (t=0;t<T;t++) B[t]=Bsurv[t]=0.;

	/* define the offset between the CPUE and the catches */

	DS = T-Ts;

	/* chains */
	
	for (c=0;c<nc;c++) {

		ntemp = (int)(ni/nt);
		nk = 0;
		PROTECT(Rval = allocMatrix(REALSXP, ntemp, nj));

		/* initialize chain */
	
		Q = REAL(Rinit)[0]+rnorm(0,0.01);
		r = REAL(Rinit)[1]+rnorm(0,0.01);
		K = REAL(Rinit)[2]+rnorm(0,0.01);
		sigmas = REAL(Rinit)[3]+rnorm(0,0.01);
		lnQ = log(Q);
	
		/* chain */
		for (i=0; i<ni+nb; i++) {
	    
			/* update Q using condtional posterior */ 
	    
			pdyn(r,K,mpar,delta,B,C,T);
	     
			/* rescale the biomass to the time when the catch/survey was taken */
	    
			for(t=0;t<T;t++) {
				Bsurv[t] = B[t]-eps*C[t];
				if(Bsurv[t] < 0.) Bsurv[t] = 1.e-2;
			} 
	    
			for(res=0.,t=0;t<Ts;t++) res += log(I[t])-log(Bsurv[t+DS]);
			dummy2 = 1./(1./priors[1] + (double)Ts/sigmas);
			dummy1 = (priors[0]/priors[1] + res/sigmas)*dummy2; 
			lnQ = rnorm(dummy1,sqrt(dummy2));
			Q = exp(lnQ);

			/* update r wnd K ith a random walk Metropolis update */
	    
			for(;;) {
				rnew = r + rnorm(0.0,sqrt(rvar));
				knew = K + rnorm(0.0,sqrt(kvar));
				if(rnew > 0.0 && knew > 0.0) break;
			}

			/* accept or reject */
	    
			pival1 = funcrk(Q,r,K,mpar,delta,sigmas,priors,B,Bsurv,C,eps,T,Ts,DS,I);
			pival2 = funcrk(Q,rnew,knew,mpar,delta,sigmas,priors,B,Bsurv,C,eps,T,Ts,DS,I);
	    
			accpt = pival2-pival1 < 0. ? pival2-pival1 : 0.;
	    
			/* generate a random U[0,1] variate */ 
	    
			uvar=log(runif(0.0,1.0));
	    
			if(accpt > uvar) {
				if(i >= nb) 
					acp++;
				r = rnew;
				K = knew;
			}
	    
			/* update the survey variance 
			 * using the conditional posteriors
			 */
	    
			pdyn(r,K,mpar,delta,B,C,T);
			for(t=0;t<T;t++) {
				Bsurv[t] = B[t]-eps*C[t];
				if(Bsurv[t] < 0.) Bsurv[t] = 1.e-2;
			} 
			res=0.;
			for(t=0;t<Ts;t++) res += 0.5*(log(I[t])-log(Q*Bsurv[t+DS]))*(log(I[t])-log(Q*Bsurv[t+DS]));
			dummy1=rgamma(priors[6]+(double)Ts/2.0,priors[7]/(1.0+priors[7]*res));
			sigmas=1.0/dummy1;
	    
			/* update the markov chain */
	    
			if(i >= nb && i % nt == 0) {
				REAL(Rval)[nk + 0*ntemp] = Q;
				REAL(Rval)[nk + 1*ntemp] = r;
				REAL(Rval)[nk + 2*ntemp] = K;
				REAL(Rval)[nk + 3*ntemp] = sigmas;
				for(t=0;t<T;t++) REAL(Rval)[nk + (4+t)*ntemp] = B[t]*K; 	    
				nk++;
			}
		}
		acp/=(double)(ni);
		Rprintf("(r,K) acceptance rate = %8.6f\n",acp); 

		SET_ELEMENT(Rlist, c, Rval);
	
		UNPROTECT(1);
	}

	GetRNGstate(); 
	
	UNPROTECT(1);

	return (Rlist);

} /* }}} */

void pdyn(double r,double K, double mpar, double delta, double B[], double C[], int T)
{
  int t;
  double pwr=mpar-1.;
  
  B[0]=delta;
  for(t=1;t<T;t++) {
    B[t] = B[t-1] + r*B[t-1]*(1.-pow(B[t-1],pwr))-C[t-1]/K;
    if(B[t] <= 0.) B[t] = 1.e-2;
  }

  return;
}

double funcrk(double Q,double r,double K,double mpar,double delta,double sigmas,double priors[],double B[],double Bsurv[],double C[],double eps,int T,int Ts,int DS,double I[])
{
  int t;
  double lkhd=0.,prior=0.,retval=0.;

  /* calculate the log-posterior here */

  pdyn(r,K,mpar,delta,B,C,T);
  
  for(t=0;t<T;t++) {
	  Bsurv[t] = B[t]-eps*C[t];
	  if(Bsurv[t] < 0.) Bsurv[t] = 1.e-2;
  } 

  /* log-likelihood */

  if(Q >= 0.0) {
    lkhd = -0.5*(double)Ts*log(2.*M_PI*sigmas);
    for(t=0;t<Ts;t++) lkhd -= 1./(2.*sigmas)*(log(I[t])-(log(Q*Bsurv[t+DS])))*(log(I[t])-(log(Q*Bsurv[t+DS])));
  } else lkhd = log(1.e-300);

  /* log-prior */
  
  prior += log(dlnorm(r,priors[2],sqrt(priors[3]),FALSE));
  prior += log(dlnorm(K,priors[4],sqrt(priors[5]),FALSE));
  
  retval = lkhd + prior;

  return retval;
}
