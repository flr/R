/*
 * bevholtbayes.c = Bayesian Beverton-Holt stock-recruit using 
 *                  Metropolis-within-Gibbs sampling : virgin SSB and steepness
 *                  parameterisation.
 *
 * Authors : Richard Hillary <r.hillary@imperial.ac.uk> Imperial College London
 *           Alex Glaser, Surrey University
 *           Iago Mosqueira <imosqueira@suk.azti.es> AZTI Fundazioa 
 * Last Change: 02 Feb 2005 14:47
 * $Id: bevholtBayes.c,v 1.5 2006/07/04 12:31:04 rmh1977 Exp $
 * 
 */

#include <R.h>
#include <Rdefines.h>
#include <Rmath.h>
#include "bayes.h"

/* function prototypes */

double bhfunc(double *, double *, double, double, double, double, double, double, double *, int);

/* function SEXP bevholtBayes(SEXP rec, ssb, priors, nIter, chains, mvar, rho) {{{ */
SEXP bevholtBayes(SEXP Rrec, SEXP Rssb, SEXP Rpriors, SEXP Rinit, SEXP RnIter, SEXP Rburnin, SEXP Rthin, SEXP Rchains, SEXP Rmvar, SEXP Rrho)
{
	/* initialise variables */
	SEXP Rval = R_NilValue;
	SEXP Rlist = R_NilValue;
	GetRNGstate(); 

	int i=0,c,t;
	int ni = INTEGER(RnIter)[0]*INTEGER(Rthin)[0];
	int nj = 5;
	int T = LENGTH(Rrec);
	int nc = INTEGER(Rchains)[0];
	int nt = INTEGER(Rthin)[0];
	int nb = INTEGER(Rburnin)[0];
	int ntemp,nk;
	
	double *R,*S,*priors;
	double alpha,beta,sigmar,S0,h,R0,rho;
	double pival1, pival2, acp[1];
	double dummy1,res,snew,hnew,anew,bnew;
	double accpt, uvar;
	double svar = REAL(Rmvar)[0];
	double hvar = REAL(Rmvar)[1];

	PROTECT(Rlist = NEW_LIST(nc));

	/* data */

	R = REAL(Rrec);
	S = REAL(Rssb);
	priors = REAL(Rpriors);
	rho = REAL(Rrho)[0];

	/* chains */
	for (c=0;c<nc;c++) {

		acp[0]=0.;
		ntemp = (int)(ni/nt);
		nk=0;
		PROTECT(Rval = allocMatrix(REALSXP, ntemp, nj));

		/* initialize chain */
	
		for (;;) {
			S0 = REAL(Rinit)[0] + rnorm(0,1);
			h = REAL(Rinit)[1] + rnorm(0,0.001);
			sigmar = REAL(Rinit)[2] + rnorm(0,0.01);
			if (S0 > 0. && h > 0.2 && h < 1. && sigmar > 0.) break;
		}
	
		/* chain */
		
		for (i=0; i<ni+nb; i++) {

	  	/* define the values of alpha and beta */

	  	R0=S0/rho;
	  	if(h > 1.0) h = 1.0;
	  	if(h > 0.2) {
			alpha=4.*h*R0/(5.*h-1.);
			beta=S0*(1.-h)/(5.*h-1.);
		} else {
			alpha=0.0;
			beta=TINY;
		}
	  
	  	/* update (S0,h) using Metropolis-Hastings */
	  
	  	for(;;) {
			snew = S0 + rnorm(0.0,sqrt(svar));
			hnew = h + rnorm(0.0,sqrt(hvar));
			if(snew > 0.0 && hnew > 0.2 && hnew < 1.0) break;
		}

		R0=snew/rho;
		if(hnew > 1.0) hnew = 1.0;
	  	if(hnew > 0.2) {
			anew=4.*hnew*R0/(5.*hnew-1.);
			bnew=snew*(1.-hnew)/(5.*hnew-1.);
		} else {
			anew=0.0;
			bnew=TINY;
		}
	  
	  	/* acceptance probability */

	  	pival1 = bhfunc(R,S,S0,h,alpha,beta,sigmar,rho,priors,T);
	  	pival2 = bhfunc(R,S,snew,hnew,anew,bnew,sigmar,rho,priors,T);
	  	accpt = pival2-pival1 < 0. ? pival2-pival1 : 0.;

	  	/* generate a random U[0,1] variate */

		uvar=log(runif(0.0,1.0));
		
		if(accpt > uvar) {
			if(i >= nb)
				acp[0]++;
			S0 = snew;
			h = hnew;
			alpha = anew;
			beta = bnew;
		}
	
		/* update the recruit variance 
		 * using the conditional posteriors
		*/

		res=0.;
		for(t=0;t<T;t++) res += 0.5*(log(R[t])-log(S[t])-log(alpha)+log(beta+S[t]))*(log(R[t])-log(S[t])-log(alpha)+log(beta+S[t]));
    		dummy1=rgamma(priors[4]+(double)T/2.0,priors[5]/(1.0+priors[5]*res));
		sigmar=1.0/dummy1;
	
		/* update the markov chain
		 * but only after burnin and for thinning! */
		if(i >= nb && i % nt == 0) {
			REAL(Rval)[nk + 0*ntemp] = S0;
			REAL(Rval)[nk + 1*ntemp] = h;
			REAL(Rval)[nk + 2*ntemp] = alpha;
			REAL(Rval)[nk + 3*ntemp] = beta;
			REAL(Rval)[nk + 4*ntemp] = sigmar;
			nk++;
		}
	}

	acp[0]/=(double)(ni);
	Rprintf("flBayes::bevholtBayes:\n");
	Rprintf("Acceptance probability for (S0,h) = %8.6f\n", acp[0]);

	SET_ELEMENT(Rlist, c, Rval);
	
	UNPROTECT(1);

	}

	PutRNGstate(); 

	UNPROTECT(1);

	return (Rlist);

} /* }}} */

/* double bhfunc(R, S, S0, h, alpha, beta, sigmar, rho, priors, T) {{{ */
double bhfunc(double R[],double S[],double S0,double h,double alpha,double beta,double sigmar,double rho,double priors[],int T)
{
  int t;
  double retval,lkhd,prior;

  /* calculate the likelihood */
  
  lkhd = -0.5*(double)T*log(2.*M_PI*sigmar);
  for(t=0;t<T;t++)
	  lkhd -= 1./(2.*sigmar)*(log(R[t])-log(S[t])-log(alpha)+log(beta+S[t]))*(log(R[t])-log(S[t])-log(alpha)+log(beta+S[t]));

  /* calculate the prior */

  prior = log(dlnorm(S0,priors[0],sqrt(priors[1]),FALSE));
  prior += log(beta_trunc(h,priors[2],priors[3])); 
  /* prior += log(uform(h,priors[2],priors[3])); */

  retval = lkhd + prior;

  return retval;
} /* }}} */
