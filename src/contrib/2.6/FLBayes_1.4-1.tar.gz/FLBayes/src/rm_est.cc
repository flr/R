// code for estimating rm from Pella-Tomlinson model
// using stock-recruit and life-history information
// ::
// Richard Hillary <r.hillary@imperial.ac.uk>, July 2006
//$Id: rm_est.cc,v 1.1 2006/07/04 10:14:58 rmh1977 Exp $

#include <R.h>
#include <Rdefines.h>
#include <Rinternals.h>
#include <Rmath.h>

double func(double,double,double,double);
double dfunc(double,double,double);

extern "C" SEXP rmest(SEXP Rm,SEXP Ram,SEXP Ralp,SEXP Rrho,SEXP Rinit) {

	int i,n,itmax=1000,nits=LENGTH(Rm);
	double x,xold,*am,*ps,*alp,*m,*rho,tol=1.0e-4;

	// data transfers
	
	m = REAL(Rm);
	am = REAL(Ram);
	alp = REAL(Ralp);
	rho = REAL(Rrho);
	ps = REAL(Rm);

	// R return stuff
	
	SEXP Rval = R_NilValue;

	PROTECT(Rval = allocVector(REALSXP, nits));

	for(n=0;n<nits;n++) {
		ps[n] = exp(-m[n]);
		alp[n] *= (1-ps[n])*rho[n];
	}

	for(n=0;n<nits;n++) {
		
		// Newton-Raphson loop to solve for rm

		x = exp(REAL(Rinit)[0]); 
		xold = x;
		for(i=1;i<=itmax;i++) {
		
			xold = x;
			x -= func(xold,am[n],ps[n],alp[n])/dfunc(xold,am[n],ps[n]);

			// convergence check
	
			if(fabs(x-xold) <= tol)
				break;
		
			if(i == itmax) 
				Rprintf("Maximum iterations reached\n");
		}

		if(x <= 0.)
			Rprintf("Error: estimated value of exp(rm) is negative!\n");
		else 
			REAL(Rval)[n] = log(x); 
	}

	UNPROTECT(1);

	return (Rval);
}

// functions

double func(double x,double am,double ps,double alp) {
	
	return pow(x,am)-ps*pow(x,double(am-1.))-alp;
}

double dfunc(double x,double am,double ps) {
	return am*pow(x,double(am-1.))-ps*(am-1.)*pow(x,double(am-2.));
}
