FLash
=====

The FLash package for fisheries forecasting

# WARNING!!

On the Windows OS this package will only install and run on the 32-bit version of R. If installing using

```
devtools::install_github('flr/FLash')
```

make sure you do so from 32-bit R.
