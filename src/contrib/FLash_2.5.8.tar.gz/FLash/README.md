FLash
=====

The FLash package for fisheries forecasting

# WARNING!!

On the Windows OS this package will only install and run on the 32-bit version of R. Please install using

```
devtools::install_github('flr/FLash', INSTALL_opts="--no-multiarch")
```

and make sure you do so from 32-bit R.
