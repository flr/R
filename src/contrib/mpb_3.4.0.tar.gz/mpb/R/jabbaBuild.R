jBuild=c("catch","cpue","se","assessment","scenario", "model.type", 
         "add.catch.CV","catch.cv","Plim","r.dist", "r.prior", "K.dist", 
         "K.prior", 
         "psi.dist", 
         "psi.prior", 
         "b.prior", 
         "bk",        
         "Fmsy","catch.metric") 
