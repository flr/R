source("../run.compare.R")
run.compare("mack")
