# FLAssess-methods - «Short one line description»

# Author: Laurie T. Kell, CEFAS
# Maintainer: Iago Mosqueira, AZTI Tecnalia
# Additions:
# Last Change: 27 Apr 2007 17:56
# $Id: FLAssess-methods.R,v 1.57.2.4 2007/04/27 16:01:48 imosqueira Exp $

# Reference:
# Notes:

# TODO mié 08 mar 2006 23:27:42 CET iagoazti: Adapt plot to lattice
# qapply for FLAssess

# summary   {{{
setMethod("summary", signature(object="FLAssess"),
    function(object, ...){
        cat("An object of class \"FLAssess\" with:\n\n")
        cat("Dimensions:\n")
        print(dimnames(object@stock.n))

    	if (any(getSlots(class(object))=="control")) {
        	cat("Control parameters:\n")
	    	  summary(object@control)
    	    }
	}
)   # }}}

# show     {{{
setMethod("show", signature(object="FLAssess"),
    function(object){
        slots <- getSlots(class(object))

        #main stuff
        print(object@desc)
        print(object@call)
          
        #FLQuants
        quants <- names(slots[slots=="FLQuant"])
    	for (i in quants)
    	{
        cat("\nSlot: ", i, "\n")
        print(slot(object,i))
      }
     
        not.quants<-names(slots[slots!="FLQuant"])
        remainder<-not.quants[!(not.quants%in%c("desc","call"))]
        for (i in remainder)
            if (length(slot(object,i))>0)
            {
                cat("\nSlot: ", i, "\n")
                print(slot(object,i))
            }
       }
)        # }}}

# plot   {{{
# }}}

# is.FLAssess   {{{
is.FLAssess <- function(x)
    return(inherits(x, "FLAssess")) # }}}

# trim   {{{
# }}}

## window   {{{
setMethod("window", signature(x="FLAssess"),
	  function(x, start, end, extend=TRUE, frequency=1) {

		names. <- names(getSlots(class(x))[getSlots(class(x))=="FLQuant"])

		for (s. in names.) {
       slot(x, s.) <- window(slot(x, s.), start=start, end=end,
		   extend=extend, frequency=frequency)
		}
		
    x@range["minyear"] <- start
		x@range["maxyear"] <- end

		return(x)
	}
)   # }}}

# units   {{{
setMethod("units", signature(x="FLAssess"), function(x) {
	
	names. <- names(getSlots(class(x))[getSlots(class(x))=="FLQuant"])
	res <- list()
	for(s. in names.)
    res <- as.list(c(unlist(res), assign(s., units(slot(x, s.)))))
  names(res) <- names.
  return(res)
})  #}}}

## units<-  {{{
setMethod("units<-", signature(x="FLAssess", value="list"),
    function(x, value) {
        for(i in seq(along=value))
            if(is.character(value[[i]]))
                units(slot(x, names(value[i]))) <- value[[i]]
        return(x)
	}
) # }}}

# iter   {{{
# }}}

# apply   {{{
# }}}

# transform   {{{
# }}}

# Accesors   {{{
# }}}

# update   {{{
# use a stock assessment to update n and f
if (!isGeneric("update")) {
    setGeneric("update", useAsDefault = update)
}
setMethod("update", signature(object="FLAssess"),
    function(object, stock, ...){

	if (missing(object) || !is(object, "FLAssess"))
		stop("object must be an FLAssess object")
	if (missing(stock) || !is(stock, "FLStock"))
    	stop("stock must be an FLStock object")

	#Check that age ranges in both object match
	dnXn <- dimnames(object@stock.n)
	dnSn <- dimnames(stock@stock.n)
	if (!all(dim(object@harvest) == dim(object@stock.n)))
    	stop("arrays stock.n and f must have same dimensions in object!")
    if (!isSubset(dnXn, dnSn))
        stop("Range in FLAssess is not a subset of range the stock FLStock!")
    if (!all(dnXn$year %in% dnSn$year))
        {
        stock<-trim(stock,ages=dims(t.@z)$minyear:dims(t.@z)$maxyear)
        #stop("Years in FLAssess is not a subset of years the stock FLStock!")
        }
    if (!all(dnXn$age == dnSn$age))
        {
        stock<-trim(stock,ages=dims(t.@z)$min:dims(t.@z)$max)
        #stop("Ages in FLAssess do not match those in FLStock!")
        }
        
  	# Create the updated stock FLStock
   	res <- stock
    res@desc <- paste(object@desc,
    	"- updated according to an FLAssess with desc:", object@desc)
    res@catch       <- doSubset(stock@catch, dnXn, do.subset.age=FALSE)
    res@catch.n     <- doSubset(stock@catch.n, dnXn)
    res@catch.wt    <- doSubset(stock@catch.wt, dnXn)
    res@discards    <- doSubset(stock@discards, dnXn, do.subset.age=FALSE)
    res@discards.n  <- doSubset(stock@discards.n, dnXn)
    res@discards.wt <- doSubset(stock@discards.wt, dnXn)
    res@landings    <- doSubset(stock@landings, dnXn, do.subset.age=FALSE)
    res@landings.n  <- doSubset(stock@landings.n, dnXn)
    res@landings.wt <- doSubset(stock@landings.wt, dnXn)

    res@mat         <- doSubset(stock@mat, dnXn)
    res@m           <- doSubset(stock@m, dnXn)
    res@stock.wt    <- doSubset(stock@stock.wt, dnXn)
    res@harvest.spwn<- doSubset(stock@harvest.spwn, dnXn)
    res@m.spwn      <- doSubset(stock@m.spwn, dnXn)

    # These are the updated fields
    res@stock.n <- object@stock.n
    if (is(object, "FLAssess")){
      	res@harvest <- object@harvest
        res@stock.n <- object@stock.n
        }

    # Range is set to the value in res@stock.n
    Par <- dims(res@stock.n)
    res@range <- unlist(list(min=Par$min, max=Par$max, plusgroup=Par$max,
        minyear=Par$minyear, maxyear=Par$maxyear))
    return(res)
    }
)   # }}}

# "+"      {{{
setMethod("+", signature(e1="FLStock",e2="FLAssess"),
	function(e1, e2) {
        return(update(e2,e1))
    }
)
setMethod("+", signature(e1="FLAssess",e2="FLStock"),
	function(e1, e2) {
        return(update(e1,e2))
    }
)   # }}}


# The NEW retro function.  Supercedes the old one.  Now returns FLStocks object
retro <- function(FLStock, FLIndices, control="missing", year.range="missing",retro=0){
# year.range is of form min:max, or vector of years e.g. c(1990, 1995) for assessment
# for years 1990 and 1995 only.
# Just a wrapper to call the assessment method with trimmed stocks / indices
# ---------- Checks ----------------------
  if (!inherits(FLStock, "FLStock"))
    stop("FLStock must be an 'FLStock' object!")
  if (!validObject(FLStock))
    stop("FLStock is not a valid object!")
  if (!inherits(FLIndices, "FLIndices"))
    stop("FLIndices must be an 'FLIndices' object!")
  if (!validObject(FLIndices))
    stop("FLIndices is not a valid object!")
  # Check we have at least a usable retro or years.range
  if ((missing(year.range) || !is.numeric(year.range)) && (!is.numeric(retro) || retro < 0 || is.na(retro) || length(retro) > 1))
    stop("'retro' must be a non-negative integer or 'year.range' must be a numeric vector")
  # ------------ Sort out retrospective years ------------
  minyear <- FLStock@range["minyear"]
  maxyear <- FLStock@range["maxyear"]
  if(missing(year.range))
    year.range <- (maxyear-retro):maxyear
  #cat("year.range: ", year.range, "\n")
  # Check year.range is sensible
  if(min(year.range) < minyear || max(year.range) > maxyear)
    stop("Year range outside stock object range")
  # ---------- Run that retrospective! -------------
  cat("I am very pleased to run this retrospective for you...\n")
  Indices.temp<-FLIndices
  res <- new("FLStocks")
  counter<-0
  for (i in year.range)
  {
    counter<-counter+1
    Stock <- trim(FLStock, year=minyear:i)
    for (j in 1:length(FLIndices))
    {
      min.yr <- min(as.numeric(dimnames(FLIndices[[j]]@index)$year))
      max.yr <- max(as.numeric(dimnames(FLIndices[[j]]@index)$year))
      if (i < min.yr) stop("year.range is outside indices year range")
      Indices.temp[[j]] <- trim(FLIndices[[j]],year=min.yr:(min(max.yr,i)))
    }
    assess.        <- assess(control, Stock, Indices.temp)
    Stock <- Stock + assess.
    Stock@name <- paste(Stock@name, " Retrospective analysis for ", i,sep="")
    res[[as.character(i)]] <- Stock
  }
  res@desc   <-paste("Retrospective analysis from object", FLStock@desc)
  return(res)
}

## Plots the retrospective
plot.retro<-function(obj,yrs="missing",fbar.range="missing",main="")
{
  if ( is(obj,"FLStock"))  obj<-FLStocks(obj)
  if (!is(obj,"FLStocks")) stop("object must be either an FLStock or FLStocks object")

  if (missing(fbar.range)) fbar.range <- c(max(unlist(lapply(obj,function(x) slot(x,"range")["min"]))),
                                             min(unlist(lapply(obj,function(x) slot(x,"range")["max"]))))

  maxyear <- max(unlist(lapply(obj,function(x) slot(x,"range")["maxyear"])))
  if (missing(yrs))      yrs<-obj[[1]]@range["minyear"]:maxyear
  if (is.character(yrs)) yrs<-as.numeric(yrs)

  newobj <- lapply(obj,function(x) window(x,start=yrs[1],end=yrs[length(yrs)]))
  # Make the dataframe
  measures <- c("ssb","r","fbar","yield")
  res = data.frame("stock" = rep(1:length(newobj),each=length(yrs),times=length(measures)),
                      "year" = rep(yrs,times=length(newobj) * length(measures)),
                      type = rep(measures,each= length(newobj) * length(yrs)),
                      val = NA)

  res[res$type=="ssb","val"] <- unlist(lapply(newobj,ssb))
  res[res$type=="r","val"] <- unlist(lapply(newobj, function(x) slot(x,"stock.n")[1,]))
  res[res$type=="fbar","val"] <- unlist(lapply(newobj, function(x) apply(slot(x,"harvest")[fbar.range[1]:fbar.range[2],],2,mean)))
  res[res$type=="yield","val"] <- unlist(lapply(newobj,computeCatch))
  res[res$val==0 & !is.na(res$val),] <- NA

# just get max here, not range
  ylim.r <- c(0,ceiling(max(res[res[,"type"]=="r",    "val"],na.rm=T)))
  ylim.ssb <- c(0,ceiling(max(res[res[,"type"]=="ssb",    "val"],na.rm=T)))
  ylim.yield <- c(0,ceiling(max(res[res[,"type"]=="yield",    "val"],na.rm=T)))
  ylim.f <- c(0,ceiling(max(res[res[,"type"]=="fbar",    "val"],na.rm=T)))
  ylim=list(ylim.f,ylim.r,ylim.ssb,ylim.yield)

  xyplot(val~year|type, groups=res[,1],data=res, col=1:4,type="l",scales="free",ylim=ylim,main=main)
}


# The OLD reto function.  Returns an FLAssess.class.  To be binned.  DO NOT USE
retro.old <- function(FLStock, FLIndices, control="missing", retro=0, fbar=c(min=as.integer(NA),max=as.integer(NA))){
      if (!inherits(FLStock, "FLStock"))
            stop("FLStock must be an 'FLStock' object!")
      if (!validObject(FLStock))
            stop("FLStock is not a valid object!")
      if (!inherits(FLIndices, "FLIndices"))
            stop("FLIndices must be an 'FLIndices' object!")
      if (!validObject(FLIndices))
            stop("FLIndices is not a valid object!")
 #     if (!inherits(control, "FLAssess.control"))
 #           stop("control must be an 'FLAssess.control' object!")
 #     if (!validObject(control))
 #           stop("control is not a valid FLAssess.control object!")
      if (!is.numeric(retro) || retro[1] < 0)
            stop("retro must be a positive integer")

      if (!("min" %in% names(fbar))) fbar["min"] = FLStock@range["min"]
      else if (is.na(fbar["min"]))   fbar["min"] = FLStock@range["min"]
      if (!("max" %in% names(fbar))) fbar["max"] = FLStock@range["max"]
      else if (is.na(fbar["max"]))   fbar["max"] = FLStock@range["max"]

      fbar["min"] = max(fbar["min"],FLStock@range["min"])
      fbar["max"] = min(fbar["max"],FLStock@range["max"])

      retro <- as.integer(retro[1])
      minyear <- FLStock@range["minyear"]
      maxyear <- FLStock@range["maxyear"]
      res <- new("FLAssess.retro")

      FLIndices.in <- FLIndices      
      
      for (i in ((maxyear-retro):maxyear)){
	  	   Stock <- trim(FLStock, year=minyear:i)
         FLStock@range["maxyear"] <- i

  		   for (j in 1:length(FLIndices.in)) {
  		       min.yr <- min(as.numeric(dimnames(FLIndices.in[[j]]@index)$year))
  		       max.yr <- max(as.numeric(dimnames(FLIndices.in[[j]]@index)$year))
             FLIndices[[j]] <- trim(FLIndices.in[[j]],year=min.yr:(min(max.yr,i)))
          }                

          assess.        <- assess(control, Stock, FLIndices)
          if(length(dim(assess.@catch.n))==6){  
            assess.@stock.n <- convert6d(assess.@stock.n)
            assess.@harvest <- convert6d(assess.@harvest) 
          }      
          if (is(assess.@stock.n,"FLQuant"))
             Stock@stock.n <-assess.@stock.n
          if (is(assess.@harvest,"FLQuant"))
             Stock@harvest <-assess.@harvest
             
          res@harvest[[maxyear-i+1]] <-apply(assess.@harvest[as.character(fbar["min"]:fbar["max"]),],2,mean)
          names(res@harvest)[maxyear-i+1] <- i
          if(length(dim(assess.@stock.n))==6){
            res@ssb[[maxyear-i+1]]      <-ssb(Stock)[1, ,1,1,1,1]
            names(res@ssb)[maxyear-i+1] <- i
            res@recruits[[maxyear-i+1]] <-assess.@stock.n[1, ,1,1,1,1]   
            names(res@recruits)[maxyear-i+1] <- i
          } 
          if(length(dim(assess.@stock.n))==5){
            res@ssb[[maxyear-i+1]]      <-ssb(Stock)[1, ,1,1,1]
            names(res@ssb)[maxyear-i+1] <- i
            res@recruits[[maxyear-i+1]] <-assess.@stock.n[1, ,1,1,1]   
            names(res@recruits)[maxyear-i+1] <- i
          }  
      }
         
      res@desc   <-paste("Retrospective for",FLStock@desc)
      res
}   # }}}

# is.FLAsses.retro      {{{
is.FLAssess.retro <- function(x)
      return(inherits(x, "FLAssess.retro")) # }}}

# plot  FLAssess.retro  {{{
setMethod('plot', signature(x='FLAssess.retro', y='missing'),
    function(x, y, ...) {
        maxyear <- max(unlist(lapply(x@ssb, function(x) dims(x)$maxyear)))
        minyear <- min(unlist(lapply(x@ssb, function(x) dims(x)$maxyear)))
        firstyear <- min(unlist(lapply(x@ssb, function(x) dims(x)$minyear)))

        xyplot(data~year|slot, data=as.data.frame(window(x, max(minyear-4, firstyear),
            maxyear)), groups=qname, scales=list(relation='free'), ylab='', type='b',
            xlab='', strip=strip.custom(factor.levels=c('recruits',
            paste('SSB (', units(x@ssb[[1]]),')', sep=''),
            paste('harvest (', units(x@harvest[[1]]),')', sep=''))), as.table=TRUE, ...)
    }
)   # }}}

# as.data.frame FLAssess.retro  {{{
setMethod('as.data.frame', signature('FLAssess.retro'),
    function(x, row.names=NULL, optional=FALSE){
        rbind(
            cbind(data.list(x@recruits), slot='recruits'),
            cbind(data.list(x@ssb), slot='ssb')[1:10,],
            cbind(data.list(x@harvest), slot='harvest'))
    }
)   # }}}

# window FLAssess.retro {{{
setMethod('window', signature('FLAssess.retro'),
    function(x, start, end, ...){
        x@ssb <- FLQuants(lapply(x@ssb, window, start=start, end=end))
        x@recruits <- FLQuants(lapply(x@recruits, window, start=start, end=end))
        x@harvest <- FLQuants(lapply(x@harvest, window, start=start, end=end))
        return(x)
    }
)   # }}}

# plots    {{{
setMethod("plot", signature(x="FLAssess", y="missing"),
     function(x, y,type=c("recruits","ssb","f"),...){
      lenIndex<- length(x@index)
      dimNameNames <- names(dimnames(x@index[[1]]))
    
      dfa <- as.data.frame(sweep(x@index[[1]],1,apply(x@index[[1]],  1,mean,na.rm=T),"/"))
      names(dfa)[names(dfa)=="data"]<- "index1"
    
      if (lenIndex > 1) for (li in 2:lenIndex){
        dft <- as.data.frame( sweep(x@index[[li]],1,apply(x@index[[li]],  1,mean,na.rm=T),"/"))
        names(dft)[names(dft)=="data"]<- paste("index",li,sep="")
        dfa <- merge(dfa,dft, by=dimNameNames, all=T)
      }
    
      winstock.n <- window(x@stock.n,min(dfa$year),max(dfa$year))
      dfa <- merge(dfa,as.data.frame( sweep(winstock.n,1,apply(winstock.n,  1,mean,na.rm=T),"/")), by=dimNameNames, all.L=T)
      dfa$age <- as.factor(dfa$age)
    
	# formula 
	names(dfa)[-c(1:5)]->lnames
	lform <- strsplit(lnames, split=" ")
	lform$sep <- "+"
	lform <- do.call("paste", lform)
	lform
	rform <- "year|age"
	x <- as.formula(paste(lform, rform, sep="~"))
    xyplot(x,data=dfa,
             xlab="Age", ylab="normalised index",
             type=c(rep("p",lenIndex),"l"),lty=c(rep(0,lenIndex),1),pch=c(1,1,1,1),cex=c(rep(1,lenIndex),0))
})
# }}}

# assess (generic only)   {{{
# Run assess
if (!isGeneric("assess")) {
	setGeneric("assess", function(control, ...){
    	value <- standardGeneric("assess")
        value
    })
}
   # }}}

# outerFLQuants     {{{
outerFLQuants<-function(object)
  {
  #if (!is(object,"FLQuants")) stop("must be an FLQuants object")
  if (!is(object,"list")) stop("object must be a list")
  if (!all(unlist(lapply(object,class))=="FLQuant")) stop("objects in list must be of type FLQuant")
  
  res<-unlist(lapply(object,dimnames))
  
  res<-FLQuant(NA,  dimnames=list(age   =unique(sort(res[substr(names(res),1,3)=="age"])),
                                  year  =unique(sort(res[substr(names(res),1,4)=="year"])),
                                  unit  =unique(sort(res[substr(names(res),1,4)=="unit"])),
                                  season=unique(sort(res[substr(names(res),1,6)=="season"])),
                                  area  =unique(sort(res[substr(names(res),1,4)=="area"]))))
                                  
  returnObj<-new("FLQuants")
  
  for (i in (1:length(object)))
      {                  
      returnObj[[i]]<-res                              
   
      returnObj[[i]][dimnames(object[[i]])$age,
                     dimnames(object[[i]])$year,
                     dimnames(object[[i]])$unit,
                     dimnames(object[[i]])$season,
                     dimnames(object[[i]])$area]<-object[[i]][,,,,]                              
      }               
  
  return(FLQuants(returnObj))
}   # }}}

# correctIndex  {{{
correctIndex<-function(FLIndex,harvest,m)
   { 
   ##Equation (3) VPA User Guide
   startf <-min(1.0,max(0.0,FLIndex@range["startf"]))
   endf   <-min(1.0,max(0.0,FLIndex@range["endf"]))
   
   if (startf == 0.0 & endf == 0.0)
      return(FLIndex)
      
   if (startf == endf)
      endf <- endf + 0.00001

   dmns <- dimnames(ple4.cpue[[1]]@index)
      
   Z                       <- m[      dmns$age,dmns$year,dmns$unit,dmns$season,dmns$area]+
                              harvest[dmns$age,dmns$year,dmns$unit,dmns$season,dmns$area]                   
   FLIndex@index           <- FLIndex@index/(exp(-startf*Z) - exp(-endf*Z))/((endf-startf)*Z)
   FLIndex@range["startf"] <- startf
   FLIndex@range["endf"]   <- endf
   
   return(FLIndex)
   }    # }}}

# Internal functions   {{{
window.cpue<-function(obj, retro.year)
	  {
	  slots.<-getSlots("FLIndex")
	  obj@range["maxyear"]<-retro.year
	
	  yrs<-as.character(dims(obj)$minyear:retro.year)
	  yrs<-yrs[yrs%in%dimnames(obj@index)$year]
	  obj@range[c("minyear","maxyear")]<-range(as.integer(yrs))
	  for (i in names(slots.[slots.=="FLQuant"]))
	      slot(obj,i)<-slot(obj,i)[,yrs,,,]
	      
	  return(obj)
	  }

    
    #local function
    # isSubset
    # Check that dims in X match those in Y
    isSubset <- function(dnX, dnY) {
    	# We consider here that we have five dimensions, like in usual FLQuant FLStocks
    	if (!all(dnX$age    %in% dnY$age)) return(FALSE)
    	if (!all(dnX$year   %in% dnY$year)) return(FALSE)
      if (!all(dnX$unit   %in% dnY$unit)) return(FALSE)
      if (!all(dnX$season %in% dnY$season)) return(FALSE)
      if (!all(dnX$area   %in% dnY$area)) return(FALSE)
        return(TRUE)
    }

    # doSubset
    # We now subset the FLStock according to dimensions in the object
    doSubset <- function(Quant, Dimnames, do.subset.age=TRUE) {
    	# We subset an FLQuant FLStock according to Dimnames
        # (supposed to ba a strict subset tested with isSubset())
        if (do.subset.age) {
        	res <- as.FLQuant(Quant[Dimnames$age, Dimnames$year,
            	Dimnames$unit, Dimnames$season, Dimnames$area, drop=FALSE])
         } else {
         	res <- as.FLQuant(Quant[, Dimnames$year,
            	Dimnames$unit, Dimnames$season, Dimnames$area, drop=FALSE])
         }
         	res
    }   # }}} 

# no.discards   {{{
if (!isGeneric("no.discards")) {
	setGeneric("no.discards", function(obj, ...){
		value  <-  standardGeneric("no.discards")
		value
	})
}

setMethod("no.discards",signature("FLStock"),
   	function(obj, ...) {
      obj@discards   <- FLQuant(0,dimnames=dimnames(obj@discards))
      obj@discards.n <- FLQuant(0,dimnames=dimnames(obj@discards.n))
      obj@discards.wt<- FLQuant(0,dimnames=dimnames(obj@discards.wt))
      obj@catch      <- obj@landings
      obj@catch.n    <- obj@landings.n
      obj@catch.wt   <- obj@landings.wt
  
      return(obj)
      })    # }}}
  
project <-function(obj,catch.sel="missing",discards.sel="missing",fmult="missing",sr.model="missing",sr.param="missing"){
     ## check that obj is of type FLStock and valid

     ## check that catch.sel, discards.sel and fmult are for valid years etc.

     ## check SRR

     year              <-dimnames(catch.sel)$year
     pg                <-dims(obj@stock.n)[[1]]
     harvest           <-fmult*catch.sel@.Data[,year]

     stock.n           <-obj@stock.n@.Data[,year]
     Z                 <-harvest+obj@m@.Data[,year]
     expZ              <-exp(Z)

     for (iyr in as.integer(year)[-length(year)])
        {
        stock.n[1, as.character(iyr+1)] <-recruits(ssb(obj)[,as.character(max(iyr,obj@range["minyear"]))],sr.model,sr.param)

        stock.n[-1,as.character(iyr+1)] <-obj@stock.n[-pg,as.character(iyr)]*expZ[-pg,as.character(iyr)]
        stock.n[pg,as.character(iyr+1)] <-obj@stock.n[pg,as.character(iyr+1)]
                                         +obj@stock.n[pg,as.character(iyr)]*expZ[pg,as.character(iyr)]
                                         -obj@m[pg,as.character(iyr)]
        }

     obj@stock.n@.Data[,year,,,,] <-stock.n[,year]
     obj@catch.n@.Data[,year,,,,] <-stock.n[,year]*harvest*(1.0-expZ)/Z
     obj@harvest@.Data[,year,,,,] <-as.FLQuant(harvest)
     catch.n                <-as.FLQuant(NA,dimnames=dimnames(stock.n))
     discards.n             <-as.FLQuant(NA,dimnames=dimnames(stock.n))

     if (!missing(discards.sel))
        {
        discards.n <-catch.n*discards.sel/catch.sel
        landings.n <-catch.n-discards.n

        obj@discards.n[,year,,,,]<-as.FLQuant(discards.n)
        obj@landings.n[,year,,,,]<-as.FLQuant(landings.n)
        }

     return(obj)
     }

BiolToStock <- function(biol)
{
  if (!is(biol, "FLBiol"))
    stop("Object must be an 'FLBiol' object")
  stock <- FLStock(iniFLQuant = biol@m)
  stock@name <- biol@name
  stock@range <- biol@range
  stock@desc <- biol@desc
  stock@stock.n <- biol@n
  stock@m <- biol@m
  stock@stock.wt <- biol@wt
  stock@mat <- biol@fec
  stock@m.spwn <- biol@spwn
  stock@harvest[] <- 0
  units(stock@harvest) <- "f"
  return(stock)
}

StockToBiol <- function(stock)
{
  if (!is(stock, "FLStock"))
    stop("Object must be an 'FLStock' object")
  biol <- FLBiol(iniFLQuant = stock@m)
  biol@name <- stock@name
  biol@range <- stock@range
  biol@desc <- stock@desc
  biol@n <- stock@stock.n
  biol@m <- stock@m
  biol@wt <- stock@stock.wt
  biol@fec <- stock@mat
  biol@spwn <- stock@m.spwn
  return(biol)
}

## stf :: Generic           {{{
if (!isGeneric("stf")) {
    setGeneric("stf", function(object, ...){
	    value <- standardGeneric("stf")
	    value
    })
}

# stf for FLBiol objects
setMethod("stf", signature(object="FLBiol"),
function(object,nyrs=3,wts.nyrs=3,arith.mn=TRUE, na.rm=TRUE)
{
  res<- stf(BiolToStock(object),nyrs=nyrs,wts.nyrs=wts.nyrs,arith.mn=arith.mn, na.rm=na.rm)
  return(StockToBiol(res))
}
)

## stf in FLStock objects
setMethod("stf", signature(object="FLStock"),
function(object,nyrs=3,wts.nyrs=3,f.nyrs=NA,disc.nyrs=NA,arith.mn=TRUE, na.rm=TRUE)
{
  # Works for 5D and 6D
  if (is.na(f.nyrs)) f.nyrs <- wts.nyrs
  if (is.na(disc.nyrs)) disc.nyrs <- wts.nyrs
  # Object checks
  if (!is(object, "FLStock"))
  stop("Object must be an 'FLStock' object")
  Dim <- dim(object@m)
  if (Dim[4]!=1) return("Not yet implemented for multiple seasons")
  if (Dim[5]!=1) return("Not yet implemented for multiple areas")
  if (Dim[3]>2) return("Not yet implemented for more than two units")

  # ----------- Set up new object -------------------

  fc.years <- as.character((object@range["maxyear"]+1):(object@range["maxyear"]+nyrs))
  weights.years <- as.character((object@range["maxyear"]-wts.nyrs+1):object@range["maxyear"])
  f.years <- as.character((object@range["maxyear"]-f.nyrs+1):object@range["maxyear"])
  disc.years <- as.character((object@range["maxyear"]-disc.nyrs+1):object@range["maxyear"])

  # The new object
  res <- window(object,start=object@range["minyear"],end=(object@range["maxyear"]+nyrs))
  res@desc    <- paste("Original data source: ", object@desc, ". Forecast for", nyrs, "years")

  # ------------ and fill in slots ---------------------

  # Weights, mat, m and swpn slots as mean of last wts.nyrs years
  weight.slots <- c("mat","m","harvest.spwn","m.spwn","discards.wt","catch.wt","landings.wt","stock.wt")
  for (slot.count in weight.slots)
    slot(res,slot.count) <- meanQuantYear(slot(res,slot.count),weights.years,fc.years,arith.mn,na.rm)

  # Harvest - just calc mean of last f.nyrs - no rescaling or anything funky
  res@harvest <- meanQuantYear(res@harvest,f.years,fc.years,arith.mn,na.rm)

  # Landings and discards - future proportions based on mean of previous proportions
  res@discards.n <- meanQuantYear(res@discards.n / (res@discards.n+res@landings.n), disc.years,fc.years,arith.mn,na.rm)
  res@landings.n[,fc.years] <- 1 - res@discards.n[,fc.years]

  return(res)
  }
)

# Calcs mean over the mean.yrs range and sticks the results in all years of the new.years range
meanQuantYear <- function(object,mean.years,new.years,arith.mn=FALSE,na.rm=TRUE)
{
  # Object is a 5 or 6D quant
  mean.years<-as.character(mean.years)
  new.years<-as.character(new.years)
  app.dims <- (1:length(dim(object)))[-2] # e.g 1,3,4,5,6
  # Make all new years values = 0 - clumsy method but whatever....
  object[,new.years]<-0.0
  if (arith.mn==FALSE)
    mean.bit <-  exp(apply(log(object[,mean.years]),app.dims,mean,na.rm=na.rm))
  else
    mean.bit <-  apply(object[,mean.years],app.dims,mean,na.rm=na.rm)
  object[,new.years] <- sweep(object[,new.years],app.dims,mean.bit,"+")
  return(object)
}

## fwd      {{{
if (!isGeneric("fwd")) {
    setGeneric("fwd", function(object, ...){
	    value <- standardGeneric("fwd")
	    value
    })
}


# fwd for FLBiol objects
setMethod("fwd", signature(object="FLBiol"),
function(object,year,sr.model="missing",sr.param="missing",sr.residuals=1.0,sr.residuals.mult=TRUE)
{
  res<- fwd(BiolToStock(object), year, sr.model, sr.param, sr.residuals, sr.residuals.mult)
  return(StockToBiol(res))
}
)

## fwd in FLAssess
setMethod("fwd", signature(object="FLStock"),
function(object,year,sr.model="missing",sr.param="missing",sr.residuals=1.0,sr.residuals.mult=TRUE)
{

  year<-as.character(year)
  # Object checks
  if (!is(object, "FLStock"))
    stop("FLStock must be an 'FLStock' object")

  if(object@range["maxyear"] < max(as.integer(year)))
    stop("Maximum projection year > Maximum year of stock object")
  if(length(sr.residuals) > length(year))
    warning("More residuals supplied than number of years")
  if (missing(sr.model) || missing(sr.param)  || sr.model=="missing" || sr.param=="missing")
  {
    sr.model     <- "mean"
    sr.param     <- 1.0
    sr.residuals <- object@stock.n[1,]
  }

  # make sure that sr.residuals are right length - just repeated if too short
  sr.residuals <- rep(sr.residuals,length.out=length(year))
  names(sr.residuals)<-year

  #------- Start projecting -----------
  Dim <- dim(object@m)
  for (iyr in year)
  {
#    cat("Projection year: ", iyr,"\n")
    # If not fitting for catch for any iteration, just run projection - good for 5D and 6D - fastish
    if (all(is.na(object@catch[,iyr])))
      object<-fwd.fmult(object,iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult)

    # Otherwise fit for catch - check each iteration in turn - v. slow
    else
    {
      if (Dim[4]!=1 || Dim[4]!=1 || Dim[5]!=1) return("Harvest fitting function not yet implemented for multiple units, areas or seasons")
      # 5D
      if (length(dim(object@m)) == 5)
        object <- fwd.fit(object,iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult)
      else
       # 6D
        for (i in  1:length(dimnames(object@m)$iter))
        {
#          cat("Iteration: ", i, "\n")
            if (!is.na(iter(object@catch[,iyr],i))) # is there a catch to fit?
              res<-fwd.fit(iter(object,i),iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult)
            else res <- fwd.fmult(iter(object,i),iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult) # if no catch
            # load projections into object iteration
            for (s in c("stock.n","catch.n","harvest"))
              slot(object, s)[,,,,,i] <-slot(res, s)
        }
    }
  }
  # ----------  Finish up -----------------

  app.dim <- 2:length(Dim)
  object@catch <- apply(object@catch.n*object@catch.wt,app.dim,sum)
  # Check if landings.n and discards.n are given as proportions, if so calc the actual numbers
  if (all(object@landings.n[,year]<=1) && all(object@discards.n[,year]<=1)
      && all(!is.na(object@landings.n[,year])) && all(!is.na(object@discards.n[,year])))
  {
    object@landings.n[,year] <- object@landings.n[,year] * object@catch.n[,year]
    object@discards.n[,year] <- object@discards.n[,year] * object@catch.n[,year]
  }
  object@discards <- apply(object@discards.n*object@discards.wt,app.dim,sum)
  object@landings <- apply(object@landings.n*object@landings.wt,app.dim,sum)
  object@stock <- apply(object@stock.n*object@stock.wt,app.dim,sum)
  return(object)
}
)

fwd.fit<-function(object,iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult)
{
  # Fitting fmult in iyr to give desired catch
  # Object is single iteration of stock
  # check that catch.constraint >= 0 (max catch is checked below)
  if (object@catch[,iyr]<0.0)
    stop("catch.constraint -ve")
  # find F range that brackets catch.constraint
  Iter <-0
  ini.fmult <- 0.05
  fmult <- ini.fmult
  fmult.factor <- 2.0
  sel  <- object@harvest[,iyr]
  repeat
  {
    Iter <- Iter+1
    fmult <- fmult * fmult.factor
    object@harvest[,iyr] <- sel*fmult
    object<-fwd.fmult(object,iyr,sr.model,sr.param,sr.residuals[as.character(iyr)],sr.residuals.mult)
    if (apply(object@catch.n[,iyr]*object@catch.wt[,iyr],2,sum) > object@catch[,iyr]) break
    if (Iter >= 100) stop("catch hat > max possible catch") # too many iterations
  }
  ## Function to optimise
  object.catch<-function(x,object,sel,iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult)
  {
    object@harvest[,iyr] <- sel*x
    object               <-fwd.fmult(object,iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult)
    return(as.double((object@catch[,iyr]-apply(object@catch.n[,iyr]*object@catch.wt[,iyr],2,sum))^2)) # Squared difference
  }
  fmult<-optimise(object.catch,c(ifelse(fmult==(ini.fmult*fmult.factor),0,fmult/fmult.factor),fmult),object=object,sel=sel,iyr=iyr,sr.model=sr.model,sr.param=sr.param,sr.residuals=sr.residuals[as.character(iyr)],sr.residuals.mult=sr.residuals.mult, maximum=FALSE, tol=.Machine$double.eps^0.5)$minimum
  object@harvest[,iyr] <-sel*fmult
  object               <-fwd.fmult(object,iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult)
  return(object)
}

## one year F projection - good for 5D, 6D and multisex
fwd.fmult <-function(obj,iyr,sr.model,sr.param,sr.residuals,sr.residuals.mult)
{
  iyr <- as.character(iyr) # the year you are projecting to, based on previous years harvest and stock
  nages<-dims(obj@harvest)$age
  yrs   <-as.character((as.integer(iyr)-1):as.integer(iyr))
  Z     <-obj@harvest[,yrs]+obj@m[,yrs]

  # Update stock - including plus group if required
  obj@stock.n[2:nages,iyr] <- (obj@stock.n[,yrs[1]]*exp(-Z[,yrs[1]]))[-nages]
  if (!is.na(obj@range["plusgroup"]))
    obj@stock.n[nages,iyr] <- obj@stock.n[nages,iyr] + obj@stock.n[nages,yrs[1]]*exp(-Z[nages,yrs[1]])

  # Get recruitment
  obj@stock.n[ 1,iyr]<-recruits(ssb(obj)[,iyr],sr.model,sr.param)
  if (sr.residuals.mult)
    obj@stock.n[ 1,iyr]<-obj@stock.n[ 1,iyr]*sr.residuals[iyr]
  else
    obj@stock.n[ 1,iyr]<-obj@stock.n[ 1,iyr]+sr.residuals[iyr]
  # Get catch - remove zeros first...
  obj@catch.n[obj@catch.n[]==0] <-0.01
  obj@catch.n[,iyr] <- obj@stock.n[,iyr]*obj@harvest[,iyr]/Z[,iyr]*(1.0-exp(-Z[,iyr]))
  return(obj)
}

## Function for recruitment
recruits<-function(ssb,sr.model,sr.param){
  res<-switch(tolower(sr.model),
    "mean"      = sr.param[1],
    "bevholt"   = sr.param["alpha"] * ssb / (ssb + sr.param["beta"]),
    "ricker"    = sr.param["alpha"] * ssb * exp(-sr.param["beta"] * ssb),
    "qhstk"     = ifelse(ssb <= sr.param["beta"]*(1-sr.param["rho"]), sr.param["alpha"]*ssb,
                  ifelse(ssb < sr.param["beta"]*(1 + sr.param["rho"]),
                    sr.param["alpha"]*(ssb-(ssb-sr.param["beta"]*(1-sr.param["rho"]))*
                    (ssb-sr.param["beta"]*(1-sr.param["rho"]))/(as.double(4)*sr.param["beta"]*sr.param["rho"])),
                    sr.param["alpha"]*sr.param["beta"])),
    "shepherd"  =pow((SPR-param["alpha"])/param["beta"], 1/(Param[3]+1)),
                 cat("sr.model must be 'mean', 'bevholt', 'ricker' 'shepherd' or 'qhstk'!\n")
  )
  return(as.numeric(res))
}

# FORWARD VALIDATION
fwd.val<-function(stock, idx, control, yrs, recruits=as.numeric(1.0),known.sel=FALSE,known.wt=FALSE)
{
  # --------- Checks -----------------
  yrs <- as.character(yrs)
  # yrs must be included in stock
    if(!all(yrs %in% dimnames(stock@m)$year)) stop("Supplied 'yrs' are not in stock object")

  # ------------- Do stuff -----------------
  # Do retrospective assessment up to year before year range
  stock.retro <-retro(stock,idx,control,year.range=(as.numeric(yrs[1])-1))[[1]]
  ## set up projection based upon FLSTF assumptions
  stock.retro.proj     <-stf(stock.retro,nyrs=(length(yrs)))
  ## set catches in proj equal to reported catches
  stock.retro.proj@catch[,yrs]<-computeCatch(stock)[,yrs]
  ## set wts in proj equal to reported wts
  if (known.wt)
  {
    stock.retro.proj@catch.wt[,   yrs] <-stock@catch.wt[,   yrs]
    stock.retro.proj@discards.wt[,yrs] <-stock@discards.wt[,yrs]
    stock.retro.proj@landings.wt[,yrs] <-stock@landings.wt[,yrs]
    # What about stock.wt?
  }
   ## set selection pattern in proj equal to subsequent estimates and clear out catch
  if (known.sel)
  {
    stock.retro.proj@harvest[,   yrs]  <-stock@harvest[,   yrs]
    # Catch too? Leave line out for the moment. Up to user to set Catch slot to NA.
    # stock.retro.proj@catch[,   yrs] <- NA
    # Does this matter?  These probably get overwritten anyway.
    stock.retro.proj@discards.n[,yrs]  <-stock@discards.n[,yrs]
    stock.retro.proj@landings.n[,yrs]  <-stock@landings.n[,yrs]
  }
  # ---------  Project forward based on how recruitment is specified
  # (i.e. either a single number which becomes mean of SR, or range of values
  # which is then passed in as residuals) ----------------
  if (is.FLQuant(recruits))
  {
    if (!all(dimnames(recruits)$year %in% yrs)) stop("recruits by year don't match projection year")
    stock.fwd <-fwd(stock.retro.proj, year=yrs,sr.model="mean",sr.param=1.0,sr.residuals=recruits,sr.residuals.mult=TRUE)
  }
  if (!is.FLQuant(recruits))
  {
    if(is.numeric(recruits) && length(recruits)>1) stop("specify single value for recruitment")
    stock.fwd <-fwd(stock.retro.proj, year=yrs,sr.model="mean",sr.param=recruits,sr.residuals=1.0,sr.residuals.mult=TRUE)
  }
  return(stock.fwd)
}

# plot  FLAssess.retro  {{{
setMethod('plot', signature(x='FLAssess.retro', y='missing'),
    function(x, y, ...) {
        maxyear <- max(unlist(lapply(x@ssb, function(x) dims(x)$maxyear)))
        minyear <- min(unlist(lapply(x@ssb, function(x) dims(x)$maxyear)))
        firstyear <- min(unlist(lapply(x@ssb, function(x) dims(x)$minyear)))

        xyplot(data~year|slot, data=as.data.frame(window(x, max(minyear-4, firstyear),
            maxyear)), groups=qname, scales=list(relation='free'), ylab='', type='b',
            xlab='', strip=strip.custom(factor.levels=c('recruits',
            paste('SSB (', units(x@ssb[[1]]),')', sep=''),
            paste('harvest (', units(x@harvest[[1]]),')', sep=''))), as.table=TRUE, ...)
    }
)   # }}}

# as.data.frame FLAssess.retro  {{{
setMethod('as.data.frame', signature('FLAssess.retro'),
    function(x, row.names=NULL, optional=FALSE){
        rbind(
            cbind(data.list(x@recruits), slot='recruits'),
            cbind(data.list(x@ssb), slot='ssb')[1:10,],
            cbind(data.list(x@harvest), slot='harvest'))
    }
)   # }}}

# window FLAssess.retro {{{
setMethod('window', signature('FLAssess.retro'),
    function(x, start, end, ...){
        x@ssb <- FLQuants(lapply(x@ssb, window, start=start, end=end))
        x@recruits <- FLQuants(lapply(x@recruits, window, start=start, end=end))
        x@harvest <- FLQuants(lapply(x@harvest, window, start=start, end=end))
        return(x)
    }
)   # }}}


