# FLAssess - «Short one line description»

# Author: Iago Mosqueira, AZTI Tecnalia
# Maintainer: FLR Team 
# Additions:
# Last Change: 26 oct 2006 15:55
# $Id: FLAssess.R,v 1.2 2006/10/29 23:12:19 iagoazti Exp $

# Reference:
# Notes:

# TODO jue 26 oct 2006 13:16:30 CEST iagoazti:

library(FLAssess)

# Run a separable VPA

data(ple4)
ple4@range['plusgroup'] <- 15
ple4.sepvpa <- SepVPA(ple4, FLSepVPA.control(sep.age=5, sep.sel=0.75), ref.harvest=0.5)
