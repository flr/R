.onLoad <- function(lib,pkg) {
	require(methods)
	cat("FLEDA 1.4-3 - \"The Jackal's Associate\" \n")
}
