.onLoad <- function(lib,pkg) {
	require(methods)
	cat("FLCore 1.4-4 - \"Golden Jackal\" \n")
}
