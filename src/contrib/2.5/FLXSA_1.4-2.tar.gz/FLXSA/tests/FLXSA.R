# $Id: FLXSA.R,v 1.24 2006/10/29 23:11:59 iagoazti Exp $
### Routine for validation #####################################################
validate.xsa<-function(i,stock,indices,xsa.control,ref,maxit="missing"){
  ## i            run
  ## stock        FLStock object
  ## indices      FLIndices object
  ## xsa.control  data frame with all FLXSA.control options
  ## ica.ref      reference data sets from exe for comparison 

  ## replace catch.n with landings, explicitly assuming no discarding  and set plusgroup
  #stock   <-  no.discards(setPlusGroup(stock, xsa.control[i,"plusgroup"]))

  ## set FLXSA.control from 
  control <-  FLXSA.control(tol       =xsa.control[i,"tol"],       
                            maxit     =ifelse(missing(maxit),xsa.control[i,"maxit"],maxit),
                            min.nse   =xsa.control[i,"min.nse"],   
                            fse       =xsa.control[i,"fse"],       
                            rage      =xsa.control[i,"rage"],      
                            qage      =xsa.control[i,"qage"],      
                            shk.n     =as.logical(xsa.control[i,"shk.n"]),     
                            shk.f     =as.logical(xsa.control[i,"shk.f"]),     
                            shk.yrs   =xsa.control[i,"shk.yrs"],   
                            shk.ages  =xsa.control[i,"shk.ages"],  
                            window    =xsa.control[i,"window"],    
                            tsrange   =xsa.control[i,"tsrange"],   
                            tspower   =xsa.control[i,"tspower"])   

  ## run FLXSA
  xsa        <- FLXSA(stock, indices, control)

  ## put results into data frame
  flxsa.ref<-cbind(as.data.frame(xsa@stock.n)[,-(3:5)],as.data.frame(xsa@harvest)[,-(1:5)])
  names(flxsa.ref)<-c("age","year","fl.n","fl.f")

  ## merge with reference data set
  comp <- merge(flxsa.ref,ref[ref[,"key"]==i,])
  comp <- comp[comp[,"f"]>0 & comp[,"n"]>0,]

  ## compare FLICA to reference data set
  return(c(!any(abs(comp[,"f"]/comp[,"fl.f"]-1.0)>0.050),
           !any(abs(comp[,"n"]/comp[,"fl.n"]-1.0)>0.050)))
  }
### End Routine for validation #################################################

### Test data ##################################################################
library(FLXSA)

#data objects
data(cod4)
data(her4)
data(ple7a)
### End test data ##############################################################

### Run all tests ##############################################################
for (i in 1:16)
  if (!any(validate.xsa(i, cod4.stock,  cod4.indices,  cod4.xsa.control,  cod4.xsa.ref)))    
    print("error")

for (i in 1:16)
  if (!any(validate.xsa(i, her4.stock,  her4.indices,  her4.xsa.control,  her4.xsa.ref, maxit=25)))
    print("error")

for (i in 1:16)
  if (!any(validate.xsa(i, ple7a.stock, ple7a.indices, ple7a.xsa.control, ple7a.xsa.ref))) 
    print("error")
### End run all tests ##########################################################

#run XSA
cod4.xsa <-FLXSA(cod4.stock, cod4.indices)
her4.xsa <-FLXSA(her4.stock, her4.indices)
ple7a.xsa<-FLXSA(ple7a.stock,ple7a.indices)

#Retrospectives
#cod4.retro<-retro(cod4.stock, cod4.indices, FLXSA.control(), retro=2)
#her4.retro<-retro(her4.stock, her4.indices,retro=2)
#ple7a.retro<-retro(ple7a.stock,ple7a.indices,retro=2)
