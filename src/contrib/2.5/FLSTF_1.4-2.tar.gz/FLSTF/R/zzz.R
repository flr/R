.onLoad <- function(lib,pkg) {
#	ver. <- packageDescription("FLSTF")$Version
#	cat("FLSTF ",ver.," - \"Short-term forecast\" \n")
#	cat("FLSTF 1.4-1 - \"Short-term forecast\" \n")
}
