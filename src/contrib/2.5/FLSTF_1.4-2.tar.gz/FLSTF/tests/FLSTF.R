#################################################################
## test:  reading in data from a file                          ##
#################################################################


library(FLSTF)
data(ple4)

out.file <- "flstf.out"
write(paste("Results of FLSTF tests : ",date()), file=out.file)

# default 3 year forecast
ple4.stf.control <- FLSTF.control()
ple4.stf.control # returns summary of control object using the overwritten "show" method.
ple4.stf         <- FLSTF(ple4, ple4.stf.control) # creates new FLSTF object and runs forecast
ple4.stf@stock.n

# 10 year forecast
ple4.stf.control <- FLSTF.control(nyrs=10)
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ple4.stf@stock.n

# specify year range for gm recruitment estimate
ple4.stf.control <- FLSTF.control(rec.yrs=c(1990,2001))
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ple4.stf@stock.n

# Specify recruitment for the forecast years
ple4.stf.control <- FLSTF.control(nyrs=4, rec = c(200000,300000,400000,500000))
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ple4.stf@stock.n

# standard 3 year forecast with a catch constraint applied to the first forecast year
ple4.stf.control <- FLSTF.control(catch.constraint = 50000)
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ple4.stf@catch

# 4 year forecast with fixed recruitment for all years and an SSB constraint in the final year
ple4.stf.control <- FLSTF.control(rec = 400000,ssb.constraint = 300000)
ple4.stf         <- FLSTF(ple4, ple4.stf.control)
ssb(ple4.stf)
ple4.stf@stock.n

# Setting survivors using an FLQuant
ple4.stf.control <- FLSTF.control()
# randomly set survivors - not realistic - just for demonstration
survivors <- FLQuant(abs(rnorm(14,mean = 5000, sd = 1000)),dim=c(1,14,1,1,1))
ple4.stf <- FLSTF(ple4,ple4.stf.control,survivors = survivors)

# Setting survivors as a vector
ple4.stf.control <- FLSTF.control()
ple4.stf <- FLSTF(ple4,ple4.stf.control,survivors = rep(2000,14))
ple4.stf@stock.n

# Check FLSTF calculations against MFDP results (tolerance = 0.1%)

data(cod7a)

## Test 1
## Simple 3yr status quo projection

stf.control <- FLSTF.control(fbar.min=2, fbar.max=4, rec.yrs=c(1992,2002))
res.l <- numeric()
res.s <- numeric()
for(fm in seq(0.1,2,by=0.1)){
  stf.control@fmult <- c(1,fm,fm)
  stf <- FLSTF(cod7a, stf.control)
  res.l <- c(res.l, as.numeric(landings(stf)[,"2004"]))
  res.s <- c(res.s, as.numeric(ssb(stf)[,"2005"]))
}
# estimates of landngs in 2004 from equivalent MFDP run
obs.l <- c(730,1360,1905,2378,2788,3147,3460,3736,3978,4192,4382,4551,4702,4837,4959,5070,5169,5261,5344,5420)
write(!any((abs(obs.l-res.l)/obs.l*100)>0.1), out.file, append=T)

obs.s <- c(7776,6936,6212,5586,5044,4574,4165,3809,3497,3224,2984,2772,2585,2419,2271,2139,2021,1916,1820,1734)
!any((abs(obs.s-res.s)/obs.s*100)>0.1)

## Test 2
## Simple 3yr status quo projection with catch constraint of 5000t in 2003
## optimise function very slow therefore only test at Fmult of 1.0

stf.control <- FLSTF.control(fbar.min=2, fbar.max=4, rec.yrs=c(1992,2002),catch.constraint=5000)
stf <- FLSTF(cod7a, stf.control)

#MFDP results - landings 2004 and ssb 2005 for fmult 0.1 to 2.0
#obs.l <- c(971,1804,2520,3137,3669,4130,4531,4880,5185,5452,5687,5895,6079,6242,6389,6520,6638,6744,6841,6929)
#!any((abs(obs.l-res.l)/obs.l*100)>0.1)
#obs.s <- c(9372,8279,7342,6539,5848,5253,4739,4294,3908,3572,3279,3023,2799,2601,2427,2272,2135,2013,1904,1807)
#!any((abs(obs.s-res.s)/obs.s*100)>0.1)

(abs(5452-as.numeric(landings(stf)[,"2004"]))/5452*100)<0.1
(abs(3572-as.numeric(ssb(stf)[,"2005"]))/3572*100)<0.1

fbm <- mean(apply(trim(stf@harvest,years=2000:2002),1,mean)[as.character(2:4),])
fbr <- mean(apply(trim(stf@harvest,years=2003),1,mean)[as.character(2:4),])
(abs(0.6919-(fbr/fbm))/0.6919*100)<0.1


