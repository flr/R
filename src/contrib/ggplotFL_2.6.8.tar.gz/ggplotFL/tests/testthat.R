
library(testthat)
library(ggplotFL)

# TEST datasets

data(ple4)
data(ple4sex)

test_check("ggplotFL")

# https://github.com/r-lib/vdiffr
