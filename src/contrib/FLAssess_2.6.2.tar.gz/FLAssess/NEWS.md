# FLAssess 2.6.2

## DEPRECATED

- retro methods had been deprecated, now their Rd files have been deleted too.

