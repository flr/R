# FLEDA
Develops several procedures to explore fisheries data through data tranformation and plotting
