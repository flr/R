diags
=====

diagsnostics for stock assessment methods