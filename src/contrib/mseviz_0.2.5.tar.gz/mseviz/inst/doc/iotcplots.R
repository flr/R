## ---- start, echo=FALSE, message=FALSE----------------------------------------
library(knitr)
opts_chunk$set(echo=FALSE, message=FALSE, warning=FALSE,
  fig.width=5, fig.height=3, fig.pos='H')

## ----pkgs---------------------------------------------------------------------
library(mseviz)

## ----data---------------------------------------------------------------------
data(perf)
data(omruns)

## ----perf---------------------------------------------------------------------
perf

## ----runs---------------------------------------------------------------------
runs

## ----om-----------------------------------------------------------------------
om

## ----plotbps------------------------------------------------------------------
plotBPs(perf, statistics=c("FMSY", "SBMSY", "green", "risk1"))

## ----plottos------------------------------------------------------------------
plotTOs(perf, x="C", y=c("FMSY", "SBMSY", "green", "risk1"))

## ----kobemps------------------------------------------------------------------
kobeMPs(perf)

## ----plotomrunsf--------------------------------------------------------------
data(omruns)
plotOMruns(om$F, FLQuants(lapply(runs, '[[', 'F')), limit=0.8, target=0.4)

## ----plotomrunsc--------------------------------------------------------------
plotOMruns(om$C, FLQuants(lapply(runs, '[[', 'C')), limit=0.8, target=0.4)

