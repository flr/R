pow<-function(a,b) a^b
