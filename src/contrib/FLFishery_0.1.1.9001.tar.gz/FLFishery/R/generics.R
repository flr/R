# generics.R - DESC
# FLFishery/R/generics.R

# Copyright European Union, 2015 
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under terms of the European Union Public Licence (EUPL) V.1.1.

# CONSTRUCTORS

setGeneric("FLCatch", function(object, ...) standardGeneric("FLCatch"))

setGeneric("FLCatches", function(object, ...) standardGeneric("FLCatches"))

setGeneric("FLFishery", function(object, ...) standardGeneric("FLFishery"))

setGeneric("FLFisheries", function(object, ...) standardGeneric("FLFisheries"))

# ACCESSORS

setGeneric("capacity", function(object, ...) standardGeneric("capacity"))
setGeneric("capacity<-", function(object, ..., value) standardGeneric("capacity<-"))

setGeneric("crewshare", function(object, ...) standardGeneric("crewshare"))
setGeneric("crewshare<-", function(object, ..., value) standardGeneric("crewshare<-"))

setGeneric("fcost", function(object, ...) standardGeneric("fcost"))
setGeneric("fcost<-", function(object, ..., value) standardGeneric("fcost<-"))

setGeneric("hperiod", function(object, ...) standardGeneric("hperiod"))
setGeneric("hperiod<-", function(object, ..., value) standardGeneric("hperiod<-"))

setGeneric("orevenue", function(object, ...) standardGeneric("orevenue"))
setGeneric("orevenue<-", function(object, ..., value) standardGeneric("orevenue<-"))

setGeneric("price", function(object, ...) standardGeneric("price"))
setGeneric("price<-", function(object, ..., value) standardGeneric("price<-"))

setGeneric("vcost", function(object, ...) standardGeneric("vcost"))
setGeneric("vcost<-", function(object, ..., value) standardGeneric("vcost<-"))

# METHODS

setGeneric("catch.sel", function(object, ...) standardGeneric("catch.sel"))

setGeneric("catch.sel<-", function(object, ..., value) standardGeneric("catch.sel<-"))

setGeneric("discards.ratio", function(object, ...) standardGeneric("discards.ratio"))

setGeneric("cost", function(object, ...) standardGeneric("cost"))

setGeneric("ccost", function(object, ...) standardGeneric("ccost"))

setGeneric("profit", function(object, ...) standardGeneric("profit"))

setGeneric("lrevenue", function(object, ...) standardGeneric("lrevenue"))

setGeneric("revenue", function(object, ...) standardGeneric("revenue"))
