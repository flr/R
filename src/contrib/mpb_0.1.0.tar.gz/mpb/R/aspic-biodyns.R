#setGeneric('biodyns',     function(object,...)  standardGeneric('biodyns'))
 
