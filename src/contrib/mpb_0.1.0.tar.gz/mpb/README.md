# mp
A package for implementing Management Procedures, that can be simulation testing using Management Strategy Evaluation
