## ----knitr_init, echo=FALSE, results="hide"------------------------------
library(knitr)
## Global options
opts_chunk$set(echo    =!TRUE,
               eval    =TRUE,
               cache   =FALSE,
               cache.path="cache/mp",
               prompt  =FALSE,
               comment =NA,
               message =FALSE,
               tidy    =FALSE,
               warning =FALSE,
               fig.height=4.5,
               fig.width =4.5,
               fig.path  ="tex/mp")

## ---- pkgs, echo=FALSE, message=FALSE------------------------------------
library(ggplot2)

theme_set(theme_bw())
options(digits=3)

## ----install,eval=FALSE--------------------------------------------------
#  install.packages("mpb", repos = "http://flr-project.org/R")

## ----lib,echo=TRUE-------------------------------------------------------
library(mpb)
library(plyr)

## ---- fwd, echo=TRUE, eval=FALSE-----------------------------------------
#  fwd(object, catch = NULL, harvest = NULL,
#    stock = NULL, hcr = NULL, pe = NULL, peMult = TRUE, minF = 0,
#    maxF = 2, bounds = list(catch = c(Inf, Inf)), lag = 0, end = NULL,
#    starvationRations = 0.75, ...)

## ---- sim, echo=TRUE-----------------------------------------------------
bd=sim()

## ---- projection, echo=TRUE----------------------------------------------
bd=fwd(bd,catch=FLQuant(125,dimnames=list(year=49:100)))

## ---- projection2, echo=TRUE---------------------------------------------
bd=fwd(bd,FLQuants("catch"  =FLQuant(125,dimnames=list(year=49:100)),
                   "harvest"=FLQuant(.35,dimnames=list(year=49:100))))

plot(bd)

## ----example1,echo=TRUE,eval=TRUE----------------------------------------

## ---- devtools, echo=TRUE, eval=FALSE------------------------------------
#  	library(devtools)
#  	install_github('flr/FLPKG')

