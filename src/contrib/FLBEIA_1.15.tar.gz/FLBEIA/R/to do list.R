#------------------------------------------------------
## 2017/05/18
#------------------------------------------------------

# * varia.mat:a?adir al obs.trl. Al hacer:
#       FLStock@mat <- @fec*@mat  (1)
#    varia.fec deveria de ser 0 y poner un condicional en (1) para que en la multi.
#    solo entre @mat. from dorleta to dorleta
#
# * Escribir paginas de ayuda para los ***.ctrl, esto se utilizará en el manual 
#   para rellenar la seccion correspondiente. Se aconseja usar las tablas del 
#   manual para aprobechar el trabajo de Sonia. from dorleta to agurtzane & dorleta
# * Hacer update de la funcion jointIters al nuevo diseño. from dorleta to dorleta

