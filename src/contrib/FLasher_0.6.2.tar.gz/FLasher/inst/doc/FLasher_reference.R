## ---- pkgs, echo=FALSE, message=FALSE---------------------
#library(Rcpp)
#library(FLasher)
#library(ggplotFL)
#library(knitr)
#opts_chunk$set(dev='png', cache=FALSE, fig.width=5, fig.height=4.5, tidy=TRUE, dpi=300)
#options(width=60)

## ---- demoobjects-----------------------------------------

# A simple operating model
##om3 <- make_test_operatingModel3(niters = 100, sd = 0.1)
#data(ple4)

## ---- recycle_alpha---------------------------------------
## Get an FLCatch from the simple operating model
#catch1 <- om3$fisheries[["fishery"]][["catch"]]
## Look at the catchability parameters
#catch.q(catch1)
#dim(catch.q(catch1))
## Call the C++ method to access years 1 to 4 and iters 1 to 5 of alpha
#recycled_q <- test_FLCatchAD_catch_q_params_subset(catch1, c(1,1,1,1,1,1), c(1,4,1,1,1,5))
#is(recycled_q)
#dim(recycled_q)
## Note that dimnames have not been set - that is OK as it is used internally
#recycled_q

## ---- srp_example-----------------------------------------
## Make the simple OM with 1 fishery, 1 biol and 4 seasons
#FCB <- array(c(1,1,1), dim=c(1,3), dimnames=list(1,c("F","C","B")))
## Recruitment in seasons 1 and 3, so spawning in seasons 4 and 2
#om <- make_test_operatingModel(ple4, FCB, nseasons = 4, recruitment_seasons = c(1,3), recruitment_age = 1, niters = 20, sd = 0.1)
## Take a look at the spwn slot
## We have two units. They both spawn in seasons 2 and 4.
#spwn(om[["biols"]][[1]][["biol"]])[,1:5,1,]
#spwn(om[["biols"]][[1]][["biol"]])[,1:5,2,]
## Get the SRP each unit for five years
#srp <- test_operatingModel_SRP_FLQ_subset(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, c(1,1,1,1,1), c(5,2,4,1,20))
## SRP of unit 1 has SRP in season 2 and 4 
#srp[,,1]
## SRP of unit 2 also has SRP in season 2 and 4 
#srp[,,2]
## Total SRP of each unit in the biol - also in season 2 and 4
#total_srp <- test_operatingModel_total_SRP_FLQ_subset(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, c(1,1,1,1,1), c(5,2,4,1,20))
#total_srp

## ---- srp_timelag-----------------------------------------
## Annual model with first age 0
## timelag of 0 (SRP and recruitment in same year)
#biol <- random_FLBiolcpp_generator(fixed_dims = c(5,5,1,1,1,1), min_age_name = 0)
#test_fwdBiol_srp_timelag(biol)
## Annual model with first age 2
## timelag of 2 (SRP from 2 years ago)
#biol <- random_FLBiolcpp_generator(fixed_dims = c(5,5,1,1,1,1), min_age_name = 2)
#test_fwdBiol_srp_timelag(biol)
## Seasonal model (12 seasons) with first age 0
## timelag of 1 - SRP comes from previous timestep
#biol <- random_FLBiolcpp_generator(fixed_dims = c(5,5,1,12,1,1), min_age_name = 0)
#test_fwdBiol_srp_timelag(biol)
## Seasonal model (12 seasons) with first age 2
## timelag of 24 - SRP comes from same season, but 2 years ago 
#biol <- random_FLBiolcpp_generator(fixed_dims = c(5,5,1,12,1,1), min_age_name = 2)
#test_fwdBiol_srp_timelag(biol)

## ---- srr_recycling1--------------------------------------
## Set up some random deviances - not used in calculation
#deviances <- FLQuant(1, dimnames = list(year = 1:10, iter = 1:10))
#deviances_mult <- TRUE
## Set the SRR parameters - no structure in the time dimension - only disaggregated by parameter
#srr_params <- FLQuant(c(10, 0.001), dimnames=list(param = c("a","b")))
#srr_params
## Get the parameters in year 1
#test_fwdSR_get_params("ricker", srr_params, deviances, deviances_mult, c(1,1,1,1,1))
## Get the parameters in year 2 - the same due to recycling
#test_fwdSR_get_params("ricker", srr_params, deviances, deviances_mult, c(2,1,1,1,1))
## Get the  parameters in year 5 - the same due to recycling
#test_fwdSR_get_params("ricker", srr_params, deviances, deviances_mult, c(5,1,1,1,1))

## ---- srr_recycling2--------------------------------------
## Set up some random deviances - not used in calculation
#deviances <- FLQuant(1, dimnames = list(year = 1:5, iter = 1:10))
#deviances_mult <- TRUE
## SRR parameters change over time
#srr_params <- FLQuant(NA, dimnames=list(param=c("a","b"), year=1:5))
#srr_params[1,] <- seq(8,12,length=5)
#srr_params[2,] <- seq(0.0008,0.0012, length=5)
#srr_params
## Year 1, iter 1
#test_fwdSR_get_params("ricker", srr_params, deviances, deviances_mult, c(1,1,1,1,1))
## Year 2, iter 5 (recycling over iterations)
#test_fwdSR_get_params("ricker", srr_params, deviances, deviances_mult, c(2,1,1,1,5))
## Year 5, iter 10 (recycling over iterations)
#test_fwdSR_get_params("ricker", srr_params, deviances, deviances_mult, c(5,1,1,1,10))
## Asking for Year outside than SRR params - only the first year is returned
#test_fwdSR_get_params("ricker", srr_params, deviances, deviances_mult, c(10,1,1,1,1))

## ---- single_rec1-----------------------------------------
#FCB <- array(c(1,1,1), dim=c(1,3), dimnames=list(1,c("F","C","B")))
## Annual model with a first age of one and 5 iterations
#om <- make_test_operatingModel(ple4, FCB, nseasons = 1, recruitment_age = 1, niters = 5, sd = 0.1)
## Fix the SRR parameters so that they are not disaggregated by time or by iter
#sr_params <- FLQuant(NA, dimnames=list(param=c("a","b")))
#sr_params[1,] <- 700000
#sr_params[2,] <- 9000
#om[["biols"]][[1]][["srr_params"]] <- sr_params
## Get the recruitment in the year 2 (uses SRP in year 1)
## SRR parameters are recycled over the year and iter dimensions
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 2)
## Get the recruitment in the year 10 (uses SRP in year 9)
## SRR parameters are recycled over the year and iter dimensionas
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 50)

## ---- single_rec2-----------------------------------------
## Use the same OM as above
## Set the SRR parameters to be disaggregated by year (not disaggregated by iteration)
## Need same number of years as rest of model - else only first year is used
#sr_params <- FLQuant(NA, dimnames=list(param=c("a","b"), year=1:52))
#sr_params[1,] <- c(rep(700000,26), rep(900000,26))
#sr_params[2,] <- 9000
#om[["biols"]][[1]][["srr_params"]] <- sr_params
## Show a few years - note step change in recruitment parameters
#sr_params[,24:28]
## Get the recruitment in the year 2 (uses SRP in year 1)
## SRR parameters are recycled over the iter dimension
## Note same values as above
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 2)
## Get the recruitment in the year 10 (uses SRP in year 9)
## SRR parameters are recycled over the iter dimension
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 50)

## ---- single_rec3-----------------------------------------
#FCB <- array(c(1,1,1), dim=c(1,3), dimnames=list(1,c("F","C","B")))
## Seasonal model with, 4 seasons, recruiting in season 2 and a first age of one and 5 iterations
#om <- make_test_operatingModel(ple4, FCB, nseasons = 4, recruitment_seasons = 2, recruitment_age = 1, niters = 5, sd = 0.1)
## The SRR parameters have already been set up for us
## Recruitment only happens in season 2
#om[["biols"]][[1]][["srr_params"]]
## Recruitment in Year 2, season 1
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 5)
## Recruitment in Year 2, season 2
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 6)
## Recruitment in Year 2, season 3
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 7)
## Recruitment in Year 2, season 4
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 8)

## ---- single_rec4-----------------------------------------
## Example of how to incorrectly set up SRR params for a seasonal model
#FCB <- array(c(1,1,1), dim=c(1,3), dimnames=list(1,c("F","C","B")))
## Seasonal model with, 4 seasons, recruiting in season 2 and a first age of one and 5 iterations
#om <- make_test_operatingModel(ple4, FCB, nseasons = 4, recruitment_seasons = 2, recruitment_age = 1, niters = 5, sd = 0.1)
## Replace SRR params with new params without seasonal disaggregation
## Recruitment only happens in season 2
#om[["biols"]][[1]][["srr_params"]] <- FLQuant(c(900000,9000), dimnames=list(params=c("a","b")))
## Recruitment in Year 2 season 1
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 5)
## Recruitment in Year 2, season 2
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 6)
## Recruitment in Year 2, season 3
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 7)
## Recruitment in Year 2, season 4
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 8)

## ---- multi_rec1------------------------------------------
## Simple model with a single fishery, catch and stock
#FCB <- array(c(1,1,1), dim=c(1,3), dimnames=list(1,c("F","C","B")))
## Seasonal model with, 4 seasons, recruitment in seasons 2 and 4, first age of 1 and 5 iterations
#om <- make_test_operatingModel(ple4, FCB, nseasons = 4, recruitment_seasons = c(2,4), recruitment_age = 1, niters = 5, sd = 0.1)
## Look at spwn slot that determines the timing of spawning
## Spawning pattern of unit 1
#spwn(om[["biols"]][[1]][["biol"]])[,1,1,]
## Spawning pattern of unit 2
#spwn(om[["biols"]][[1]][["biol"]])[,1,2,]
## Both units spawn at the same time. Recruitment is always based on total SRP of both units.
## Look at the SRR params - they are disaggregated by param, unit and season (and iter)
#dim(om[["biols"]][[1]][["srr_params"]])
## Season 1, neither unit recruits
#om[["biols"]][[1]][["srr_params"]][,,,1]
## Season 2, unit 2 recruits
#om[["biols"]][[1]][["srr_params"]][,,,2]
## Season 3, neither unit recruits
#om[["biols"]][[1]][["srr_params"]][,,,3]
## Season 4, unit 2 recruits
#om[["biols"]][[1]][["srr_params"]][,,,4]
## Check that the calculated recruitment reflects this
## Year 2, season 1, unit 1
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 5)
## Year 2, season 1, unit 2
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 2, 5)
## Year 2, season 2, unit 1
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 6)
## Year 2, season 2, unit 2
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 2, 6)
## Year 2, season 3, unit 1
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 7)
## Year 2, season 3, unit 2
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 2, 7)
## Year 2, season 4, unit 1
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 1, 8)
## Year 2, season 4, unit 2
#test_operatingModel_calc_rec(om[["fisheries"]], om[["biols"]], om[["fwc"]], 1, 2, 8)

