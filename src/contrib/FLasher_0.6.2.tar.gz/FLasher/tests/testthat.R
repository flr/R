
library(testthat)
library(ggplot2)
library(FLasher)

test_check("FLasher")
