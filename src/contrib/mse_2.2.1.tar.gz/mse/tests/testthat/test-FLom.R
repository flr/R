# test-FLom.R - DESC
# /test-FLom.R

# Copyright Iago MOSQUEIRA (WMR), 2021
# Author: Iago MOSQUEIRA (WMR) <iago.mosqueira@wur.nl>
#
# Distributed under the terms of the EUPL-1.2


data(p4om)


catch(om)

landings(om)
discards(om)

fbar(om)

harvest(om)

ssb(om)

tsb(om)
