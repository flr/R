# FLQuantDistr - «Short one line description»
# FLCore/R/FLQuantDistr.R

# Copyright 2003-2012 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, JRC
# $Id: FLQuantPoint.R 1779 2012-11-23 09:39:31Z imosqueira $

## FLQuantDistr()	{{{
setMethod("FLQuantDistr", signature(object="ANY", var="ANY"),
	function(object, var, ...) {

		# object
		object <- FLQuant(object)
		# var
		var <- FLQuant(var)

		return(FLQuantDistr(object=object, var=var, ...))
	}
)

setMethod("FLQuantDistr", signature(object="FLQuant", var="FLQuant"),
  function(object, var, units=object@units, distr='norm') {
		return(new('FLQuantDistr', object, var=var, units=units, distr=distr))
	}
) # }}}

## show     {{{
# TODO show median(var) or [lowq-uppq]
setMethod("show", signature(object="FLQuantDistr"),
	function(object){
		cat("An object of class \"FLQuantDistr\":\n")

    v3 <- paste(format(object@.Data,digits=5),"(", format(object@var, digits=3), ")", sep="")
    print(array(v3, dim=dim(object)[1:5], dimnames=dimnames(object)[1:5]), quote=FALSE)

		cat("units: ", object@units, "\n")
		cat("distr: ", object@distr, "\n")
	}
)   # }}}

## random generators	{{{
# rnorm(FLQuantPoint, missing)
setMethod("rnorm", signature(n='numeric', mean="FLQuantPoint", sd="missing"),
	function(n=1, mean)
	rnorm(n, mean(mean), sqrt(var(mean)))
)
# rlnorm
setMethod("rlnorm", signature(n='numeric', meanlog="FLQuantPoint", sdlog="missing"),
	function(n=1, meanlog)
	rlnorm(n, mean(meanlog), sqrt(var(meanlog)))
)
# gamma
if (!isGeneric("rgamma"))
	setGeneric("rgamma", useAsDefault=rgamma)

setMethod("rgamma", signature(n='numeric', shape="FLQuantPoint", rate="missing",
	scale="missing"),
	function(n=1, shape)
	FLQuant(rgamma(n, shape=mean(shape)^2/var(shape), scale=var(shape)/mean(shape)),
		dim=c(dim(shape)[-6], n))
)
# pearson
# }}}

## accesors	{{{
setMethod("e", signature(x="FLQuantDistr"),
	function(x)
		return(FLQuant(x@.Data, units=units(x)))
)

setMethod("e<-", signature(x="FLQuantDistr", value="FLQuant"),
	function(x, value) {
		x@.Data <- value
		return(x)
	}
)

setMethod("var", signature(x="FLQuantDistr"),
	function(x)
		return(x@var)
)

setMethod("var<-", signature(x="FLQuantDistr", value="FLArray"),
	function(x, value) {
		x@var <- value
		return(x)
	}
)

setMethod("distr", signature(object="FLQuantDistr"),
	function(object)
		return(object@distr)
)

setMethod("distr<-", signature(object="FLQuantDistr", value="character"),
	function(object, value) {
		object@distr <- value
		return(object)
	}
) # }}}

# sd, cv {{{
setMethod("sd", signature(x="FLQuantDistr"),
	function(x, na.rm=TRUE)
		return(sqrt(var(x)))
)

setMethod("cv", signature(x="FLQuantDistr"),
	function(x)
		return(sd(x) / e(x))
) # }}}

# Arith {{{

# FLQuantDistr, FLArray
setMethod("+",
	signature(e1 = "FLQuantDistr", e2 = "FLArray"),
	function(e1, e2) {
		e1@.Data <- e1@.Data + e2
		units(e1) <- uom('+', units(e1), units(e2))
		return(e1)
	}
)

setMethod("-",
	signature(e1 = "FLQuantDistr", e2 = "FLArray"),
	function(e1, e2) {
		e1@.Data <- e1@.Data - e2
		units(e1) <- uom('-', units(e1), units(e2))
		return(e1)
	}
)
setMethod("*",
	signature(e1 = "FLQuantDistr", e2 = "FLArray"),
	function(e1, e2) {
		e1@.Data <- e1@.Data * e2@.Data
		e1@var@.Data <- e2@.Data^2 * e1@var
		units(e1) <- uom('*', units(e1), units(e2))
		return(e1)
	}
)
setMethod("/",
	signature(e1 = "FLQuantDistr", e2 = "FLArray"),
	function(e1, e2) {
		e1@.Data <- e1@.Data / e2@.Data
		e1@var@.Data <- 1/e2@.Data^2 * e1@var
		units(e1) <- uom('/', units(e1), units(e2))
		return(e1)
	}
) 

# FLQuantDistr, FLQuantDistr
setMethod("*",
	signature(e1 = "FLQuantDistr", e2 = "FLQuantDistr"),
	function(e1, e2) {

		dis <- unique(c(distr(e1), distr(e2)))

		# Both distr must be equal
		if(length(dis) > 1)
			stop ("Both objects must be of same 'distr': ", dis)

		# Both objects must be either 'norm' or 'lnorm'
		if(dis %in% c('norm', 'lnorm')) {
			var(e1)[] <- e1@.Data^2 * var(e2) + e2@.Data^2 * var(e1)
		} else {
			stop("Operation only defined for distr='norm' or 'lnorm'")
		}
		e1@.Data <- e1@.Data * e2@.Data
		units(e1) <- uom('*', units(e1), units(e2))
		
		return(e1)
	}
)

setMethod("+",
	signature(e1 = "FLQuantDistr", e2 = "FLQuantDistr"),
	function(e1, e2) {

		dis <- unique(c(distr(e1), distr(e2)))

		# Both distr must be equal
		if(length(dis) > 1)
			stop ("Both objects must be of same 'distr': ", dis)

		# Both objects must be either 'norm' or 'lnorm'
		if(dis %in% c('norm', 'lnorm')) {
			e1@var[] <- var(e1) + var(e2)
		} else {
			stop("Operation only defined for distr='norm' or 'lnorm'")
		}
		e1@.Data <- e1@.Data + e2@.Data
		units(e1) <- uom('+', units(e1), units(e2))
		
		return(e1)
	}
)

setMethod("-",
	signature(e1 = "FLQuantDistr", e2 = "FLQuantDistr"),
	function(e1, e2) {

		dis <- unique(c(distr(e1), distr(e2)))

		# Both distr must be equal
		if(length(dis) > 1)
			stop ("Both objects must be of same 'distr': ", dis)

		# Both objects must be either 'norm' or 'lnorm'
		if(dis %in% c('norm', 'lnorm')) {
			var(e1)[] <- var(e1) + var(e2)
		} else {
			stop("Operation only defined for distr='norm' or 'lnorm'")
		}
		e1@.Data <- e1@.Data - e2@.Data
		units(e1) <- uom('+', units(e1), units(e2))
		
		return(e1)
	}
) # }}}

## "["             {{{
setMethod("[", signature(x="FLQuantDistr"),
    function(x, i, j, k, l, m, n, ..., drop=FALSE) {

   		if(length(list(...)) > 0)
        stop('FLQuantDistr objects only have 6 dimensions')

	  	dx <- dim(x)
		  if (missing(i))
        i  <-  seq(1, dx[1])
      if (missing(j))
        j  <-  seq(1, dx[2])
      if (missing(k))
        k  <-  seq(1, dx[3])
      if (missing(l))
        l  <-  seq(1, dx[4])
      if (missing(m))
        m  <-  seq(1, dx[5])
      if (missing(n))
        n  <-  seq(1, dx[6])
			
			res <- x
			res@.Data <- do.call('[', list(x=x@.Data, i=i, j=j, k=k, l=l,
				m=m, n=n, drop=FALSE))
			res@var <- do.call('[', list(x=x@var, i=i, j=j, k=k, l=l,
				m=m, n=n, drop=FALSE))
      
      return(res)
	}
) 

setMethod("[", signature(x="FLQuantDistr", i="array", j="missing", drop="missing"),
  function(x, i)
  {
		res <- x
		
		res@.Data <- do.call('[', list(x=e(x), i=i))
		res@var <- do.call('[', list(x=var(x), i=i))

		return(res)
  }
)


# }}}

## "[<-"            {{{
setMethod("[<-", signature(x="FLQuantDistr", value="FLQuantDistr"),
  function(x, i, j, k, l, m, n, ..., value)
  {
		# check dims !> 6
    if(length(list(...)) > 0)
      stop(paste(class(x), 'objects only have 6 dimensions'))

		# array (logical) used to index
    if(!missing(i) && is.array(i))
    {
	  x@.Data[i] <- value
      return(x)
    }
		
		# default dims = all
    dx <- dim(x)
  	if (missing(i))
      i  <-  seq(1, dx[1])
    if (missing(j))
      j  <-  seq(1, dx[2])
    if (missing(k))
      k  <-  seq(1, dx[3])
    if (missing(l))
      l  <-  seq(1, dx[4])
    if (missing(m))
      m  <-  seq(1, dx[5])
    if (missing(n))
      n  <-  seq(1, dx[6])

    # aperm array, not common dims last
		same <- which(dim(value) == dim(x))
		diff <- which(dim(value) != dim(x))
		dper <- c(same, diff)
		y <- aperm(x, dper)
		
		# 
		iper <- list(i, j, k, l, m, n)[dper]
		names(iper) <- c('i','j','k','l','m','n')
		
		# call [<-
		y <- do.call('[<-', c(list(x=y), iper, list(value=aperm(unname(value), dper))))

		# re-aperm
		y <- aperm(y, order(dper))

   	return(new(class(x), y, units=units(x)))
	}
)   # }}}

# window {{{
setMethod("window", signature(x="FLQuantDistr"),
	function(x, start=dims(x)$minyear, end=dims(x)$maxyear, extend=TRUE, frequency=1) {
	return(FLQuantDistr(window(FLQuant(x@.Data), start=start, end=end, extend=extend, frequency=frequency), var=window(FLQuant(x@var), start=start, end=end, extend=extend, frequency=frequency), distr=distr(x), units=units(x)))
}) # }}}

# sums         {{{
setMethod('quantSums', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- quantSums(FLQuant(x@.Data), na.rm=na.rm)
		va <- quantSums(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('yearSums', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- yearSums(FLQuant(x@.Data), na.rm=na.rm)
		va <- yearSums(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('unitSums', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- unitSums(FLQuant(x@.Data), na.rm=na.rm)
		va <- unitSums(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('seasonSums', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- seasonSums(FLQuant(x@.Data), na.rm=na.rm)
		va <- seasonSums(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('areaSums', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- areaSums(FLQuant(x@.Data), na.rm=na.rm)
		va <- areaSums(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
}) # }}}

# means         {{{
setMethod('quantMeans', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- quantMeans(FLQuant(x@.Data), na.rm=na.rm)
		va <- quantMeans(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('yearMeans', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- yearMeans(FLQuant(x@.Data), na.rm=na.rm)
		va <- yearMeans(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('unitMeans', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- unitMeans(FLQuant(x@.Data), na.rm=na.rm)
		va <- unitMeans(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('seasonMeans', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- seasonMeans(FLQuant(x@.Data), na.rm=na.rm)
		va <- seasonMeans(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('areaMeans', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- areaMeans(FLQuant(x@.Data), na.rm=na.rm)
		va <- areaMeans(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('iterMeans', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- iterMeans(FLQuant(x@.Data), na.rm=na.rm)
		va <- iterMeans(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
}) # }}}

# medians         {{{
setMethod('iterMedians', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- iterMedians(FLQuant(x@.Data), na.rm=na.rm)
		va <- iterMedians(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
}) # }}}

# vars         {{{
setMethod('quantVars', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- quantVars(FLQuant(x@.Data), na.rm=na.rm)
		va <- quantVars(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('yearVars', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- yearVars(FLQuant(x@.Data), na.rm=na.rm)
		va <- yearVars(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('unitVars', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- unitVars(FLQuant(x@.Data), na.rm=na.rm)
		va <- unitVars(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('seasonVars', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- seasonVars(FLQuant(x@.Data), na.rm=na.rm)
		va <- seasonVars(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('areaVars', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- areaVars(FLQuant(x@.Data), na.rm=na.rm)
		va <- areaVars(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
})
setMethod('iterVars', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- iterVars(FLQuant(x@.Data), na.rm=na.rm)
		va <- iterVars(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
}) # }}}

# CVs {{{
setMethod('iterCVs', signature(x='FLQuantDistr'), function(x, na.rm=TRUE) {
		re <- iterCVs(FLQuant(x@.Data), na.rm=na.rm)
		va <- iterCVs(FLQuant(x@var), na.rm=na.rm)
		return(FLQuantDistr(re, va, units=x@units, distr=x@distr))
}) # }}}

# propagate {{{
setMethod("propagate", signature(object="FLQuantDistr"),
  function(object, iter, fill.iter=TRUE)
	{
		re <- propagate(FLQuant(object@.Data), iter=iter, fill.iter=fill.iter)
		va <- propagate(FLQuant(object@var), iter=iter, fill.iter=fill.iter)
		return(FLQuantDistr(re, var=va, units=object@units, distr=object@distr))
	}
) # }}}
