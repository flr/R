## ---- pkgs, echo=FALSE, message=FALSE-----------------------------------------
library(knitr)
opts_chunk$set(echo=FALSE, message=FALSE, warning=FALSE,
  fig.width=5, fig.height=4.5)

## ---- eval=FALSE--------------------------------------------------------------
#  install.packages("ss3om", repos=structure(c(CRAN="https://cloud.r-project.org/",
#    FLR="https://flr-project.org/R")))

## ---- eval=FALSE--------------------------------------------------------------
#  remotes::install_github("flr/ss3om")

## ----loadpkg------------------------------------------------------------------
library(ss3om)

## ----setpwd-------------------------------------------------------------------
dir <- system.file("ext-data/albio", package="ss3om")

## ----readfls------------------------------------------------------------------
albio <- readFLSss3(dir, name="herring")

