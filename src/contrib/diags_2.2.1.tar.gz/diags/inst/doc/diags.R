## ----knitr_init, echo=FALSE, results="hide"------------------------------
library(knitr)
## Global options
opts_chunk$set(echo    =!TRUE,
               eval    =TRUE,
               cache   =!FALSE,
               cache.path="cache/",
               prompt  =FALSE,
               comment =NA,
               message =FALSE,
               tidy    =FALSE,
               warning =FALSE,
               fig.height=4.5,
               fig.width =8,
               fig.path  ="tex/")

## ---- pkgs, echo=FALSE, message=FALSE------------------------------------
options(warn=-1)

library(ggplot2)
library(diags)

theme_set(theme_bw())
options(digits=3)

## ----install,echo=TRUE,eval=FALSE----------------------------------------
#  install.packages("diags", repos = "http://cloud.r-project.org/")

## ----lib,echo=TRUE-------------------------------------------------------
library(diags)

## ----data-yft,echo=TRUE,eval=!FALSE--------------------------------------
data(dgs)

## ----data-yft2,echo=!TRUE------------------------------------------------
is(dgs)
colnames(dgs)

## ----cpue-plot,echo=TRUE,fig.height=4,fig.width=8------------------------
ggplot(dgs)+
  geom_path(aes(year,y,group=name,col=name))

## ----plyr,echo=TRUE------------------------------------------------------
library(plyr)

## ----plyr2,echo=TRUE-----------------------------------------------------
par(mfrow = c(4, 2))
par(mar = c(3, 3, 0, 0), oma = c(1, 1, 1, 1))

d_ply(dgs, .(name), with, acf(residual,lag.max=5))

## ----plyr3,echo=TRUE,fig.height=8----------------------------------------
qq=ddply(dgs, .(name), with, 
          as.data.frame(qqnorm(residual,plot=FALSE)))

ggplot(aes(x,y),data=qq)+
  geom_point()+
  geom_smooth(method="lm")+
  facet_wrap(~name)

## ------------------------------------------------------------------------
diags:::stdz(  rnorm(10,1,.3))
diags:::minMax(rnorm(10,1,.3))

## ------------------------------------------------------------------------
dgs=ddply(dgs, .(name), transform, sdgs=diags:::stdz(residual))

## ------------------------------------------------------------------------
library(gam)
library( plyr)
library(dplyr)

scale<-function(x,y,group=1){
  gm  =gam(y~lo(x)+group)

  res=data.frame(hat =predict(gm),
                 y     =gm$y,
                 x     =x,
                 group =group,
                 scl   =c(0,coefficients(gm)[-(1:2)])[as.numeric(as.factor(group))]
                 )
  res$y  =res$y  -res$scl
  res$hat=res$hat-res$scl
  res[,-5]}


## ----fig.cap=""----------------------------------------------------------
ggplot(with(dgs,scale(year,y,name)))+
  geom_line( aes(x,hat,col=group))+
  geom_line( aes(x,y,col=group))+
  geom_point(aes(x,y,col=group))+
  theme(legend.position="bottom")

## ----fig.cap=""----------------------------------------------------------
ggplot(with(dgs,scale(year,residual,name)))+
  geom_hline(aes(yintercept=0))+
  geom_line(aes(x,hat,col=group))+
  geom_point(aes(x,y,col=group),position=position_dodge(width = 1))+
  geom_linerange(aes(x,ymin=hat,ymax=y,col=group),position=position_dodge(width = 1))+
  theme(legend.position="bottom")

## ----eval=!FALSE---------------------------------------------------------
library(reshape)
library(GGally)
library(diags)
library(reshape2)
library(plyr)

my_density <- function(data,mapping,...){
  ggplot(data=data,mapping=mapping)+
    geom_density(...,lwd=1)}

my_smooth <- function(data,mapping,...){
  ggplot(data=data,mapping=mapping)+
    geom_point(...,size=.5)+
    geom_smooth(...,method="lm",se=FALSE)}

mat=cast(dgs,year~name,value="y")
names(mat)=gsub(" ", "_",names(mat))

ggpairs(mat,
  upper=list(continuous=wrap("cor",size=4, hjust=0.5)),
  lower=list(continuous = wrap(my_smooth)),
  diag=list(continuous=wrap(my_density,alpha=0.2)))

## ------------------------------------------------------------------------
library(corrplot)
cr=cor(mat[,-1],use="pairwise.complete.obs")
dimnames(cr)=list(gsub("_"," ",names(mat)[-1]),gsub("_"," ",names(mat)[-1]))
cr[is.na(cr)]=0
corrplot(cr,diag=F,order="hclust",addrect=2)  +          
             theme(legend.position="bottom")  

## ------------------------------------------------------------------------
ggplot(aes(x,y),data=dgs) +   
      geom_point()+
      geom_smooth(se=FALSE,method="lm")+
      geom_abline(aes(slope=1,intercept=0))+
      xlab("Assessment Estimate")+ylab("Observered CPUE")+
      facet_wrap(~name,scale="free")

## ------------------------------------------------------------------------
dat=ddply(dgs, .(name), transform, residual=diags:::stdz(residual,na.rm=T))

ggplot(aes(year,residual),data=dat) +
  geom_hline(aes(yintercept=0))      +
  geom_point()                       +
  geom_linerange(aes(year,ymin=0,ymax=residual))                       +
  stat_smooth(,method="loess",se=T,fill="blue", alpha=0.1)  +
  facet_wrap(~name,scale="free",ncol=2)  

## ------------------------------------------------------------------------
ggplot(dgs)                                              +
  geom_point( aes(residual,residualLag))                  +
  stat_smooth(aes(residual,residualLag),method="lm",se=T,fill="blue", alpha=0.1)      +
  geom_hline(aes(yintercept=0))                           +
  facet_wrap(~name,scale="free",ncol=3)                   +
  xlab(expression(Residual[t])) + 
  ylab(expression(Residual[t+1])) 

## ------------------------------------------------------------------------
ggplot(dgs)                                           +
  geom_point( aes(qqx,qqy))                            +
  stat_smooth(aes(qqx,qqHat),method="lm",se=T,fill="blue", alpha=0.1)         +
  facet_wrap(~name)          

## ------------------------------------------------------------------------
ggplot(aes(yhat, residual),data=dgs)   +
  geom_hline(aes(yintercept=0))         +
  geom_point()                          +
  stat_smooth(method="loess",span=.9,fill="blue", alpha=0.1)   +
  facet_wrap(~name,scale="free",ncol=3) 

## ---- eval=FALSE---------------------------------------------------------
#  library(ggplot2)
#  library(diags)
#  library(plyr)
#  library(dplyr)
#  library(GGally)
#  library(stringr)
#  
#  data(dgs)
#  
#  lm_with_cor <- function(data, mapping, ..., method = "pearson") {
#      x <- data[[deparse(mapping$x)]]
#      y <- data[[deparse(mapping$y)]]
#      cor <- cor(x, y, method = method)
#      ggally_smooth_lm(data, mapping, ...) +
#        ggplot2::geom_label(
#          data = data.frame(
#            x = min(x, na.rm = TRUE),
#            y = max(y, na.rm = TRUE),
#            lab = round(cor, digits = 3)
#          ),
#          mapping = ggplot2::aes(x = x, y = y, label = lab, color = NULL),
#          hjust = 0, vjust = 1,
#          size = 5, fontface = "bold"
#        )
#    }
#  
#  ggduo(dgs,c("year","y"),c("residual",".fitted"),
#          mapping=aes(color=name),
#    types = list(continuous = wrap(lm_with_cor, alpha = 0.25)),
#    showStrips = FALSE,
#    title = "",
#    xlab = "",
#    ylab = "",
#    #legend = c(5,2)
#    ) +
#    theme(legend.position = "bottom")
#  
#   ggplot(melt(dgs[,c("name","year","residual",".hat",".cooksd",".sigma")],id=c("name","year")))+
#      geom_point(aes(year,value))+
#      facet_grid(variable~name,scale="free",space="free_x")+
#      scale_x_continuous(breaks=seq(1950,2010,10))+
#      theme(axis.text.x = element_text(angle = 90, hjust = 1))

## ---- devtools, echo=TRUE, eval=FALSE------------------------------------
#  	devtools::install_github('flr/FLPKG')

