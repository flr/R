# allGenerics.R - DESC
# allGenerics.R

# Copyright 2012-2017 FLR Team. Distributed under the GPL 2
# Maintainer: Iago Mosqueira (EC JRC) <iago.mosqueira@ec.europa.eu

# ggplot 
setGeneric("ggplot", useAsDefault = ggplot2::ggplot)
