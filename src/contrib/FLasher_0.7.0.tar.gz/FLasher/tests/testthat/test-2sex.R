# test-2sex.R - DESC
# /test-2sex.R

# Copyright Iago MOSQUEIRA (WMR), 2021
# Author: Iago MOSQUEIRA (WMR) <iago.mosqueira@wur.nl>
#
# Distributed under the terms of the EUPL-1.2


# --- TEST projections with 2-sex FLStock (ple4sex)


