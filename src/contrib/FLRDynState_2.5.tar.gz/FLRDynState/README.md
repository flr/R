FLRDynState
===========

Two-species Dynamic State Variable Model in FLR
