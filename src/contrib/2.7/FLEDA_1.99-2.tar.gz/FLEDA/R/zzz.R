.onLoad <- function(lib,pkg) {
	require(methods)
	cat("FLEDA 1.99-RC2 - 20080331\n")
}
