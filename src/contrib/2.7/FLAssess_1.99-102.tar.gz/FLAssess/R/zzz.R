# zzz - «Short one line description»

# Author: Iago Mosqueira, AZTI Tecnalia
# Maintainer: FLR Team 
# Additions:
# Last Change: 03 Apr 2008 10:40
# $Id: zzz.R,v 1.2 2008/05/02 09:47:19 imosqueira Exp $

.onLoad <- function(lib,pkg) {
	require(methods)
}
