## 01/06 Modifications by L Kell, J. J. Poos and F.Scott
##27/7/2005 Modified by J.J.Poos and R.Scott
##20/4/2005 Modified by L Kell

## FLSTF Extends FLStock

validFLSTF.control <- function(object) {
	if(object@fbar.nyrs < 1)               return("Invalid number of years for calculation of fbar")
	if(!is.logical(object@f.rescale))      return("f.rescale must be either TRUE or FALSE")
	if(object@wts.nyrs  < 1)               return("Invalid number of years for calculation of mean weight at age")
	if(object@fbar.min < 0)                return("Invalid minimum age specified for calculation of fbar")
	if(object@fbar.max < object@fbar.min)  return("fbar.max less than fbar.min")
	if(object@nyrs < 1)                    return("Invalid number of years for forecast")
	if(((length(object@rec) != 1) && (length(object@rec)!=object@nyrs)) || ((length(object@rec)!=1) && any(is.na(object@rec))))
                                          return("rec must be a single NA, a single value or vector of nyrs values")
#  if(!is.na(object@catch.constraint) && !is.na(object@ssb.constraint))
#                                          return("Only one of catch.constraint or ssb.constraint may be set")
	return(TRUE)
}

setClass("FLSTF.control",
   representation(
      fbar.min   ="numeric",
      fbar.max   ="numeric",
      fbar.nyrs  ="numeric",
      f.rescale  ="logical",
      wts.nyrs   ="numeric",
      rec        ="numeric",
      rec.yrs    ="numeric",
      nyrs       ="numeric",
      fmult	     ="numeric",
      catch.constraint="numeric",
      landings.constraint="numeric",
      ssb.constraint="numeric"
      ),
   prototype=prototype(
      fbar.min    =as.integer(0),
      fbar.max    =as.integer(0),
      fbar.nyrs   =as.integer(3),
      f.rescale   =FALSE,
      wts.nyrs    =as.integer(3),
      rec         =as.numeric(NA),
      rec.yrs     =as.numeric(c(NA,NA)),
      nyrs        =as.integer(3),
      fmult	      =as.double(0),
      catch.constraint=as.double(NA),
      landings.constraint=as.double(NA),
      ssb.constraint=as.double(NA)
     ),
   validity=validFLSTF.control
)

setClass("FLSTF",
   contains="FLStock",
   representation(
      name	   = "character",
      desc	   = "character",
      call     = "character",
      control  = "FLSTF.control"
      ),
   prototype=prototype(
      name	   =character(0),
      desc	   =character(0),
      call     =character(0),
      control  =new("FLSTF.control")
     )
)

#createFLAccesors(new("FLSTF.control"), exclude=list("fbar.min","fbar.max","fbar.nyrs","f.rescale",
#                   "wts.nyrs","rec","rec.nyrs","nyrs","fmult","catch.constraint","ssb.constraint"))


FLSTF.control <- function(fbar.nyrs=3, f.rescale=FALSE, wts.nyrs=3, fbar.min=2, fbar.max=3,
			rec=as.numeric(NA), rec.yrs=as.numeric(c(NA,NA)), nyrs=3, fmult=1,
      catch.constraint=as.double(NA), landings.constraint=as.double(NA), ssb.constraint=as.double(NA)) {

	res <- new("FLSTF.control", fbar.nyrs=fbar.nyrs, f.rescale=f.rescale, wts.nyrs=wts.nyrs,
			fbar.min=fbar.min, fbar.max=fbar.max, rec=rec, rec.yrs=rec.yrs,
			nyrs=nyrs, fmult=fmult, catch.constraint=catch.constraint, ssb.constraint=ssb.constraint,
      landings.constraint=landings.constraint)

	check <- validFLSTF.control(res)
	if(!check)
		stop("invalid FLSTF.control object:", check)

	return(res)
}


# Updated by Jan Jaap Poos, 19/7/2005;
# changed resizing of FLQuants in FLSTF object created by FLSTF() with direct transfer of data to speed it up.
FLSTF <- function(stock, control, unit=1, season=1, area=1, iter=1, survivors=NA, quiet=TRUE, harvest="missing", sop.correct=FALSE,...) {

   if(!inherits(stock, "FLStock"))
  	   stop("FLStock must be an 'FLStock' object")
   if(!inherits(control, "FLSTF.control"))
	     stop("FLSTF.control must be an 'FLSTF.control' object")

  res <- new('FLSTF', window(stock, dims(catch.n(stock))$minyear,
		dims(catch.n(stock))$maxyear + control@nyrs))

   res@range   <- stock@range
   res@control <- control
   res@name    <- stock@name
   res@desc <- paste("Original data source: ", stock@desc, ". Forecast for",
   	control@nyrs, "years")

   nages <-  dim(stock@landings.n)[1]
   dms   <- dimnames(stock@catch.n[,,unit,season,area,iter])
   dms$year <- as.character(stock@range["minyear"]:(stock@range["maxyear"]+control@nyrs))

   ages<-as.character(stock@range["min"]:stock@range["max"])
   yrs <-as.character(stock@range["minyear"]:stock@range["maxyear"])

   pred.years   <- as.character((stock@range["maxyear"]+1):(stock@range["maxyear"]+control@nyrs))
   pred.years.n <- as.character(stock@range["maxyear"]:(stock@range["maxyear"]+control@nyrs))

   ## define a vector of fmultipliers
   if (length(control@fmult)==1) fmult <- rep(control@fmult, control@nyrs)
   if (length(control@fmult)== control@nyrs) fmult <- control@fmult
   if (length(control@fmult)!=1 && length(control@fmult)!=control@nyrs)
        stop("Error: fmult is not of the right length")

   f.partn.yrs <- as.character((stock@range["maxyear"]-control@fbar.nyrs+1):stock@range["maxyear"])
   f.partn <- apply(stock@landings.n[,f.partn.yrs,unit,season,area]/stock@catch.n[,f.partn.yrs,unit,season,area],1,mean)
   f.partition <- as.FLQuant(pmin(1, as.vector(f.partn)), dimnames=dimnames(f.partn))

   if(any(is.na(f.partition)))
     if(all(stock@discards.n[is.na(f.partition),f.partn.yrs] == 0))
       f.partition[is.na(f.partition)] <- 1
   
   ## get recruitment estimates, if not specified in control object for all years of forecast
   ## if the recruitment is NA, estimate it
   if(any(is.na(control@rec))) {
      if(is.na(control@rec.yrs[1])) control@rec.yrs[1] <- stock@range["minyear"]
      if(is.na(control@rec.yrs[2])) control@rec.yrs[2] <- stock@range["maxyear"]-2
      if((control@rec.yrs[1] < res@range["minyear"]) || (control@rec.yrs[1] > stock@range["maxyear"]) ||
         (control@rec.yrs[2] < res@range["minyear"]) || (control@rec.yrs[2] > stock@range["maxyear"])) stop ("recruitment range outside stock range!")
      control@rec <- rep(exp(mean(log(stock@stock.n[1,as.character(control@rec.yrs[1]:control@rec.yrs[2]),unit,season,area]))),control@nyrs)
   }
   ## if recruitment is given as a single value, replicate across all years
  if(length(control@rec) != control@nyrs)
    control@rec <- rep(control@rec[1],control@nyrs)

   ## calculate the forecast Ns, Fs and Cs
   res@harvest[,pred.years,,,]   <- proj.harvest(res, control@fbar.nyrs, control@f.rescale, control@fbar.min,control@fbar.max, control@rec,(stock@range["maxyear"]+1):(stock@range["maxyear"]+control@nyrs) , fmult)

   ## Added by L Kell 6th July 2006, this allows F's to be specified, other than recent average, if supplied as an argument to method call
   if (!missing(harvest))
      {
      harvest.yrs<-dimnames(harvest)$year[dimnames(harvest)$year %in% pred.years]
      res@harvest[,harvest.yrs,,,]   <- harvest[,harvest.yrs,,,]
      }

   av.yrs <- as.character((dims(stock@m)$maxyear-control@wts.nyrs+1):dims(stock@m)$maxyear)

   for(s. in list("landings.wt", "discards.wt", "catch.wt", "stock.wt", "m", "mat", "harvest.spwn", "m.spwn")) {
     slot(res, s.)[,pred.years,,,]  <- apply(slot(res, s.)[,av.yrs,,,],1,mean)
   }
   
   res@stock.n[,pred.years.n,,,] <- proj.stock.n(res@stock.n[,pred.years.n,,,], res@harvest[,pred.years.n,,,], res@m[,pred.years.n,,,], control@rec, survivors)
   res@catch.n[,pred.years,,,]   <- proj.catch.n(res@stock.n[,pred.years,,,], res@harvest[,pred.years,,,], res@m[,pred.years,,,])


   ## ********** Catch constraint bit *************

    if (!is.na(control@catch.constraint)){
    
      constraint.yr <- res@range["maxyear"]+2
      
      ## check that catch.constraint >= 0
      if (control@catch.constraint<0.0) stop("catch.constraint -ve")

      ## check that catch.constraint is possible
      if (control@catch.constraint > apply(res@stock.n[,as.character(constraint.yr-1),,,]*
                        res@stock.wt[,as.character(constraint.yr-1),,,],2,sum))
         stop("catch.constraint > stock biomass")

      n  <- res@stock.n[,as.character(constraint.yr-1),,,]
      f  <- res@harvest[,as.character(constraint.yr-1),,,]
      fl  <- res@harvest[,as.character(constraint.yr-1),,,] * f.partition
      m  <- res@m[,as.character(constraint.yr-1),,,]
      wt <- res@catch.wt[,as.character(constraint.yr-1),,,]

      F <- 5.0

      catch.eq <- expression(sum((F*f)/(F*f+m)*n*(1-exp(-(F*f+m)))*wt, na.rm=TRUE))

      TAC  <- control@catch.constraint
      diff <- 1

      while(abs(diff) > 0.000001) {
        Fold <- F
        Y  <- eval(catch.eq) - TAC
        dY <- sum(f*n*wt*(m-exp(-F*f-m)*m+exp(-F*f-m)*F^2*f^2+exp(-F*f-m)*F*f*m)/(F*f+m)^2, na.rm=TRUE)
        diff <- Y/dY
        F <- Fold - diff
      }
      fmult[1] <- F
      res@harvest[,as.character(constraint.yr-1),,,] <- res@harvest[,as.character(constraint.yr-1),,,] * fmult[1]
      # re-calculate stock and catch
      res@stock.n[,pred.years.n,,,] <- proj.stock.n(res@stock.n[,pred.years.n,,,], res@harvest[,pred.years.n,,,], res@m[,pred.years.n,,,], control@rec, survivors)
      res@catch.n[,pred.years,,,]   <- proj.catch.n(res@stock.n[,pred.years,,,], res@harvest[,pred.years,,,], res@m[,pred.years,,,])

      }

  ## ***************************************************

  ## ********** Landings constraint bit *************

    if (!is.na(control@landings.constraint)){

      constraint.yr <- res@range["maxyear"]+2

      ## check that catch.constraint >= 0
      if (control@landings.constraint<0.0) stop("landings.constraint -ve")

      ## check that landings.constraint is possible
      ## note that this is not a proper test if you have discards too
      if (control@landings.constraint > apply(res@stock.n[,as.character(constraint.yr-1),,,]*
                        res@stock.wt[,as.character(constraint.yr-1),,,],2,sum))
         stop("catch.constraint > stock biomass")

      n  <- res@stock.n[,as.character(constraint.yr-1),,,]
      f  <- res@harvest[,as.character(constraint.yr-1),,,]
      fl  <- res@harvest[,as.character(constraint.yr-1),,,] * f.partition
      m  <- res@m[,as.character(constraint.yr-1),,,]
      wt <- res@catch.wt[,as.character(constraint.yr-1),,,]

      F <- 5.0

      landings.eq <- expression(sum((F*fl)/(F*f+m)*n*(1-exp(-(F*f+m)))*wt, na.rm=TRUE))

      TAC  <- control@landings.constraint
      diff <- 1

      while(abs(diff) > 0.000001) {
        Fold <- F
        Y  <- eval(landings.eq) - TAC
        dY <- sum(fl*n*wt*(m-exp(-F*f-m)*m+exp(-F*f-m)*F^2*f^2+exp(-F*f-m)*F*f*m)/(F*f+m)^2, na.rm=TRUE)
        diff <- Y/dY
        F <- Fold - diff
      }
      fmult[1] <- F
      res@harvest[,as.character(constraint.yr-1),,,] <- res@harvest[,as.character(constraint.yr-1),,,] * fmult[1]
      # re-calculate stock and catch
      res@stock.n[,pred.years.n,,,] <- proj.stock.n(res@stock.n[,pred.years.n,,,], res@harvest[,pred.years.n,,,], res@m[,pred.years.n,,,], control@rec, survivors)
      res@catch.n[,pred.years,,,]   <- proj.catch.n(res@stock.n[,pred.years,,,], res@harvest[,pred.years,,,], res@m[,pred.years,,,])
      }

  ## ***************************************************

  ## ************** SSB constraint bit ********************

    if (!is.na(control@ssb.constraint)){
      ## check that ssb.constraint >= 0
      if (control@ssb.constraint<0.0) stop("ssb.constraint -ve")

      constraint.yr <- res@range["maxyear"] + control@nyrs

      n  <- c(control@rec[2],res@stock.n[,as.character(constraint.yr-1),,,])
      f  <- c(0,res@harvest[,as.character(constraint.yr-1),,,])
      m  <- c(0,res@m[,as.character(constraint.yr-1),,,])
      wt <- c(res@stock.wt[,as.character(constraint.yr),,,],res@stock.wt[nages,as.character(constraint.yr),,,])
      mat<- c(res@mat[,as.character(constraint.yr),,,],res@mat[nages,as.character(constraint.yr),,,])

      F <- 5.0

      ssb.eq <- expression(sum(n*exp(-F*f-m)*mat*wt))

      SSB  <- control@ssb.constraint
      diff <- 1

      while(abs(diff) > 0.000001) {
        Fold <- F
        Y  <- eval(ssb.eq) - SSB
        dY <- -sum(n*f*exp(-F*f-m)*mat*wt)
        diff <- Y/dY
        F <- Fold - diff
      }
      if(F < 0) stop(paste("ssb.constraint > max possible ssb in", constraint.yr))
      
      fmult[control@nyrs-1] <- F
      res@harvest[,as.character(constraint.yr-1),,,] <- res@harvest[,as.character(constraint.yr-1),,,] * fmult[control@nyrs-1]
      # re-calculate stock and catch
      res@stock.n[,pred.years.n,,,] <- proj.stock.n(res@stock.n[,pred.years.n,,,], res@harvest[,pred.years.n,,,], res@m[,pred.years.n,,,], control@rec, survivors)
      res@catch.n[,pred.years,,,]   <- proj.catch.n(res@stock.n[,pred.years,,,], res@harvest[,pred.years,,,], res@m[,pred.years,,,])

      }

   ## Calculate catch components
   res@landings.n[,pred.years,,,] <- sweep(res@catch.n[,pred.years,,,], 1, f.partition, "*")
   res@discards.n[,pred.years,,,] <- sweep(res@catch.n[,pred.years,,,], 1, (1-f.partition), "*")

   ## SOP corrections
   if(sop.correct==TRUE) {
     res@landings.n[,pred.years,,,] <- res@landings.n[,pred.years,,,] * (res@landings.n[,pred.years,,,]*res@catch.wt[,pred.years,,,])/(res@landings.n[,pred.years,,,]*res@landings.wt[,pred.years,,,])
     res@discards.n[,pred.years,,,] <- res@discards.n[,pred.years,,,] * (res@discards.n[,pred.years,,,]*res@catch.wt[,pred.years,,,])/(res@discards.n[,pred.years,,,]*res@discards.wt[,pred.years,,,])
   }  
   
   ## Calculate catch biomasses
   dms$age <- "all"
   res@landings   <- as.FLQuant(cbind(matrix(stock@landings[,yrs,unit,season,area], nrow=1),matrix(apply(res@landings.n[,pred.years,unit,season,area]*res@landings.wt[,pred.years,unit,season,area],2,sum),nrow=1)), dimnames=dms, units=units(stock@landings))
   res@discards   <- as.FLQuant(cbind(matrix(stock@discards[,yrs,unit,season,area], nrow=1),matrix(apply(res@discards.n[,pred.years,unit,season,area]*res@discards.wt[,pred.years,unit,season,area],2,sum),nrow=1)), dimnames=dms, units=units(stock@discards))
   res@catch      <- as.FLQuant(cbind(matrix(stock@catch[,yrs,unit,season,area], nrow=1),matrix(apply(res@catch.n[,pred.years,unit,season,area]*res@catch.wt[,pred.years,unit,season,area],2,sum),nrow=1)), dimnames=dms, units=units(stock@catch))

   ## Calculate Stock - better to write a Stock method for FLStock class but this will do in the mean time
   res@stock <- quantSums(res@stock.n * res@stock.wt)

   slot(res, "range")["maxyear"] <- slot(res, "range")["maxyear"]+slot(control, "nyrs")

   ## Update fmult so it returns the fmult used in forecast (in case catch or ssb.constraint routine has altered it)
   res@control@fmult <- fmult
   
   class(res) <- list("FLSTF","FLStock")
   
   return(res)

}
# Example: test <- test.FLSTF(tmp, control=stf.control, survivors=TRUE)


## -----------------------------------------------------------------------------------------------------------------
## Method: proj.stock.n
## -----------------------------------------------------------------------------------------------------------------
proj.stock.n <- function(stock.n, harvest, m, rec, survivors) {

	if(!inherits(stock.n, "FLQuant") || !inherits(harvest, "FLQuant") || !inherits(harvest, "FLQuant") )
		stop("stock.n and harvest and M must be an 'FLQuants'!")

  nages     <- dims(stock.n)$age
  nyears    <- dims(stock.n)$year
  minyear   <- dims(stock.n)$minyear
  maxyear   <- dims(stock.n)$maxyear

  Ns        <- matrix(NA, nrow=nages, ncol=nyears)
  Ns[,1]    <- stock.n[,as.character(minyear),,,]

  p <- 1
  #check for survivors
  if (!all(is.na(survivors))){
      if (length(survivors) == nages) survivors <- as.numeric(survivors)[2:nages]
      else if (length(survivors) == (nages -1)) survivors <- as.numeric(survivors)
      else stop("length of survivors smaller than ages - 1 or larger than ages")
      Ns[,2] <- c(rec[1],survivors)
      p <-  2
  }


  for(y in (minyear + p):maxyear ) {

    i <- y - minyear + 1

    N <- c(rec[i-1],Ns[,i-1] * exp(-harvest[,i-1,,,]-m[,i-1,,,]))
		N[length(N)-1] <- N[length(N)-1] + N[length(N)]
		N <- N[1:length(N)-1]
		Ns[,i] <- N
  }

	return(Ns)
}



## -----------------------------------------------------------------------------------------------------------------
## Method: proj.catch.n
## -----------------------------------------------------------------------------------------------------------------
proj.catch.n <- function(stock.n, harvest, m) {

	if(!inherits(stock.n, "FLQuant") || !inherits(harvest, "FLQuant") || !inherits(harvest, "FLQuant") )
		stop("stock.n and harvest and M must be an 'FLQuants'!")

  nages     <- dims(stock.n)$age
  nyears    <- dims(stock.n)$year
  minyear   <- dims(stock.n)$minyear
  maxyear   <- dims(stock.n)$maxyear

  Cs        <- matrix(NA, nrow=nages, ncol=nyears)

	for(y in minyear:maxyear ) {

    i <- y - minyear + 1

		C     <- harvest[,i,,,]/(harvest[,i,,,]+m[,i,,,])*stock.n[,i,,,]*(1-exp(-harvest[,i,,,]-m[,i,,,]))
  	Cs[,i] <- C
  }

	return(Cs)
}
# proj.catch.n (xsa.stock, fbar.nyrs=3, F.rescale=TRUE, fbar.min=2, fbar.max=6, rec=0, years=c(2005:2007), fmult=c(1,1,1), unit=1, season=1, area=1)



## -----------------------------------------------------------------------------------------------------------------
## Method: proj.harvest
## -----------------------------------------------------------------------------------------------------------------
proj.harvest <- function(stock, fbar.nyrs, F.rescale=FALSE, fbar.min=2, fbar.max=3, rec, years=c(2005:2007), fmult=c(1,1,1), unit=1, season=1, area=1) {

	if(!inherits(stock, "FLStock") && !inherits(stock, "FLSTF"))
		stop("stock must be an 'FLStock' or 'FLSTF' object!")

  # test if the stock has not been forecast with Ns yet
  if (max(years) != as.numeric(stock@range["maxyear"]) ) {
	  yr <- as.numeric(stock@range["maxyear"])
  	fb <- rowMeans(stock@harvest[, as.character((stock@range["maxyear"]-fbar.nyrs+1):as.numeric(stock@range["maxyear"])),unit,season,area])
		last.fbar <- mean(stock@harvest[as.character(fbar.min:fbar.max), as.character(stock@range["maxyear"]),unit,season,area])
  } else {
  	yr <- as.numeric(stock@range["maxyear"]) - length(years)
  	fb <- rowMeans(stock@harvest[, as.character(((stock@range["maxyear"]-fbar.nyrs-length(years)+1):(as.numeric(stock@range["maxyear"])-length(years)))),unit,season,area])
		last.fbar <- mean(stock@harvest[as.character(fbar.min:fbar.max), as.character(stock@range["maxyear"]-length(years)),unit,season,area])
  }

	## to rescale F at age
	if(F.rescale==TRUE) {
		mean.fbar <- mean(fb[as.character(fbar.min:fbar.max)])
		fb <- fb*last.fbar/mean.fbar
	}

  Hs <- matrix(0, nrow=stock@range["max"]-stock@range["min"]+1,
                  ncol=length(years),
                  dimnames=list(c(stock@range["min"]:stock@range["max"]), c(years))
               )

	for(y in years ) {
    i <- y - yr
		H     <- fb * fmult[i]
  	Hs[,i] <- H
  }

	return(Hs)
}

# ********** The constraining functions ********

constrain.catch<-function(fmult, stock, control, res, pred.years, pred.years.n, survivors){
   res@harvest[,pred.years,,,]   <- proj.harvest(res, control@fbar.nyrs, control@f.rescale, control@fbar.min,control@fbar.max, control@rec,(stock@range["maxyear"]+1):(stock@range["maxyear"]+control@nyrs) , fmult)
   res@stock.n[,pred.years.n,,,] <- proj.stock.n(res@stock.n[,pred.years.n,,,], res@harvest[,pred.years.n,,,], res@m[,pred.years.n,,,], control@rec, survivors)
   res@catch.n[,pred.years,,,]   <- proj.catch.n(res@stock.n[,pred.years,,,], res@harvest[,pred.years,,,], res@m[,pred.years,,,])
   return (apply(res@catch.n[,pred.years[1]]*res@catch.wt[,pred.years[1]],2,sum))
   }

obj.catch<-function(x, stock, fmult.temp, control, res, pred.years, pred.years.n, survivors, catch.constraint){
  fmult.temp[1] <- x
  val<-constrain.catch(fmult.temp, stock, control, res, pred.years, pred.years.n, survivors)
  return(as.double((val-catch.constraint)^2))
  }

constrain.ssb<-function(fmult, stock, control, res, pred.years, pred.years.n, survivors){
   res@harvest[,pred.years,,,]   <- proj.harvest(res, control@fbar.nyrs, control@f.rescale, control@fbar.min,control@fbar.max, control@rec,(stock@range["maxyear"]+1):(stock@range["maxyear"]+control@nyrs) , fmult)
   res@stock.n[,pred.years.n,,,] <- proj.stock.n(res@stock.n[,pred.years.n,,,], res@harvest[,pred.years.n,,,], res@m[,pred.years.n,,,], control@rec, survivors)
   res@catch.n[,pred.years,,,]   <- proj.catch.n(res@stock.n[,pred.years,,,], res@harvest[,pred.years,,,], res@m[,pred.years,,,])
   res.ssb<-ssb(res)
   return (as.numeric(ssb(res)[,dim(ssb(res))[2]]))
   }

obj.ssb<-function(x, stock, fmult.temp, control, res, pred.years, pred.years.n, survivors, ssb.constraint){
  fmult.temp[2] <- x
  val<-constrain.ssb(fmult.temp, stock, control, res, pred.years, pred.years.n, survivors)
  return(as.double((val-ssb.constraint)^2))
  }

## ************* Other methods ***************

setMethod("show", signature(object="FLSTF.control"),
 function(object){
# Just setting tabs up through trial and error - could be done better
# Also this falls over if old FLSTF.control (without catch.constraint and ssb.constraint) is used
# Ideally need to test if these slots are filled.
        n.<-slotNames(object)
        for (i in 1:length(n.))
          if(nchar(n.[i])<7)
            {cat(n.[i],"\t\t\t",slot(object,n.[i]),"\n")}
          else{
          if(nchar(n.[i])>=16)
            {cat(n.[i],"\t",slot(object,n.[i]),"\n")}
            else{if(nchar(n.[i])>=7)
              {cat(n.[i],"\t\t",slot(object,n.[i]),"\n")}
              }
          }
    }
)

setMethod("summary", signature(object="FLSTF"),
	function(object, ...){
		cat("An object of class \"FLSTF\"\n\n")
		cat("Name:", object@name, "\n")
		cat("Description:", object@desc, "\n")
		cat("Range:\tmin\tmax\tp+group\tminyear\tmaxyear\n")
		cat("", object@range, "\n", sep="\t")
		cat("Quant:", quant(object@catch), "\n\n")
		for (s in list("catch", "catch.n", "catch.wt", "discards", "discards.n",
					   "discards.wt", "landings", "landings.n", "landings.wt",
					   "stock", "stock.n", "stock.wt", "harvest",
					   "harvest.spwn", "m", "m.spwn", "mat")) {
				 if (sum(!complete.cases(slot(object, s))) == length(slot(object,s)))
				cat(substr(paste(s, "          "), start=1, stop=12), " : EMPTY\n") else
				cat(substr(paste(s, "          "), start=1, stop=12), " : [", dim(slot(object,s)),"], units = ", slot(object,s)@units, "\n")
		}
		cat("\nControl slot details:\n")
		show(object@control)
	}
)

if (!isGeneric("update")) {
	setGeneric("update", function(object, ...){
		value <- standardGeneric("update")
		value
	})
}

setMethod("update", signature("FLSTF"), function(object, ...){

  old.nyrs <- slot(slot(object,"control"),"nyrs")
  control  <- slot(object,"control")

  args <- list(...)

  if(!is.null(args[["fbar.nyrs"]])) slot(control,"fbar.nyrs") <- args[["fbar.nyrs"]]
	if(!is.null(args[["fbar.min"]]))  slot(control,"fbar.min")  <- args[["fbar.min"]]
	if(!is.null(args[["fbar.max"]]))  slot(control,"fbar.max")  <- args[["fbar.max"]]
	if(!is.null(args[["f.rescale"]])) slot(control,"f.rescale") <- args[["f.rescale"]]
	if(!is.null(args[["wts.nyrs"]]))  slot(control,"wts.nyrs")  <- args[["wts.nyrs"]]
	if(!is.null(args[["rec"]]))       slot(control,"rec")       <- args[["rec"]]
	if(!is.null(args[["rec.yrs"]]))   slot(control,"rec.yrs")   <- args[["rec.yrs"]]
	if(!is.null(args[["nyrs"]]))      slot(control,"nyrs")      <- args[["nyrs"]]
	if(!is.null(args[["catch.constraint"]])) slot(control,"catch.constraint") <- args[["catch.constraint"]]
  if(!is.null(args[["ssb.constraint"]])) slot(control,"ssb.constraint")   <- args[["ssb.constraint"]]
  if(!is.null(args[["fmult"]]))     slot(control,"fmult") <- args[["fmult"]]
  

  yrs    <- as.numeric(dimnames(stock.n(object))$year)
  stock  <- trim(object, year=min(yrs):(max(yrs)-old.nyrs))
  res    <- FLSTF(stock, control, ...)
  
  return(res)
  }
)

setMethod("as.FLStock", signature("FLSTF"), function(object){
  res    <- FLStock()
  names. <- names(getSlots("FLStock"))
  for(s. in names.)
    slot(res, s.) <- slot(object, s.)
  return(res)
  }
)

## Management Options Table
## Code under development - might be OK but not yet fully checked
stf.options <- function(stf, fmults=seq(0,2,by=0.2), fpa=NA, bpa=NA, fpa.mult=FALSE, ...) {

  forc.yr <- max(as.numeric(dimnames(stock.n(stf))$year))
  last.yr <- forc.yr - stf@control@nyrs
  fbar.yr <- last.yr - stf@control@fbar.nyrs +1
  
  fmult.yr1 <- stf@control@fmult[1]

  if(!is.na(fpa)){
    fsq    <- mean(as.numeric(apply(trim(harvest(stf),ages=stf@control@fbar.min:stf@control@fbar.max),2,mean)[,as.character(fbar.yr:last.yr)]))
    fpam   <- fpa/fsq
    fmults <- sort(c(fmults, fpam))
    
    if(fpa.mult) fmults <- fmults * fpam
  }
  if(!is.na(bpa)){
    stf.bpa <- update(stf, ssb.constraint=bpa)
    fsq     <- mean(as.numeric(apply(trim(harvest(stf)    ,ages=stf@control@fbar.min:stf@control@fbar.max),2,mean)[,as.character(fbar.yr:last.yr)]))
    fbar    <- mean(as.numeric(apply(trim(harvest(stf.bpa),ages=stf@control@fbar.min:stf@control@fbar.max),2,mean)[,as.character(forc.yr-1)]))
    bpam    <- fbar/fsq
    fmults  <- sort(c(fmults, bpam))
  }
  
  res <- numeric(length=7)
  names(res) <- c(paste("TSB",as.character(forc.yr-1)),
                  paste("SSB",as.character(forc.yr-1)),
                  "Fmult","Fbar",
                  paste("Landings",as.character(forc.yr-1)),
                  paste("TSB",as.character(forc.yr)),
                  paste("SSB",as.character(forc.yr)))
  if(fpa.mult) {
    res <- numeric(length=8)
  names(res) <- c(paste("TSB",as.character(forc.yr-1)),
                  paste("SSB",as.character(forc.yr-1)),
                  "Fmult","Fpa.mult","Fbar",
                  paste("Landings",as.character(forc.yr-1)),
                  paste("TSB",as.character(forc.yr)),
                  paste("SSB",as.character(forc.yr)))
  }
  
  stf@control@ssb.constraint <- as.numeric(NA)
  
  for(fm in fmults) {
    stf <- update(stf, fmult=c(fmult.yr1,fm,fm),...)

    res <- rbind(res, c(round(as.numeric(quantSums(stock.n(stf)*stock.wt(stf))[,as.character(last.yr+2)]),0),
                      round(as.numeric(ssb(stf)[,as.character(last.yr+2)]),0),
                      round(as.numeric(fm),3),
                      if(fpa.mult) round(as.numeric(fm*1/fpam),3),
                      round(mean(as.numeric(apply(trim(harvest(stf),ages=stf@control@fbar.min:stf@control@fbar.max),2,mean)[,as.character(last.yr+1)]))*fm,4),
                      round(as.numeric(landings(stf)[,as.character(last.yr+2)])),
                      round(as.numeric(quantSums(stock.n(stf)*stock.wt(stf))[,as.character(forc.yr)]),0),
                      round(as.numeric(ssb(stf)[,as.character(forc.yr)]),0)))
  }
  return(res[2:length(res[,1]),])
}


