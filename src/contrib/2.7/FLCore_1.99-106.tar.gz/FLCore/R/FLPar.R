# FLPar - common structure for parameter matrices of various types.
# FLCore/R/FLPar.R

# Copyright 2003-2007 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, Cefas
# $Id: FLPar.R,v 1.24 2008/06/09 07:13:18 imosqueira Exp $

# Reference:
# Notes:

# Validity  {{{
validFLPar <- function(object) {

	# Dimensions can be 2 or 3
	if(length(dim(object)) > 3)
		stop("FLPar objects only defined for 2 or 3 dimensions")
	# First dimnames name to be iter
	if(names(dimnames(object))[1] != "iter")
		stop("First dimension must be named iter")
	return(TRUE)
}   # }}}

# FLPar {{{
setClass('FLPar', representation('array', units='character'),
	prototype=prototype(array(as.numeric(NA), dim=c(1,1),
	dimnames=list(iter=1, param="")), units='NA'), validity=validFLPar)
remove(validFLPar)
# }}}

# Constructors  {{{
if (!isGeneric("FLPar"))
	setGeneric("FLPar", function(object, ...)
		standardGeneric("FLPar"))

# FLPar(array)
setMethod('FLPar', signature(object="array"),
	function(object, iter=seq(dim(object)[1]), params=letters[1:dim(object)[2]],
    units=rep('NA', dim(object)[2]), dimnames=list(iter=iter, params=params))
	{
    if(!is.null(dimnames(object)))
      dimnames <- dimnames(object)
		res <- array(object, dim=dim(object), dimnames=dimnames)
		return(new('FLPar', res, units=units))
	}
)
	
# FLPar(missing, iter, param)
setMethod('FLPar', signature(object="missing"),
	function(iter=1, params='a', dimnames=list(iter=seq(1:iter), params=params), units='NA')
	{
		res <- array(as.numeric(NA), dim=unlist(lapply(dimnames, length)),
      dimnames=dimnames)
		return(FLPar(res, units=units, dimnames=dimnames(res)))
	}
)

# FLPar(vector)
setMethod('FLPar', signature('vector'),
	function(object, params='a', iter=seq(length(object)/length(params)), byrow=FALSE,
    units='NA')
  {
		res <- array(matrix(object, ncol=length(params), nrow=length(iter), byrow=byrow),
        dim=c(length(iter), length(params)))
		return(FLPar(res, units=units, params=params, iter=iter))
	}
)

# FLPar(FLPar)
setMethod('FLPar', signature('FLPar'),
	function(object, params=dimnames(object)$params, iter=dim(object)['iter'],
    units=object@units)
  {
    res <- FLPar(iter=iter, params=params, units=units)
    dmns <- dimnames(object)
    res[dmns$iter, dmns$params[dmns$params %in% dimnames(res)$params]] <- object[, dimnames(res)$params[dimnames(res)$params %in% dmns$params]]
    return(res)
	}
) # }}}

# '['   {{{
setMethod('[', signature(x='FLPar'),
    function(x, i='missing', j='missing', ..., drop=FALSE)
    {
		  dx <- dim(x)
  		if (missing(i))
        i  <-  seq(1, dx[1])
      if (missing(j))
        j  <-  seq(1, dx[2])

      if(length(dx) == 2)
        return(new(class(x), as.array(x@.Data[i, j, drop=FALSE])))
      else
      {
        # if ... is missing, list(...) fails
		  	args <- try(list(...), silent=TRUE)
        # so create a list using dx
        if(class(args) == 'try-error')
          k <- lapply(as.list(dx[-c(1,2)]), function(x) seq(1:x))
        else
        # and use only the section required when list(...) exists
          k <- c(args, lapply(as.list(dx[-seq(1:(2+length(args)))]),
            function(x) seq(1:x)))

        return(new(class(x), as.array(do.call('[',
          c(list(x@.Data, i, j), k, list(drop=FALSE))))))
      }
    }
)   # }}}

# "[<-"     {{{
setMethod("[<-", signature(x="FLPar"),
	function(x, i="missing", j="missing", ..., value="missing") {

        if(missing(i))
			i  <-  seq(1, length(dimnames(x@.Data)[1][[1]]))
		if (missing(j))
			j  <-  dimnames(x@.Data)[2][[1]]

        if(length(dim(x)) == 2)
            x@.Data[i, j] <- value
		else {
			args <- list(...)
			if(length(args) == 0)
				k <- seq(1, dx[3])
			else
				k <- args[[1]]
			x@.Data[i, j, k] <- value
         }

		 return(x)
	}
)   # }}}

# iter, iter<-  {{{
setMethod("iter", signature(object="FLPar"),
	function(object, iter) {
		return(object[iter,])
	}
)
setMethod("iter<-", signature(object="FLPar", value="FLPar"),
	function(object, iter, value)
  {
		object[iter,] <- value
		return(object)
	}
) # }}}

# summary   {{{
setMethod('summary', signature(object='FLPar'),
	function(object, ...) {
		cat("An object of class \"", class(object), "\"\n\n", sep="")
		return(apply(object@.Data, seq(dim(object))[-1], summary))
  }
)   # }}}

# plots {{{

# plot
setMethod("plot", signature(x="FLPar", y="missing"),
	function(x, y="missing", ...) {

			# get dimensions to condition on (skip quant)
			condnames <- names(dimnames(x))[-1]
			cond <- paste(condnames, collapse="+")
			if(cond != "") cond <- paste("|", cond)
				formula <- formula(paste("~data", cond))
			# set strip to show conditioning dimensions names
			strip <- strip.custom(var.name=condnames, strip.names=c(TRUE,TRUE))

		densityplot(formula, as.data.frame(x, row.names='row'), ylab="", xlab="",
			scales=list(y=list(draw=FALSE), relation='free'), col='black')
	}
)

# densityplot
if (!isGeneric("densityplot")) {
	setGeneric("densityplot", useAsDefault = densityplot)
}

setMethod("densityplot", signature("formula", "FLPar"), function(x, data, ...){
	lst <- substitute(list(...))
	lst <- as.list(lst)[-1]
	lst$data <- as.data.frame(data, row.names='row')
	lst$x <- x
	do.call("densityplot", lst)
})

# histogram
setMethod("histogram", signature("formula", "FLPar"), function(x, data, ...){
	lst <- substitute(list(...))
	lst <- as.list(lst)[-1]
	data <- as.data.frame(data)
	lst$data <- data.frame(param=rep(names(data), each=nrow(data)),
		data=as.vector(unlist(c(data))))
	lst$x <- x
	do.call("histogram", lst)
})

# splom
if (!isGeneric("splom")) {
	setGeneric("splom", useAsDefault = splom)
}

setMethod("splom", signature("FLPar", "missing"),
	function(x, data, ...){
		splom(as.data.frame(x))
	}
)   # }}}

# units        {{{
setMethod("units", signature(x="FLPar"),
	function(x)
		return(x@units)
) # }}}

# units<-      {{{
setMethod("units<-", signature(x="FLPar", value="character"),
	function(x, value) {
		x@units <- value
		return(x)
	}
) # }}}

# as.data.frame     {{{
setMethod("as.data.frame", signature(x="FLPar"),
	function(x, row.names='col', optional=FALSE)
		if(length(dim(x)) == 2 && row.names == 'col')
			return(as.data.frame(x@.Data))
		else
			return(data.frame(expand.grid(dimnames(x))[-1], data=as.vector(x@.Data)))
)   # }}}

# mean, median, var, quantile   {{{
# TODO review for 3D param objects
setMethod("mean", signature(x='FLPar'),
	function(x, ...)
		return(apply(x, seq(length(dim(x)))[-1], mean, ...))
)

setMethod("median", signature(x='FLPar'),
	function(x, na.rm=FALSE)
		return(apply(x, seq(length(dim(x)))[-1], median, na.rm=na.rm))
)

setMethod("var", signature(x='FLPar'),
	function(x, y=NULL, na.rm=FALSE, use='all.obs')
		return(apply(x, seq(length(dim(x)))[-1], var, na.rm=na.rm))
)   # }}}

# coerce  {{{
setAs('FLPar', 'numeric',
  function(from)
  {
    res <- as.vector(from[1,])
    names(res) <- dimnames(from)$param
    
    return(res)
  }
)
setAs('FLPar', 'list',
  function(from)
  {
    res <- vector("list", length = dim(from)[2])
    names(res) <- dimnames(from)$param
    for(i in seq(names(res)))
      res[[i]] <- as.vector(from[,i])
    return(res)
  }
)
# }}}

# propagate {{{
setMethod("propagate", signature(object="FLPar"),
  function(object, iter)
  {
    FLPar(object, iter=iter)
  }
) # }}}

# iter     {{{
setMethod("iter", signature(object="FLPar"),
	function(object, iter) {
    if(dim(object)[1] == 1)
      return(object)
    else
      return(object[iter,])
	}
)   # }}}

## dims       {{{
setMethod("dims", signature(obj="FLPar"),
	# Return a list with different parameters
	function(obj, ...){
		iter <- as.numeric(dimnames(obj)$iter)
    params <- dimnames(obj)$params
		return(list(iter=iter, params=params))
	}
)   # }}}

