# FLArray-class - Base class for FLQuant and FLCohort

# Copyright 2003-2008 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, Cefas
# $Id: FLArray.R,v 1.10 2008/06/06 13:33:39 imosqueira Exp $

## Class {{{
validFLArray  <-  function(object){
	# Make sure there are at least 6 dimensions in the array
	Dim  <-  dim(object)
	if (length(Dim) != 6) 
		return("the array must have 6 dimensions")

	if (!is.numeric(object) && !is.na(object)) 
		return("array is not numeric")

	# check "units" slot
	if(!is.character(object@units))
		return("units must be a string")
	# Everything is fine
	return(TRUE)
}

setClass("FLArray",	representation("array", units="character"),
	prototype(array(as.numeric(NA), dim=c(1,1,1,1,1,1)), units="NA"),
	validity=validFLArray
) # }}}

# units {{{
if (!isGeneric("units"))
	setGeneric("units", useAsDefault=units)
setMethod("units", signature(x="FLArray"),
	function(x)
		return(x@units)
) # }}}

# units<- {{{
if (!isGeneric("units<-"))
	setGeneric("units<-", function(x, value)
		standardGeneric("units<-"))

setMethod("units<-", signature(x="FLArray", value="character"),
	function(x, value) {
		x@units <- value
		return(x)
	}
) # }}}

# quant        {{{
if (!isGeneric("quant"))
	setGeneric("quant", function(object, ...)
		standardGeneric("quant"))

setMethod("quant", signature(object="FLArray"),
	function(object) {
		return(names(dimnames(object))[1])
	}
) # }}}

# quant<-      {{{
if (!isGeneric("quant<-"))
	setGeneric("quant<-", function(object, value)
		standardGeneric("quant<-"))

setMethod("quant<-", signature(object="FLArray", value='ANY'),
	function(object, value) {
		dn <- dimnames(object)
		names(dn)[1] <- value
		attributes(object)$dimnames <- dn
		return(object)
	}
) # }}}

## "["             {{{
setMethod("[", signature(x="FLArray"),
    function(x, i, j, k, l, m, n, ..., drop=FALSE)
    {
	  	dx <- dim(x)
		  if (missing(i))
        i  <-  seq(1, dx[1])
      if (missing(j))
        j  <-  seq(1, dx[2])
      if (missing(k))
        k  <-  seq(1, dx[3])
      if (missing(l))
        l  <-  seq(1, dx[4])
      if (missing(m))
        m  <-  seq(1, dx[5])
      if (missing(n))
        n  <-  seq(1, dx[6])

      if(drop == TRUE)
        return(x@.Data[i, j, k, l, m, n, drop=TRUE])
      else
        x@.Data <- x@.Data[i, j, k, l, m, n, drop=FALSE]
      return(x)
	}
)

setMethod("[", signature(x="FLArray", i="array"),
  function(x, i, j=missing, ..., drop=missing)
  {
    x@.Data[i]
  }
)   # }}}

## "[<-"            {{{
setMethod("[<-", signature(x="FLArray"),
	function(x, i, j, k, l, m, n, ..., value="missing")
  {
		if(!missing(i) && is.array(i)) {
			x@.Data[i] <- value
			return(x)
		}

		dx <- dim(x)
		if (missing(i))
            i  <-  seq(1, dx[1])
        if (missing(j))
            j  <-  seq(1, dx[2])
        if (missing(k))
            k  <-  seq(1, dx[3])
        if (missing(l))
            l  <-  seq(1, dx[4])
        if (missing(m))
            m  <-  seq(1, dx[5])
        if (missing(n))
            n  <-  seq(1, dx[6])

		x@.Data[i,j,k,l,m,n] <- value

   		return(x)
	}
)   # }}}

## names         {{{
if (!isGeneric("names"))
	setGeneric("names")
setMethod("names", signature(x="FLArray"),
	function(x)
    names(dimnames(x))
)
# }}}

# iter     {{{
setGeneric("iter", function(object, ...)
	standardGeneric("iter"))

setMethod("iter", signature(object="FLArray"),
	function(object, iter) {
    if(dims(object)$iter == 1)
      return(object)
    else
      return(object[,,,,,iter])
	}
)   # }}}

## summary          {{{
if (!isGeneric("summary")) {
	setGeneric("summary", useAsDefault = summary)
}
setMethod("summary", signature(object="FLArray"),
	function(object, ...)
	{
		cat("An object of class \"", as.character(class(object)), "\" with:\n", sep="")
		cat("dim  : ", dim(object), "\n")
		cat("quant: ", quant(object), "\n")
		cat("units: ", units(object), "\n\n")
		if(all(is.na(object)))
		{
			cat("Min    :  NA\n")
			cat("1st Qu.:  NA\n")
			cat("Mean   :  NA\n")
			cat("Median :  NA\n")
			cat("3rd Qu.:  NA\n")
			cat("Max    :  NA\n")
		}
		else
		{
			cat("Min    : ", min(object, na.rm=TRUE), "\n")
			cat("1st Qu.: ", quantile(as.vector(object), 0.25, na.rm=TRUE), "\n")
			cat("Mean   : ", mean(as.vector(object), na.rm=TRUE), "\n")
			cat("Median : ", median(as.vector(object), na.rm=TRUE), "\n")
			cat("3rd Qu.: ", quantile(as.vector(object), 0.75, na.rm=TRUE), "\n")
			cat("Max    : ", max(object, na.rm=TRUE), "\n")
		}
		cat("NAs    : ", format(length(as.vector(object)
			[!complete.cases(as.vector(object))])/length(as.vector(object))*100,
			digits=2), "%\n")
	}
)   # }}}
