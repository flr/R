# FLStock.R - FLStock class and methods
# FLCore/R/FLStock.R

# Copyright 2003-2007 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Rob Scott, CEFAS
# $Id: FLStock.R,v 1.119 2008/06/16 14:44:51 imosqueira Exp $

# Reference:
# Notes:

## class :: FLStock			{{{
validFLStock <- function(object) {
	
	names <- names(getSlots('FLStock')[getSlots('FLStock')=="FLQuant"])
	for(i in names)
	{
		# all dimnames but iter are the same
		if(!identical(unlist(dimnames(object@catch.n)[2:5]),
			unlist(dimnames(slot(object, i))[2:5])))
			return(paste('All elements must share dimensions 2 to 5: Error in FLStock@', i))
		# no. iter are equal or one
	}
	for (i in names[!names%in%c('catch', 'landings', 'discards', 'stock')])
	{
		# quant is n
		if(!identical(unlist(dimnames(object@catch.n)[1]),
			unlist(dimnames(slot(object, i))[1])))
			return(paste('All elements must share quant names: Error in FLStock', i))
	}
	for (i in c('catch', 'landings', 'discards'))
	{
		# quant is 1
		if(dim(slot(object, i))[1] != 1)
			return(paste('Wrong dimensions for slot ', i, 'in FLStock'))
	}
	# check range
	dim <- dim(object@catch.n)
	dimnm <- dimnames(object@catch.n)
	if(all(as.numeric(object@range[4:5]) != c(as.numeric(dimnm$year[1]),
		as.numeric(dimnm$year[dim[2]]))))
		return('Range does not match object dimensions')
	
	return(TRUE)
}

setClass("FLStock",
	representation(
	"FLComp",
	catch	    ="FLQuant",
	catch.n	    ="FLQuant",
	catch.wt	="FLQuant",
	discards	="FLQuant",
	discards.n  ="FLQuant",
	discards.wt ="FLQuant",
	landings	="FLQuant",
	landings.n  ="FLQuant",
	landings.wt ="FLQuant",
	stock	    ="FLQuant",
	stock.n	    ="FLQuant",
	stock.wt	="FLQuant",
	m			="FLQuant",
	mat		    ="FLQuant",
	harvest	    ="FLQuant",
	harvest.spwn="FLQuant",
	m.spwn	    ="FLQuant"
	),
	prototype=prototype(
		name	= character(0),
		desc	= character(0),
		range	= unlist(list(min=0, max=0, plusgroup=NA, minyear=1, maxyear=1, minfbar=0, maxfbar=0)),
		catch	= FLQuant(),
		catch.n	= FLQuant(),
		catch.wt= FLQuant(),
		discards= FLQuant(),
		discards.n = FLQuant(),
		discards.wt= FLQuant(),
		landings   = FLQuant(),
		landings.n = FLQuant(),
		landings.wt= FLQuant(),
		stock	   = FLQuant(),
		stock.n	 = FLQuant(),
		stock.wt = FLQuant(),
		m		 = FLQuant(),
		mat		 = FLQuant(),
		harvest	 = FLQuant(units="f"),
		harvest.spwn = FLQuant(),
		m.spwn	 = FLQuant()
	),
  validity=validFLStock
)
setValidity("FLStock", validFLStock)
remove(validFLStock)

invisible(createFLAccesors("FLStock", exclude=c('name', 'desc', 'range', 'harvest')))	# }}}

# FLStock()   {{{
setGeneric('FLStock', function(object, ...)
		standardGeneric('FLStock'))
setMethod('FLStock', signature(object='FLQuant'),
  function(object, plusgroup=dims(object)$max, ...)
  {
    args <- list(...)

    # empty object
    object[] <- NA
    qobject <- quantSums(object)

    dims <- dims(object)

    res <- new("FLStock", 
    catch=qobject, catch.n=object, catch.wt=object,
    landings=qobject, landings.n=object, landings.wt=object,
    discards=qobject, discards.n=object, discards.wt=object,
    stock=qobject, stock.n=object, stock.wt=object,
    harvest=object, harvest.spwn=object, m=object, m.spwn=object, mat=object, 
    range = unlist(list(min=dims$min, max=dims$max, plusgroup=plusgroup,
			minyear=dims$minyear, maxyear=dims$maxyear, minfbar=dims$min, maxfbar=dims$max)))

    # Load given slots
  	for(i in names(args))
			slot(res, i) <- args[[i]]

    return(res)
  }
)

setMethod('FLStock', signature(object='missing'),
  function(...)
  {
    args <- list(...)

    # if no FLQuant argument given, then use empty FLQuant
    slots <- lapply(args, class)
    slots <- names(slots)[slots == 'FLQuant']
    if(length(slots) == 0)
      object <- FLQuant()
    else
    {
      qslots <- slots[!slots %in% c('catch','stock','landings','discards')]
      if(length(qslots) > 0)
        object <- args[[qslots[1]]]
      else
        object <- args[[slots]]
    }
    return(FLStock(object, ...))
  }
) # }}}

# is.FLStock	{{{
is.FLStock <- function(x)
	return(inherits(x, "FLStock"))	# }}}

## computeLandings	{{{
if (!isGeneric("computeLandings"))
setGeneric("computeLandings", function(object, ...)
		standardGeneric("computeLandings"))
setMethod("computeLandings", signature(object="FLStock"),
	function(object, na.rm=TRUE) {
        res <- quantSums(landings.n(object) * landings.wt(object), na.rm=na.rm)
        units(res) <- paste(units(landings.n(object)), "*",  units(landings.wt(object)))
        return(res)
 	} 
)	# }}}

## computeDiscards	{{{
if (!isGeneric("computeDiscards"))
	setGeneric("computeDiscards", function(object, ...)
		standardGeneric("computeDiscards"))
setMethod("computeDiscards", signature(object="FLStock"),
	function(object, na.rm=TRUE) {
        res <- quantSums(discards.n(object)*discards.wt(object), na.rm=na.rm)
        units(res) <- paste(units(discards.n(object)), units(discards.wt(object)))
        return(res)
 	} 
)	# }}}

## computeCatch	{{{
if (!isGeneric("computeCatch"))
	setGeneric("computeCatch", function(object, ...)
		standardGeneric("computeCatch"))
setMethod("computeCatch", signature(object="FLStock"),
    function(object, slot="catch", na.rm=TRUE)
	{    
        if(slot == "n"){
		# NA to 0
        	res <- landings.n(object) + discards.n(object)
            if (units(discards.n(object)) == units(landings.n(object)))
				units(res) <- units(discards.n(object))
        }
        else if(slot == "wt"){
        	res <- (landings.wt(object) * landings.n(object) +
        		discards.wt(object) * discards.n(object)) /
        	 	(landings.n(object) + discards.n(object))
			if (units(discards.wt(object)) == units(landings.wt(object)))
				units(res) <- units(discards.wt(object))
        }
		else if (slot == "all"){
			res <- FLQuants(catch=computeCatch(object, slot="catch"),
				catch.wt=computeCatch(object, slot="wt"),
				catch.n=computeCatch(object, slot="n"))
		}
        else {
			res <- quantSums(catch.n(object) * catch.wt(object), na.rm=na.rm)
            units(res) <- paste(units(catch.n(object)), units(catch.wt(object)))
        }
		return(res)
    }
)	# }}}

## computeLandings	{{{
if (!isGeneric("computeStock"))
setGeneric("computeStock", function(object, ...)
		standardGeneric("computeStock"))
setMethod("computeStock", signature(object="FLStock"),
	function(object, na.rm=TRUE) {
        res <- quantSums(stock.n(object) * stock.wt(object), na.rm=na.rm)
        units(res) <- paste(units(stock.n(object)), "*",  units(stock.wt(object)))
        return(res)
 	} 
)	# }}}

## plot  {{{
setMethod("plot", signature(x="FLStock", y="missing"),
	function(x, auto.key=TRUE, ...){
		dots <- list(...)
		obj <- FLQuants(list(catch=catch(x), landings=landings(x), discards=discards(x)))
		condnames <- names(dimnames(x@catch)[c(3:5)][dim(x@catch)[c(3:5)]!=1])
		cond <- paste(condnames, collapse="+")
		if(cond != "") cond <- paste("|", cond)
		formula <- formula(paste("data~year", cond))
		dots$x <- formula
		dots$data <- as.data.frame(obj)
		dots$ylab <- units(x@catch)
		dots$auto.key <- auto.key
		dots$type <- c("l")	
		dots$groups <- expression(qname)
		do.call("xyplot", dots)
	}
)	# }}}

## setPlusGroup function	{{{
#  changes the level of the plus group of the stock object
calc.pg <- function(s., i., k., r., pg., action, na.rm) {
	q.<-slot(s.,i.)

	minage <- s.@range["min"]

	#first check that object actually has ages
	a.<-dimnames(q.)[[quant(q.)]]

	if (any(a.=="all"))
	  return(q.)

	if (any(is.na(a.)) | !all(as.integer(a.)==sort(as.integer(a.))))
	  return(q.)

	pospg <- pg. - as.numeric(dimnames(slot(s., i.))[[1]][1]) + 1

	if (action == "sum"){
	  q.[pospg,,,,]<-apply(q.[r.,],2:6,sum, na.rm=na.rm)
	}
	else{
	  if(action == "wt.mean"){
  	sum.r <- apply(slot(s.,k.)[r.,],2:6,sum, na.rm=na.rm)
		q.[pospg,,,,]<- ifelse(sum.r@.Data == 0, 0, apply(q.[r.,]*slot(s.,k.)[r.,],2:6,sum,na.rm=na.rm)/sum.r)
	  }
	}
	a. <- dimnames(q.)
	q. <- q.[1:pospg,,,,]
	dimnames(q.)[[1]] <- minage:pg.
	dimnames(q.)[2:6] <- a.[2:6]

	return(q.)
}

setMethod('setPlusGroup', signature(x='FLStock', plusgroup='numeric'),
	function(x, plusgroup, na.rm=FALSE)
	{
	# FLQuants by operation
	pg.wt.mean <-c("catch.wt","landings.wt","discards.wt")
	pg.truncate<-c("harvest","m","mat","harvest.spwn","m.spwn")
	pg.sum	   <-c("catch.n", "landings.n", "discards.n")

	# plusgroup calculations
	# xxxx.wt's etc. are condensed into the +gp using the catch if
	# stock.n not available
	# If stock.n available then these are used for f, m, mat & stockwt
	names <- names(getSlots(class(x))[getSlots(class(x))=="FLQuant"])
	maxage <-  dims(x@stock.n)["max"]
	minage <-  dims(x@stock.n)["min"]

	#check plusgroup valid
	if (!missing(plusgroup)){
	  if(plusgroup > maxage){
		 return("Error : new plus group greater than oldest age")
	  }
	  else{
		if(plusgroup < minage)
		  return("Error : new plus group less than youngest age")
	  }
	}
	else
	  return(stock)
	  
	# check fbar range is still valid with new plusgroup
  if (!missing(plusgroup)){
    if(plusgroup <= x@range["maxfbar"]){
      x@range["maxfbar"] <- plusgroup-1
      print("maxfbar has been changed to accomodate new plusgroup")
    }
    if(plusgroup <= x@range["minfbar"]){
      x@range["minfbar"] <- plusgroup-1
      print("minfbar has been changed to accomodate new plusgroup")
    }
  }
  
	#Are stock numbers present?
	stock.n.exist <- sum(x@stock.n, na.rm=TRUE) > 1
	if(stock.n.exist) {
		pg.wt.mean <- c(pg.wt.mean, pg.truncate, "stock.wt")
		pg.wt.by   <- c(pg.sum, rep("stock.n", 7))
		pg.sum	 <- c(pg.sum, "stock.n")
	} else {
		pg.wt.mean <- c(pg.wt.mean, "stock.wt")
		pg.truncate<- c(pg.truncate, "stock.n")
		pg.wt.by   <- c(pg.sum, rep("catch.n",7))
	}

	#Perform +grp calcs
	#there are three options wt by stock.n, catch.n or simply add up the values

  #  pg.range <- as.character(plusgroup:stock@range["max"])
	pg.range <- which((x@range[1] : x@range[2]) == plusgroup):length(
		(x@range[1] : x@range[2]))
	x@range["plusgroup"] <- plusgroup
	x@range["max"] <- plusgroup

	#do the weighted stuff first
	for (i in 1 : length(pg.wt.mean)) {
		j <- pg.wt.mean[i]
		k <- pg.wt.by[i]
		slot(x, j) <- calc.pg(x, j, k, pg.range, plusgroup, "wt.mean", na.rm)
	}

	#sum up stuff next
	for (i in pg.sum) {
	  slot(x, i) <- calc.pg(x, i, k, pg.range, plusgroup, "sum", na.rm)
	}

	#then truncate stuff
	if (!stock.n.exist) {
	  for (i in pg.truncate) {
		 slot(x, i) <- calc.pg(x, i, k, pg.range, plusgroup, "truncate", na.rm)
		}
	}
	return(x)
	}
)# }}}

## ssb		{{{
if (!isGeneric("ssb"))
	setGeneric("ssb", function(object, ...)
		standardGeneric("ssb"))

setMethod("ssb", signature(object="FLStock"),
	function(object, ...) {

	if(units(harvest(object)) == 'f')
	{
		res <- colSums(object@stock.n * exp(-object@harvest * object@harvest.spwn -
      object@m * object@m.spwn) * object@stock.wt * object@mat)
		dim(res) <- c(1, dim(res))
		dmns<-dimnames(object@stock)
		dmns$iter<-dimnames(res)$iter
		return(FLQuant(res, dimnames=dmns))
	} else if(units(harvest(object)) == 'hr')
  {
		res <- colSums(object@stock.n * (1 - object@harvest * object@harvest.spwn) *
      exp(-object@m * object@m.spwn) * object@harvest.spwn * object@mat * object@stock.wt)
		dim(res) <- c(1, dim(res))
		return(FLQuant(res, dimnames=dimnames(object@stock)))
  } else
		stop("Correct units (f or hr) not specified in the harvest slot")
	}
)	# }}}

## fbar		{{{
if (!isGeneric("fbar"))
	setGeneric("fbar", function(object, ...)
		standardGeneric("fbar"))

setMethod("fbar", signature(object="FLStock"),
 function(object, ...) {
  if (is.na(object@range["minfbar"])) object@range["minfbar"]<-object@range["min"]
  if (is.na(object@range["maxfbar"])) object@range["maxfbar"]<-object@range["max"]
  object@range["minfbar"]<-max(object@range["min"],min(object@range["max"],object@range["minfbar"]))
  object@range["maxfbar"]<-max(object@range["min"],min(object@range["max"],object@range["maxfbar"]))

  if(units(harvest(object)) == 'f' || units(harvest(object)) == 'hr')
	    {
		quantMeans(object@harvest[as.character(object@range["minfbar"]:object@range["maxfbar"]),])
#EJ       res <- colMeans(object@harvest[as.character(object@range["minfbar"]:object@range["maxfbar"]),])
# 	dim(res) <- c(1, dim(res))
# 	dnms <- dimnames(object@harvest)
#         dnms[[1]] <- paste(object@range["minfbar"], object@range["maxfbar"], sep=":")
#        return(FLQuant(res, dimnames = dimnames(object@stock)))
#         return(FLQuant(res, dimnames = dnms, units=units(object@harvest)))
		  } else
	stop("Correct units (f or hr) not specified in the harvest slot")
	}
)	# }}}

## sop	{{{
sop <- function(stock, slot="catch") {
	return(quantSums(slot(stock, paste(slot, ".n", sep="")) *
		slot(stock, paste(slot, ".wt", sep=""))) / slot(stock, slot))
}	# }}}

## as.FLStock	{{{
if (!isGeneric("as.FLStock")) {
	setGeneric("as.FLStock", function(object, ...)
		standardGeneric("as.FLStock"))
}	# }}}

## harvest		{{{
if (!isGeneric("harvest"))
	setGeneric("harvest", function(object, catch, ...)
		standardGeneric("harvest"))

setMethod("harvest", signature(object="FLStock", catch="missing"),
	function(object, index="f") {
		if (!missing(index) && units(slot(object, "harvest")) != index)
			stop("The units of harvest in the object do not match the specified index")
		return(slot(object, "harvest"))
	}
)

## harvest<-
if (!isGeneric("harvest<-")) {
	setGeneric("harvest<-", function(object, value){
		value <- standardGeneric("harvest<-")
		value
	})
}
setMethod("harvest<-", signature(object="FLStock", value="character"),
	function(object, value) {
		units(slot(object, "harvest")) <- value
		return(object)
	}
)
setMethod("harvest<-", signature(object="FLStock", value="FLQuant"),
	function(object, value) {
		slot(object, "harvest") <- value
		return(object)
	}
)
setMethod("harvest<-", signature(object="FLStock", value="numeric"),
	function(object, value) {
		slot(object, "harvest")[] <- value
		return(object)
	}
) # }}}

## catch<- FLQuants		{{{
setMethod("catch<-", signature(object="FLStock", value="FLQuants"),
	function(object, value) {
		catch(object) <- value[['catch']]
		catch.n(object) <- value[['catch.n']]
		catch.wt(object) <- value[['catch.wt']]
		return(object)
	}
) # }}}

## trim     {{{
setMethod("trim", signature("FLStock"), function(object, ...){

	args <- list(...)

    c1 <- args[[quant(object@stock.n)]]
	c2 <- args[["year"]]
	c3 <- args[["unit"]]
	c4 <- args[["season"]]
	c5 <- args[["area"]]
	c6 <- args[["iter"]]

    # FLQuants with quant
	names <- names(getSlots(class(object))[getSlots(class(object))=="FLQuant"])

    for (name in names) {
        if(name %in% c('stock', 'catch', 'landings', 'discards'))
            slot(object,name) <- trim(slot(object,name), year=c2, unit=c3, season=c4,
                area=c5, iter=c6)
        else
            slot(object,name) <- trim(slot(object,name), ...)
    }
            
  if (length(c1) > 0) {
    object@range["min"] <- c1[1]
    object@range["max"] <- c1[length(c1)]
    object@range["plusgroup"] <- NA
  }
  if (length(c2)>0 ) {
    object@range["minyear"] <- c2[1]
    object@range["maxyear"] <- c2[length(c2)]
  }

	return(object)

}) # }}}

## ssbpurec SSB per unit recruit {{{
if (!isGeneric("ssbpurec")) {
	setGeneric("ssbpurec", function(object, ...){
		value <- standardGeneric("ssbpurec")
		value
	})
}

setMethod("ssbpurec",signature(object="FLStock"),
	function(object, start = "missing", end = "missing", type = "non-param", recs = "missing", spwns = "missing", plusgroup = TRUE, ...) {

		# checks and chose the range over which we calculate the SSB per unit recruit
		
		if((missing(start) && !missing(end)) | (!missing(start) && missing(end))) 
			stop("Error in ssbpurec: start and end must be supplied together if at all")

		if(missing(start) && missing(end)) 
			x  <- window(object,dims(object@m)[['minyear']],dims(object@m)[['minyear']])

		if(!missing(start) && !missing(end))
			x  <- window(object,start,end)

		if(missing(recs)) 
			recs  <- 1
		if(missing(spwns)) 
			spwns  <- 1 				

		ymin  <- dims(x@m)[['minyear']]
		ymax  <- dims(x@m)[['maxyear']]
		ns  <- dims(x@m)[['season']]
		amin  <- dims(x@m)[['min']]
		amax  <- dims(x@m)[['max']]
		pg  <- dim(x@m)[1]
		
		# if amin = 0 and recs < spwns !!!! cannot happen

		if(amin == 0 && recs < spwns)
			stop("Error: minimum age is zero and the recruitment occurs before spawning - not possible")
		
		if(type == 'non-param') {
			
			m  <- yearMeans(slot(x, "m"))
			mat  <- yearMeans(slot(x, "mat")) 
			wt  <- yearMeans(slot(x, "stock.wt"))
			n  <- FLQuant(m)
			
			# seasonal or non-seasonal options
			
			if(ns == 1) {
				
				# standard calculation : recruitment = 1, natural mort. sets the 
				# age-structure, with or without a plusgroup

				n[1,1,,1,]  <- 1
				for(a in 2:pg) 
					n[a,1,,1,]  <- n[a-1,1,,1,] * exp(-m[a-1,1,,1,])
				if(plusgroup)
					n[pg,1,,1,]  <- n[pg,1,,1,] / (1-exp(-m[pg,1,,1,]))
				
				rho  <- quantSums(n * mat * wt)

				# always set dimnames$year to be the minyear in the stock object

				dimnames(rho)$year  <- dims(object@m)[['minyear']]
				
			} else {

				# to come...
			}
			
		}

		return(rho)
	}
)# }}}

# '['       {{{
setMethod('[', signature(x='FLStock'),
	function(x, i, j, k, l, m, n, ..., drop=FALSE)
  {
		dx <- dim(slot(x, 'stock.n'))

		if (missing(i))
			i <- seq(1, dx[1])
		if (missing(j))
			j <- seq(1, dx[2])
   	if (missing(k))
			k <- seq(1, dx[3])
		if (missing(l))
			l <- seq(1, dx[4])
		if (missing(m))
			m <- seq(1, dx[5])
		if (missing(n))
			n <- seq(1, dx[6])

	  quants <- list("catch.n", "catch.wt", "discards.n", "discards.wt", "landings.n",
		  "landings.wt", "stock.n", "stock.wt", "m", "mat", "harvest", "harvest.spwn",
    	"m.spwn")
    for(q in quants)
      slot(x, q) <- slot(x, q)[i,j,k,l,m,n, drop=FALSE]

	  quants <- list("catch", "landings", "discards", "stock")
      for(q in quants)
        slot(x, q) <- slot(x, q)[1,j,k,l,m,n, drop=FALSE]
        
    # range
    x@range['min'] <- dims(slot(x, 'stock.n'))$min
    x@range['max'] <- dims(slot(x, 'stock.n'))$max
    x@range['minyear'] <- dims(slot(x, 'stock.n'))$minyear
    x@range['maxyear'] <- dims(slot(x, 'stock.n'))$maxyear
    if(i[length(i)] < x@range['plusgroup'])
      x@range['plusgroup'] <- i[length(i)]

    return(x)
    }
)   # }}}

## "[<-"            {{{
setMethod("[<-", signature(x="FLStock", value="FLStock"),
	function(x, i, j, k, l, m, n, ..., value)
	{
		if (missing(i))
			i  <-  dimnames(x@stock.n)[1][[1]]
		if (missing(j))
			j  <-  dimnames(x@stock.n)[2][[1]]
   		if (missing(k))
   			k  <-  dimnames(x@stock.n)[3][[1]]
		if (missing(l))
			l  <-  dimnames(x@stock.n)[4][[1]]
		if (missing(m))
			m  <-  dimnames(x@stock.n)[5][[1]]
		if (missing(n))
			n  <-  dimnames(x@stock.n)[6][[1]]

	    quants <- list("catch.n", "catch.wt", "discards.n", "discards.wt", "landings.n",
		    "landings.wt", "stock.n", "stock.wt", "m", "mat", "harvest", "harvest.spwn",
    		"m.spwn")
        for(q in quants)
            slot(x, q)[i,j,k,l,m,n] <- slot(value, q)
	    
        quants <- list("catch", "landings", "discards", "stock")
        for(q in quants) {
            slot(x, q)[1,j,k,l,m,n] <- slot(value,q)
            }

   		return(x)
	}
)   # }}}

# coerce  {{{
setAs("data.frame", "FLStock",
  function(from)
  {
  lst <- list()
  qnames <- as.character(unique(from$slot))
  for (i in qnames)
    lst[[i]] <- as.FLQuant(from[from$slot==i,-1])
  do.call('FLStock', lst)
  }
) # }}}

# rec(FLStock)  {{{
if (!isGeneric("rec"))
	setGeneric("rec", function(object, ...)
		standardGeneric("rec"))
setMethod('rec', signature(object='FLStock'),
  function(object, rec.age=dims(object)$min)
  {
    if(dims(object)$quant == 'age')
      quantSums(stock.n(object)[rec.age,])
    else
      stop("rec(FLStock) only defined for age-based objects")
  }
) # }}}
