# zzz.R
# FLCore/R/zzz.R

# Copyright 2003-2008 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, Cefas
# $Id: zzz.R,v 1.46 2008/06/27 08:17:05 imosqueira Exp $

.onLoad <- function(lib,pkg) {
	require(methods)
	cat("FLCore 2.0-beta 20080627 \"Bronzy Barnacle\"\n")
  cat("------------------------------------\n")
  cat("PLEASE NOTE: This is a beta version, please\n")
  cat("report any bugs to <flr-team@flr-project.org>.\n")
}

## convert6d  {{{
convert6d <- function(obj) {
 
    if(is(obj, 'FLQuant'))
        return(FLQuant(obj@.Data, dimnames=dimnames(obj@.Data), units=units(obj)))
    if(is(obj, 'FLQuants'))
        return(lapply(obj, convert6d))

    slots<-getSlots(class(obj))
    slots<-names(slots[slots=="FLQuant"])

    for (i in slots)
        slot(obj, i) <- FLQuant(slot(obj, i)@.Data, 
            dimnames=dimnames(slot(obj, i)@.Data), units=units(slot(obj, i)))

    if(is(obj, 'FLFleet'))
      for (i in names(obj@metiers))
        for (j in names(obj@metiers[[i]]@catches))
          obj@metiers[[i]]@catches[[j]] <- qapply(obj@metiers[[i]]@catches[[j]], convert6d)
        
    return(obj)
} # }}}

# ac
ac <- function(x, ...)
  as.character(x, ...)
