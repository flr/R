# FLComp - «Short one line description»
# FLCore/R/FLComp.R

# Copyright 2003-2007 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, Cefas
# $Id: FLComp.R,v 1.46 2008/06/23 15:29:07 imosqueira Exp $

## FLComp   {{{
validFLComp <- function(object)
{
	# FLQuant slots must have either 1 or n iter
  names <- getSlotNamesClass(object, 'FLArray')
	dims <- vector(length=length(names))
	dimnms <- vector("list", length(names)) 
	dimnms <- list()
	for (i in seq(names))
	{
		dims[i] <- dims(slot(object, names[i]))$iter
		dimnms[[i]] <- dimnames(slot(object, names[i]))$iter
	}
	test <- dims != max(dims) & dims != 1
	if (any(test))
		stop(paste("All slots must have iters equal to 1 or 'n': error in",
			paste(names[test], collapse=', ')))
	# and dimname for iter[1] should be '1'
	test <- unlist(dimnms[dims == 1])
	if(!all(test==test))
		stop(paste("Incorrect names on the iter dimension in ",
			paste(names[test], collapse=', ')))
	return(TRUE)
}

setClass("FLComp", representation(name="character", desc="character",
	range="numeric", "VIRTUAL"), prototype(name=character(0), desc=character(0),
  range	= unlist(list(min=0, max=0, plusgroup=NA, minyear=1, maxyear=1))), 
  validity=validFLComp)

invisible(createFLAccesors('FLComp', include=c('name', 'desc')))
# }}}

## summary		{{{
setMethod("summary", signature(object="FLComp"),
	function(object, ...){
		qnames <- getSlotNamesClass(object, 'FLArray')

		cat("An object of class \"", class(object), "\"\n\n", sep="")
		cat("Name:", object@name, "\n")
		cat("Description:", object@desc, "\n")
		cat("Range:\t", paste(sub('plusgroup', 'pgroup', names(object@range)),
      collapse="\t"), "\n")
		cat("", object@range, "\n", sep="\t")
		cat("Quant:", quant(slot(object, qnames[1])), "\n\n")
		
		for (s in qnames) {
			if (sum(!complete.cases(slot(object, s))) == length(slot(object,s)))
				cat(substr(paste(s, "          "), start=1, stop=12), " : EMPTY\n") else
				cat(substr(paste(s, "          "), start=1, stop=12), " : [",
					dim(slot(object,s)),"], units = ", slot(object,s)@units, "\n")
		}
	}
)	# }}}

## window    {{{
setMethod("window", signature(x="FLComp"),
	  function(x, start=dims(x)$minyear, end=dims(x)$maxyear, extend=TRUE, frequency=1) {
    x <- qapply(x, window, start, end, extend, frequency)
		x@range["minyear"] <- start
		x@range["maxyear"] <- end

		return(x)
	}
)	# }}}

## propagate {{{
setMethod("propagate", signature(object="FLComp"),
	  function(object, iter, fill.iter=TRUE)
      qapply(object, propagate, iter=iter, fill.iter=fill.iter)
) # }}}

## iter {{{
setMethod("iter", signature(object="FLComp"),
	  function(object, iter) {
	  	
		# copy the iterate into the new slots
		names. <- names(getSlots(class(object))[getSlots(class(object))=="FLQuant"])
		for(s. in names.)
		{
			if(dims(slot(object, s.))$iter == 1)
				slot(object, s.) <- iter(slot(object, s.), 1)
			else
				slot(object, s.) <- iter(slot(object, s.), iter)
		}
		
		return(object)
	  }
) # }}}

## iter<-  {{{
setMethod("iter<-", signature(object="FLComp", value="FLComp"),
	function(object, iter, value)
	{
		object[,,,,,iter] <- value
		return(object)
	}
)   # }}}

## transform	{{{
if (!isGeneric("transform"))
	setGeneric("transform", function(`_data`, ...) standardGeneric("transform"))

setMethod("transform", signature(`_data`="FLComp"),
	function(`_data`, ...) {
		# An environment is created to avoid issues with
		#  methods sharing names with slots - IM 26.08.07
		env <- new.env()
		for (i in slotNames(`_data`))
			assign(i, slot(`_data`, i), env=env)
    args <- eval(substitute(list(...)), env)

		for (i in 1:length(args)) {
			slot(`_data`, names(args)[i]) <- args[[i]]
		}
		if(validObject(`_data`))
			return(`_data`)
		stop('Attempt to modify object incorrectly: check input dimensions')
	}
)	# }}}

## qapply		{{{
if (!isGeneric("qapply"))
	setGeneric("qapply", function(X, FUN, ...) standardGeneric("qapply"))

setMethod('qapply', signature(X='FLComp', FUN='function'),
	function(X, FUN, ...) {
		FUN <- match.fun(FUN)
		slots <- getSlotNamesClass(X, 'FLQuant')
		if(is.FLQuant(do.call(FUN, list(slot(X,slots[1]), ...)))) {
			res <- X
			for (i in slots)
				slot(res, i) <- do.call(FUN, list(slot(X,i), ...))
		}
		else {
			res  <- vector('list', 0)
			for (i in slots)
				res[[i]] <- do.call(FUN, list(slot(X,i), ...))
		}
		return(res)
	}
)   # }}}

## trim     {{{
setMethod("trim", signature("FLComp"),
	function(object, ...)
	{
	  args <- list(...)
    names <- getSlotNamesClass(object, 'FLArray')

    c1 <- args[[quant(slot(object, names[1]))]]
	  c2 <- args[["year"]]

    # FLQuants with quant
    object <- qapply(object, trim, ...)

    # range
  	if (length(c1) > 0)
    {
    	object@range["min"] <- c1[1]
	    object@range["max"] <- c1[length(c1)]
    	object@range["plusgroup"] <- NA
	  }
  	if (length(c2)>0 )
    {
    	object@range["minyear"] <- as.numeric(c2[1])
	    object@range["maxyear"] <- as.numeric(c2[length(c2)])
  	}
	  return(object)
	}
) # }}}

## units	    {{{
setMethod("units", signature(x="FLComp"), function(x)
	qapply(x, units)
)
#}}}

## units<-      {{{
setMethod("units<-", signature(x="FLComp", value="list"),
    function(x, value) {
        for(i in seq(along=value))
            if(is.character(value[[i]]))
                units(slot(x, names(value[i]))) <- value[[i]]
        return(x)
	}
) # }}}

## '['       {{{
setMethod('[', signature(x='FLComp'),
	function(x, i, j, k, l, m, n, ..., drop=FALSE) {

		qnames <- names(getSlots(class(x))[getSlots(class(x))=="FLQuant"])
		dx <- dim(slot(x, qnames[1]))
		
    if (missing(i))
			i <- seq(1, dx[1])
		if (missing(j))
			j <- seq(1, dx[2])
    if (missing(k))
			k <- seq(1, dx[3])
		if (missing(l))
			l <- seq(1, dx[4])
		if (missing(m))
			m <- seq(1, dx[5])
		if (missing(n))
			n <- seq(1, dx[6])

    for(q in qnames)
      slot(x, q) <- slot(x, q)[i, j, k, l, m, n, drop=FALSE]

    # range
    x@range['min'] <- dims(slot(x, qnames[1]))$min
    x@range['max'] <- dims(slot(x, qnames[1]))$max
    x@range['minyear'] <- dims(slot(x, qnames[1]))$minyear
    x@range['maxyear'] <- dims(slot(x, qnames[1]))$maxyear

    return(x)
    }
)   # }}}

## "[<-"            {{{
setMethod("[<-", signature(x="FLComp"),
	function(x, i, j, k, l, m, n, ..., value="missing") {

		qnames <- names(getSlots(class(x))[getSlots(class(x))=="FLQuant"])
		dx <- dim(slot(x, qnames[1]))

		if (missing(i))
			i <- seq(1, dx[1])
		if (missing(j))
			j <- seq(1, dx[2])
   		if (missing(k))
			k <- seq(1, dx[3])
		if (missing(l))
			l <- seq(1, dx[4])
		if (missing(m))
			m <- seq(1, dx[5])
		if (missing(n))
			n <- seq(1, dx[6])

        for(q in qnames)
            slot(x, q)[i,j,k,l,m,n] <- slot(value, q)
	    
   		return(x)
	}
)   # }}}

## as.data.frame        {{{
setMethod("as.data.frame", signature(x="FLComp", row.names="missing", optional="missing"),
	function(x, row.names, optional)
	{
    qnames <- getSlotNamesClass(x, 'FLArray')
    quant <- quant(slot(x, qnames[1]))
	  df   <- data.frame()
    for(s in qnames)
		{
      sdf <- as.data.frame(slot(x, s))
      sdf[[quant]] <- as.character(sdf[[quant]])
      dfq <- cbind(slot=s, sdf)

		  #if(any(class(dfq[,quant(slot(x, s))])=="factor"))
			#	dfq[,quant(slot(x, s))] <- as.numeric(NA)

			df  <- rbind(df, dfq)
	  }
		# add attributes
		attributes(df)$desc <- x@desc
		attributes(df)$name <- x@name
		attributes(df)$range <- x@range

		return(df)
	}
)   # }}}

## mcf	{{{
setGeneric("mcf", function(object, ...)
	standardGeneric("mcf")
)
setMethod('mcf', signature(object='FLComp'),
	function(object, second) {

	qdims <- unlist(qapply(object, function(x) dim(x)[1]))
	qdims <- names(qdims[qdims==max(qdims)][1])

	dimnames <- list()
	dob <- dimnames(slot(object, qdims))
	dse <- dimnames(slot(second, qdims))

	for(i in names(dob))
		dimnames[[i]] <- unique(c(dob[[i]], dse[[i]]))

	foo <- function(x, dimnames) {
		if(all(dimnames(x)[[1]] == 'all'))
			return(FLQuant(x, dimnames=dimnames[-1]))
		else
			return(FLQuant(x))
	}

	res <- new('FLlst')
	res[[1]] <- qapply(object, foo, dimnames=dimnames)
	res[[2]] <- qapply(second, foo, dimnames=dimnames)

	return(res)
	}
)	# }}}

## dims {{{
setMethod("dims", signature(obj="FLComp"),
    # Returns a list with different parameters
    function(obj, ...)
	{
		qnames <- names(getSlots(class(obj))[getSlots(class(obj))=="FLQuant"])
		return(list(
            quant = quant(slot(obj, qnames[1])),
            min = obj@range[["min"]],
            max = obj@range[["max"]],
            plusgroup=ifelse('plusgroup'%in%names(obj@range),
              obj@range[['plusgroup']],
              as.numeric(NA)),
            year = dim(slot(obj, qnames[1]))[2],
            minyear = obj@range[["minyear"]],
            maxyear = obj@range[["maxyear"]],
            unit = dim(slot(obj, qnames[1]))[3],
            season = dim(slot(obj, qnames[1]))[4],
            area = dim(slot(obj, qnames[1]))[5],
            iter = max(unlist(qapply(obj, function(x) dims(x)$iter)))))
    }
)    # }}}

## lattice plots	{{{
# xyplot
setMethod("xyplot", signature("formula", "FLComp"),
	function(x, data, ...){
	lst <- substitute(list(...))
	lst <- as.list(lst)[-1]
    lst$data <- as.data.frame(data)
	lst$x <- x
	do.call("xyplot", lst)
})

# bwplot
setMethod("bwplot", signature("formula", "FLComp"),

	function(x, data, ...){
	lst <- substitute(list(...))
	lst <- as.list(lst)[-1]
    lst$data <- as.data.frame(data)
    lst$data$year <- as.factor(lst$data$year)
	lst$x <- x
	do.call("bwplot", lst)

})

# dotplot
setMethod("dotplot", signature("formula", "FLComp"), function(x, data, ...){

	lst <- substitute(list(...))
	lst <- as.list(lst)[-1]
    lst$data <- as.data.frame(data)
    lst$data$year <- as.factor(lst$data$year)
	lst$x <- x
	do.call("dotplot", lst)

})

# barchart
setMethod("barchart", signature("formula", "FLComp"), function(x, data, ...){

	lst <- substitute(list(...))
	lst <- as.list(lst)[-1]
    lst$data <- as.data.frame(data)
	lst$x <- x
	do.call("barchart", lst)

})

# stripplot
setMethod("stripplot", signature("formula", "FLComp"), function(x, data, ...){

	lst <- substitute(list(...))
	lst <- as.list(lst)[-1]
    lst$data <- as.data.frame(data)
    lst$data$year <- as.factor(lst$data$year)
	lst$x <- x
	do.call("stripplot", lst)

})

# histogram
setMethod("histogram", signature("formula", "FLComp"), function(x, data, ...){

	lst <- substitute(list(...))
	lst <- as.list(lst)[-1]
    lst$data <- as.data.frame(data)
	lst$x <- x
	do.call("histogram", lst)

})  # }}}

# model.frame {{{
if (!isGeneric("model.frame"))
	setGeneric("model.frame", useAsDefault = model.frame)
setMethod('model.frame', signature(formula='FLComp'),
	function(formula, ...)
  {
    lst <- FLQuants()
    names <- getSlotNamesClass(formula, 'FLQuant')
    for(i in names)
      lst[[i]] <- slot(formula, i)
    names(lst) <- names
    return(model.frame(lst))
  }
)
# }}}

# range {{{
setMethod("range", "FLComp",
  function(x, i='missing', ..., na.rm = FALSE)
  {
    if(missing(i))
      slot(x, 'range')
    else
      slot(x, 'range')[i]
  }
) 

if (!isGeneric("range<-"))
	setGeneric("range<-", function(x, i, value) standardGeneric("range<-"))
setReplaceMethod("range", "FLComp",
  function(x, i, value)
  {
    slot(x, 'range')[i] <- value
    return(x)
  }
) # }}}
