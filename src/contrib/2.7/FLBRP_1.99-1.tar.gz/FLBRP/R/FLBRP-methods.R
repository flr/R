### Methods ####################################################################

# Test if an object is of FLBRP class
is.FLBRP <- function(x)
	return(is(x, "FLBRP"))

setSR<-function(object,sr="missing",sr.model="missing",sr.params="missing")
   {
   if (!missing(sr) && inherits(sr,"FLSR")) {
       sr.model(object) <-model(sr)
       sr.params(object)<-params(sr)
       }
   else {
       if (sr.model =="missing")  sr.model <-"geomean"
       if (sr.params=="missing") sr.params<-1.0

       object@sr.model<-do.call(sr.model, list())$model
       sr.params(object)<-FLPar(array(sr.params, c(1,length(sr.params))))
       }

   return(object)
   }

setSRCode<-function(object)
  {
  res<-switch(SRModelName(sr.model(object)),
             "mean"            = 1,
             "geomean" = 1,
             "bevholt" = 2,
             "ricker" = 3,
             "segreg" = 4,
             "shepherd" = 5,
             "bevholt.d" = 21,
             "bevholt.c.a" = 22,
             "bevholt.c.b" = 23,
             "bevholt.sv" = 24,
             "bevholt.ndc" = 25,
             "bevholt.ar1" = 26,
             "ricker.d" = 31,
             "ricker.c.a" = 32,
             "ricker.c.b" = 33,
             "ricker.sv " = 34,
             "ricker.ndc" = 35,
             "ricker.ar1" = 36,
             default      = 0)

  return(as.integer(res))
  }
  
# Calcs mean over the mean.yrs
mnYr<-function(object,mnYrs=3,arithMn=TRUE,na.rm=TRUE)
  {
  if      (is.numeric(mnYrs) & length(mnYrs)==1) mnYrs<-as.character(dims(object)$maxyear-(mnYrs:1)+1)
  else if (is.numeric(mnYrs) & length(mnYrs) >1) mnYrs<-as.character(mnYrs)
  else if (!is.character(mnYrs)) stop("mnYrs not valid")

  if (arithMn)
    res <-    apply(    object[,mnYrs], c(1,3:6),mean,na.rm=na.rm)
  else
    res <-exp(apply(log(object[,mnYrs]),c(1,3:6),mean,na.rm=na.rm))

  return(res)
  }

# catch et al {{{
# catch
setMethod('catch', signature(object='FLBRP'),
  function(object) {
    res <- landings(object) + discards(object)
    if (units(discards(object)) == units(landings(object)))
		  units(res) <- units(discards(object))
    else
      warning("unit s of discards and landings do not match")
    return(res)
  })

# catch.n
setMethod('catch.n', signature(object='FLBRP'),
  function(object) {
    res <- landings.n(object) + discards.n(object)
    if (units(discards.n(object)) == units(landings.n(object)))
		  units(res) <- units(discards.n(object))
    else
      warning("units of discards.n and landings.n do not match")
    return(res)
  })

# catch.wt
setMethod('catch.wt', signature(object='FLBRP'),
  function(object) {
      idx <- landings.sel(object) == 0 & discards.sel(object) == 0
      landings.sel(object)[idx] <- 1
      discards.sel(object)[idx] <- 1
      res <- (landings.wt(object) * landings.sel(object) +
              discards.wt(object) * discards.sel(object)) /
             (landings.sel(object) + discards.sel(object))

    if (units(discards.wt(object)) == units(landings.wt(object)))
				units(res) <- units(discards.wt(object))
    return(res)
  })

# catch.sel
setMethod('catch.sel', signature(object='FLBRP'),
  function(object) {
    return(landings.sel(object) + discards.sel(object))
  })

# catch.hat
setGeneric('catch.hat', function(object, ...)
		standardGeneric('catch.hat'))
setMethod('catch.hat', signature(object='FLBRP'),
  function(object) {
    return(discards.hat(object)+landings.hat(object))
    })

# catch.obs
setGeneric('catch.obs', function(object, ...)
		standardGeneric('catch.obs'))
setMethod('catch.obs', signature(object='FLBRP'),
  function(object) {
    return(discards.obs(object)+landings.obs(object))
    })

# yield
setGeneric('yield', function(object, ...)
		standardGeneric('yield'))
setMethod('yield', signature(object='FLBRP'),
  function(object) {
    return(landings(object))
    })

# yield.hat
setGeneric('yield.hat', function(object, ...)
		standardGeneric('yield.hat'))
setMethod('yield.hat', signature(object='FLBRP'),
  function(object) { return(landings(object))
    })

# yield.obs
setGeneric('yield.obs', function(object, ...)
		standardGeneric('yield.obs'))
setMethod('yield.obs', signature(object='FLBRP'),
  function(object) {
    return(landings.obs(object))
    })

# discards
setMethod('discards', signature(object='FLBRP'),
  function(object) {
    return(apply(sweep(discards.n(object),c(1,3:6),discards.wt(object),"*"),2,sum))
    })

setGeneric('discards.hat', function(object, ...)
		standardGeneric('discards.hat'))
setMethod('discards.hat', signature(object='FLBRP'),
  function(object) return(discards(object)))

# landings
setMethod('landings', signature(object='FLBRP'),
  function(object) {
    return(apply(sweep(landings.n(object),c(1,3:6),landings.wt(object),"*"),2,sum))
    })

setGeneric('landings.hat', function(object, ...)
		standardGeneric('landings.hat'))
setMethod('landings.hat', signature(object='FLBRP'),
  function(object) return(landings(object)))

# catch
setMethod('catch', signature(object='FLBRP'),
  function(object) {
    return(apply(sweep(catch.n(object),c(1,3:6),catch.wt(object),"*"),2,sum))
    })

# stock
setMethod('stock', signature(object='FLBRP'),
  function(object) {
    return(apply(sweep(stock.n(object),c(1,3:6),stock.wt(object),"*"),2,sum))
    })
setGeneric('stock.hat', function(object, ...)
		standardGeneric('stock.hat'))
setMethod('stock.hat', signature(object='FLBRP'),
  function(object) return(stock(object)))

# ssb
setMethod('ssb', signature(object='FLBRP'),
  function(object) {
     expZ <- exp(-sweep(sweep(harvest(object),c(1,3:6),harvest.spwn(object),"*"),
                        c(1,3:6), m(object)*m.spwn(object),"+"))
                 
     return(apply(sweep(stock.n(object)*expZ,c(1,3:6),stock.wt(object)*mat(object),"*"),2:6,sum))
     })

setGeneric('ssb.hat', function(object, ...)
		standardGeneric('ssb.hat'))
setMethod('ssb.hat', signature(object='FLBRP'),
  function(object) return(ssb(object)))

# fbar
setGeneric('computeFbar', function(object, ...)
		standardGeneric('computeFbar'))
setMethod('computeFbar', signature(object='FLBRP'),
  function(object) {
    return(apply(harvest(object)[ac(object@range["minfbar"]:object@range["maxfbar"])],c(2:6),mean))
    })

# revenue
setMethod('revenue', signature(object='FLBRP'),
  function(object) {
    return(apply(sweep(landings.n(object),c(1,3:6),price(object)*landings.wt(object),"*"),2:6,sum))
    })

# costs
setGeneric('costs', function(object, ...)
		standardGeneric('costs'))
setMethod('costs', signature(object='FLBRP'),
  function(object) {
    res<-sweep(sweep(fbar(object),3:6,vcost(object),"*"),3:6,fcost(object),"+")
    return(res)
    })

# recruit
setGeneric('rec', function(object, ...)
		standardGeneric('rec'))
setMethod('rec', signature(object='FLBRP'),
  function(object) {
    return(stock.n(object)[1,])
    })

# rec.hat
setGeneric('rec.hat', function(object, ...)
   standardGeneric('rec.hat'))
setMethod('rec.hat', signature(object='FLBRP'),
   function(object) {
        return(stock.n(object)[1,])
        })

# r.hat
setGeneric('r.hat', function(object, ...)
   standardGeneric('r.hat'))
setMethod('r.hat', signature(object='FLBRP'),
   function(object) {
        return(stock.n(object)[1,])
        })

# r.obs
setGeneric('r.obs', function(object, ...)
   standardGeneric('r.obs'))
setMethod('r.obs', signature(object='FLBRP'),
   function(object) {
        return(rec.obs(object))
        })
        
# profit
setGeneric('profit', function(object, ...)
		standardGeneric('profit'))
setMethod('profit', signature(object='FLBRP'),
  function(object) {
    return(apply(revenue(object),2,sum)-costs(object))
    })

setGeneric('profit.hat', function(object, ...)
		standardGeneric('profit.hat'))
setMethod('profit.hat', signature(object='FLBRP'),
  function(object) return(profit(object)))

FLBRP<-function(object,sr="missing",sr.params="missing",sr.model="missing",fbar=seq(0,4,.04),mnYrs=3,arithMn=TRUE,na.rm=TRUE,
                				 refpts=c("f0.1","fmax","spr.30","msy","mey"),...)
   {
   if (!is.FLStock(object) && !is(object,"data.frame") && is(object,"matrix") && is(object,"FLBRP"))
      return ("object must be of type FLStock, FLBRP, data.frame or matrix")

   if (is.FLBRP(object))
      {
      res<-object

      slot(res,"fbar")       <-as.FLQuant(fbar)
      dmns                   <-dimnames(fbar)
      dmns$year              <-1
      dmns                   <-dimnames(res@m)
      dmns$year              <-dimnames(res@fbar)$year
      slot(res,"stock.n")    <-FLQuant(NA,dimnames=dmns);
      slot(res,"discards.n") <-FLQuant(NA,dimnames=dmns);
      slot(res,"landings.n") <-FLQuant(NA,dimnames=dmns);
      slot(res,"harvest")    <-FLQuant(NA,dimnames=dmns);

      if (!missing(sr) || (!missing(sr.model)))
        res<-setSR(res,sr=sr,sr.model=sr.model,sr.params=sr.params)

      }
   else if (is.FLStock(object))
      {
      res <-new("FLBRP")
      res@range<-object@range

      if (!any(names((res)@range)%in%"minfbar"))
         res@range["minfbar"]<-NA
      if (!any(names((res)@range)%in%"maxfbar"))
         res@range["maxfbar"]<-NA

      plusgroup<-object@range["plusgroup"]

      object   <-trim(object,age=object@range["min"]:object@range["max"],year=object@range["minyear"]:object@range["maxyear"])
      if (plusgroup==object@range["max"]) res@range["plusgroup"]<-plusgroup

      #fbar range
      if (is.na(res@range["minfbar"])) res@range["minfbar"]<-res@range["min"]
         res@range["minfbar"]<-max(res@range["minfbar"],res@range["min"],na.rm=T)
      if (is.na(res@range["maxfbar"])) res@range["maxfbar"]<-res@range["max"]
         res@range["maxfbar"]<-min(res@range["maxfbar"],res@range["max"],na.rm=T)

      slot(res,"fbar")       <-as.FLQuant(fbar)
      dmns                   <-dimnames(fbar)
      dmns$year              <-1
      slot(res,"vcost")      <-FLQuant(NA,dimnames=dmns)
      slot(res,"fcost")      <-FLQuant(NA,dimnames=dmns)

      for (i in c("m","mat","stock.wt","harvest.spwn","m.spwn","discards.wt","landings.wt"))
         slot(res,i)<-mnYr(slot(object,i),mnYrs,arithMn,na.rm)

      slot(res,"rec.obs")     <-slot(object,"stock.n")[ac(res@range["min"])]
      slot(res,"ssb.obs")     <-ssb(object)
      slot(res,"landings.obs")<-landings(object)
      slot(res,"discards.obs")<-discards(object)
      slot(res,"fbar.obs")    <-fbar(object)
      slot(res,"profit.obs")  <-FLQuant(NA,dimnames=dimnames(slot(res,"fbar.obs")))

      dmns      <- dimnames(object@m)
      dmns$year <- dimnames(slot(res,"fbar"))$year
      slot(res,"stock.n")        <-FLQuant(NA,dimnames=dmns);
      slot(res,"discards.n")     <-FLQuant(NA,dimnames=dmns);
      slot(res,"landings.n")     <-FLQuant(NA,dimnames=dmns);
      slot(res,"harvest")        <-FLQuant(NA,dimnames=dmns);

      dmns$age <- "all"

      mnyrs.harvest<-ac(object@range["maxyear"]+(-mnYrs+1):0)
      
      sel.scaling                <-object@harvest[,mnyrs.harvest]
      sel.scaling                <-sweep(sel.scaling,2:6,apply(sel.scaling[ac(res@range["minfbar"]:res@range["maxfbar"]),],2:6,mean,na.rm=na.rm),"/")
      sel.scaling                <-mnYr(sel.scaling,mnYrs,arithMn,na.rm)
      slot(res,"discards.sel")   <-sel.scaling*mnYr(object@discards.n/(object@discards.n+object@landings.n),mnYrs,arithMn,na.rm)
      slot(res,"landings.sel")   <-sel.scaling*mnYr(object@landings.n/(object@discards.n+object@landings.n),mnYrs,arithMn,na.rm)

      slot(res,"stock.wt")       <-FLQuant(mnYr(slot(object,"stock.wt")   ,mnYrs,arithMn,na.rm),dimnames=dimnames(slot(res,"m")))
      slot(res,"discards.wt")    <-FLQuant(mnYr(slot(object,"discards.wt"),mnYrs,arithMn,na.rm),dimnames=dimnames(slot(res,"m")))
      slot(res,"landings.wt")    <-FLQuant(mnYr(slot(object,"landings.wt"),mnYrs,arithMn,na.rm),dimnames=dimnames(slot(res,"m")))
      slot(res,"bycatch.wt")     <-FLQuant(0,                                                   dimnames=dimnames(slot(res,"m")))
      slot(res,"availability")   <-FLQuant(1.0,                                                 dimnames=dimnames(slot(res,"m")))
      slot(res,"bycatch.harvest")<-FLQuant(0,                                                   dimnames=dimnames(slot(res,"m")))

      slot(res,"price")          <-FLQuant(NA,                                                  dimnames=dimnames(slot(res,"m")))

      units(res@rec.obs)         <-units(object@stock.n)
      units(res@stock.n)         <-units(object@stock.n)
      units(res@discards.n)      <-units(object@discards.n)
      units(res@landings.n)      <-units(object@landings.n)
      units(res@harvest)         <-units(object@harvest)
      units(res@bycatch.harvest) <-units(object@harvest)

      res<-setSR(res,sr=sr,sr.model=sr.model,sr.params=sr.params)
      }

   ## replace any slots passed in (...)
   args <-names(list(...))
   slots<-getSlots("FLBRP")
   for (i in args)
	   if (any(i==names(slots)))
          if (class(list(...)[[i]])==slots[i]) slot(res,i)<-list(...)[[i]]

   if (dimnames(refpts(res))$iter==1 && dims(res)$iter>1)
      {
      dmns     <-dimnames(refpts(res))
      dmns$iter<-1:dims(res)$iter
      refpts(res)<-FLPar(array(c(refpts(res)),dim=unlist(lapply(dmns,length)),dimnames=dmns))
      }
      
   if (!validObject(res)) stop("Not valid")

   return(res)
   }

setGeneric('equilibrium', function(object, ...)
		standardGeneric('equilibrium')
)
setMethod('equilibrium', signature(object='FLBRP'),
  function(object)
    {
    ## check iters in FLquants and sr.params
    #if (dims(object)$iter==1 && dims(object@sr.params)$iter ==1) OK
    #if (dims(object)$iter==1 && dims(object@sr.params)$iter !=1) OK
    if      (dims(object)$iter!=1 && dims(object@sr.params)$iter ==1)
       m(object)<-propagate(m(object),iter=dims(sr.params(object))$iter)
    else if (dims(object)$iter!=1 && dims(object@sr.params)$iter !=1)
       if (dims(object)$iter!= dims(object@sr.params)$iter)
          stop("Iters in sr.params don't match")
          
    srCode<-setSRCode(object)

    res<-.Call("equilibrium", object, srCode, PACKAGE = "FLBRP")

    for (i in c(flq.hat,"landings.sel","discards.sel"))
       slot(object,i)<-slot(res,i)
    
    return(object)
    }
)

setGeneric('computeRefpts', function(object, ...)
		standardGeneric('computeRefpts'))
setMethod('computeRefpts', signature(object='FLBRP'),
 function(object)
    {
    ## check iters in FLquants and sr.params
    #if (dims(object)$iter==1 && dims(object@sr.params)$iter ==1) OK
    #if (dims(object)$iter==1 && dims(object@sr.params)$iter !=1) OK
    if (dims(object)$iter!=1 && dims(object@sr.params)$iter ==1)
       {
       if (dims(m(object))$iter==1) m(object)<-propagate(m(object),iter=dims(sr.params(object))$iter)
       }
    else if (dims(object)$iter!=1 && dims(object@sr.params)$iter !=1)
       if (dims(object)$iter!= dims(object@sr.params)$iter)
          stop("Iters in sr.params don't match")

    srCode<-setSRCode(object)
    
    res<-.Call("computeRefpts", object, refpts(object), srCode, PACKAGE = "FLBRP")

    return(res)
    return(FLPar(res))
    })

setGeneric('brp', function(object, ...)
		standardGeneric('brp'))
setMethod('brp', signature(object='FLBRP'),
brp.<-  function(object)
    {
    ## check iters in FLquants and sr.params
    #if (dims(object)$iter==1 && dims(object@sr.params)$iter ==1) OK
    #if (dims(object)$iter==1 && dims(object@sr.params)$iter !=1) OK
    if (dims(object)$iter==1 && dims(object@sr.params)$iter !=1)
       m(object)<-propagate(m(object),iter=dims(sr.params(object))$iter)
    else if (dims(object)$iter!=1 && dims(object@sr.params)$iter !=1)
       if (dims(object)$iter!= dims(object@sr.params)$iter)
          stop("Iters in sr.params don't match")

    srCode<-setSRCode(object)

    res<-.Call("brp", object, refpts(object), srCode, PACKAGE = "FLBRP")

    return(res)
    })

setGeneric('hcrYield', function(object,fbar,...)
		standardGeneric('hcrYield')
)
setMethod('hcrYield', signature(object='FLBRP'),
  function(object,fbar)
    {
    ## check iters in FLquants and sr.params
    #if (dims(object)$iter==1 && dims(object@sr.params)$iter ==1) OK
    #if (dims(object)$iter==1 && dims(object@sr.params)$iter !=1) OK
    if      (dims(object)$iter!=1 && dims(object@sr.params)$iter ==1)
       m(object)<-propagate(m(object),iter=dims(sr.params(object))$iter)
    else if (dims(object)$iter!=1 && dims(object@sr.params)$iter !=1)
       if (dims(object)$iter!= dims(object@sr.params)$iter)
          stop("Iters in sr.params don't match")

    if (!(inherits(fbar,"FLQuant")) && inherits(fbar,"numeric")) fbar<-as.FLQuant(fbar)
    if (!(inherits(fbar,"FLQuant"))) stop("fbar has to be of type FLQuant")

    srCode<-setSRCode(object)

    res<-.Call("hcrYield", object, srCode, fbar, PACKAGE = "FLBRP")

    #return(res)
    return(apply(sweep(res,c(1,3:6),landings.wt(object),"*"),2,sum))
   }
)

  setMethod('spr0', signature(ssb='FLBRP', rec='missing', fbar='missing'),
     function(ssb)
        {
        res<-equilibrium(FLBRP(ssb,fbar=0))

        return(sum(stock.n(res)[,1]*stock.wt(res)[,1]*mat(res)[,1]*exp(-m(res)*m.spwn(res)[,1])))
        })

setRefpts<-function(harvest="missing",ssb="missing",yield="missing",s.r="missing",y.r="missing")
   {
   refpts<-array(as.numeric(NA),dim=c(5,5),dimnames=list(c("f0.1","fmax","spr.30","msy","mey"),c("harvest","yield","rec","ssb","profit")))

   if (missing(harvest)) a.<- as.null(1) else a.<- cbind(harvest,NA,   NA, NA, NA)
   if (missing(ssb))     b.<- as.null(1) else b.<- cbind(NA,     NA,   NA, ssb,NA)
   if (missing(yield))   c.<- as.null(1) else c.<- cbind(NA,     yield,NA, NA, NA)
   if (missing(s.r))     d.<- as.null(1) else d.<- cbind(NA,     NA,   1,  s.r,NA)
   if (missing(y.r))     e.<- as.null(1) else e.<- cbind(NA,     y.r,  1,  NA, NA)

   refpts<-cbind(t(refpts),a.,b.,c.,d.,e.)

   dmns<-list(iter=1,val=dimnames(refpts)[[1]],refpt=dimnames(refpts)[[2]])
   
   FLPar(array(refpts,dim=lapply(dmns,length),dimnames=dmns))
   }

setMethod("as.FLSR", signature(object="FLBRP"),
    function(object, ...)
	{
        validObject(object)

        rec <- rec.obs(object)
        ssb <- ssb.obs(object)

        # create the FLSR object

        sr <- new("FLSR", rec = rec,ssb = ssb, name = object@name,
            desc = "'rec' and 'ssb' slots obtained from a 'FLBRP' object")

        slot(sr, "fitted")    <- FLQuant(dimnames = dimnames(slot(sr, "rec")))
        slot(sr, "residuals") <- FLQuant(dimnames = dimnames(slot(sr, "rec")))

        units(slot(sr, "fitted")) <- units(slot(sr, "rec"))

        validObject(sr)
        return(sr)
   }
) # }}}
