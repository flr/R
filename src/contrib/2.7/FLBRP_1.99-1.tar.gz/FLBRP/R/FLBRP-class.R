### FLR core version 1.99 ###
### FLBRP
### This file contains code just for the core class FLBRP

##owarn <- options()$warn.FPU
##options(warn.FPU=FALSE)
##dyn.load(paste(dlldir,"FLR.dll",sep=""))
##options(warn.FPU=owarn)
##rm(dlldir, owarn)

## FLQuant slots with age="all"
flq.obs<-c("fbar.obs",
           "landings.obs",
           "discards.obs",
           "rec.obs",
           "ssb.obs",
           "profit.obs")

flq.hat<-c("stock.n",
           "landings.n",
           "discards.n",
           "harvest")

## FLQuant slots with ages
flq<-c("landings.sel",
       "discards.sel",
       "stock.wt",
       "landings.wt",
       "discards.wt",
       "bycatch.wt",
       "bycatch.harvest",
       "m",
       "mat",
       "harvest.spwn",
       "m.spwn",
       "price",
       "availability")

# FLAccesors - �Short one line description�

# Author: Iago Mosqueira, AZTI Tecnalia
# Additions:
# Last Change: 03 Jul 2008 13:43
# $Id: FLBRP-class.R,v 1.1.2.2 2008/07/03 14:01:19 imosqueira Exp $

# Reference:
# Notes:

# TODO M�r 14 Dec 2005 16:01:45 GMT iagoazti: Improve exclusion method

## createFLAccesors		{{{
createFLAccesors <- function(object, exclude=character(1)) {

	slots <- getSlots(class(object))[!names(getSlots(class(object)))%in%exclude]

	defined <- list()

	for (x in names(slots)) {
		# check method is defined already and signatures match
		eval(
		substitute(if(isGeneric(x) && names(formals(x)) != "object") {warning(paste("Accesor
			method for", x, "conflicts with a differently defined generic. Type", x,
			"for more information")); break}, list(x=x))
			)
		# create new generic and accesor method
		eval(
		substitute(if(!isGeneric(x)) setGeneric(x, function(object, ...) standardGeneric(x)),
		list(x=x))
		)
		eval(
		substitute(setMethod(x, signature(y), function(object) return(slot(object, x))), list(x=x,
			y=class(object)))
		)
		# create replacement method
		xr <- paste(x, "<-", sep="")
		eval(
		substitute(if(!isGeneric(x)) setGeneric(x,
			function(object, ..., value) standardGeneric(x)), list(x=xr))
		)
		eval(
		substitute(setMethod(x, signature(object=y, value=v), function(object, value)
			{slot(object, s) <- value; object}), list(x=xr, y=class(object), s=x,
			v=unname(slots[x])))
		)
		defined[[x]] <- c(x, xr, paste('alias{',x,',',class(object),'-method}', sep=''),
			paste('\alias{',xr,',',class(object),',',unname(slots[x]), '-method}', sep=''),
			paste('\alias{',x,'-methods}', sep=''),
			paste('\alias{"',xr, '"-methods}', sep='')
		)
	}
	return(defined)
}	# }}}

### class ######################################################################
validFLBRP <- function(object){
   # All FLQuant objects must have same dimensions
   Dim.obs <- dim(object@fbar.obs)
   Dim     <- dim(object@m)
   Dim.hat <- dim(object@stock.n)

   if (Dim[3]!=1 || Dim.obs[3]!=1 || Dim.hat[3]!=1) warning("Not yet implemented for multiple Units")
   if (Dim[4]!=1 || Dim.obs[4]!=1 || Dim.hat[4]!=1) warning("Not yet implemented for multiple seasons")
   if (Dim[5]!=1 || Dim.obs[5]!=1 || Dim.hat[5]!=1) warning("Not yet implemented for multiple areas")

   for (i in flq)
     if (!all(dim(slot(object,i))==Dim))
      stop(cat(i,"dimensions mismatch"))

   for (i in flq.obs)
     if (!all(dim(slot(object,i))==Dim.obs))
      stop(cat(i,"dimensions mismatch"))

   for (i in flq.hat)
     if (!all(dim(slot(object,i))==Dim.hat))
      stop(cat(i,"dimensions mismatch"))

   # Verify that bounds are correct
   Par <- dims(object@m)
   min <- object@range["min"]
   if (!is.na(min) && (min < Par$min || min > Par$max))
      stop("min quant is outside ages range in FLQuant slots")
   max <- object@range["max"]
   if (!is.na(max) && (max < Par$min || max > Par$max))
      stop("max quant is outside ages range in FLQuant slots")
   if (!is.na(min) && !is.na(max) && max < min)
      stop("max quant is lower than min")
   plusgroup <- object@range["plusgroup"]
   if (!is.na(plusgroup) && (plusgroup < Par$min || plusgroup > Par$max))
      stop("plusgroup is outside [min, max] rangein FLQuant slots")

   #fbar range
   minfbar <- object@range["minfbar"]
   if (is.na(minfbar)) minfbar<-min
   if (minfbar<min) stop("minfbar is < min")

   maxfbar <- object@range["maxfbar"]
   if (is.na(maxfbar)) maxfbar<-max
   if (maxfbar>max) stop("maxfbar is > max")

   # Everything is fine
   return(TRUE)
   }
   
setClass("FLBRP",
   representation(
      "FLComp",
      sr.model       ="formula",
      sr.params      ="FLPar",
      refpts         ="FLPar",
      fbar           ="FLQuant",
      fbar.obs       ="FLQuant",
      landings.obs   ="FLQuant",
      discards.obs   ="FLQuant",
      rec.obs        ="FLQuant",
      ssb.obs        ="FLQuant",
      profit.obs     ="FLQuant",
      stock.n        ="FLQuant",
      landings.n     ="FLQuant",
      discards.n     ="FLQuant",
      landings.sel   ="FLQuant",
      discards.sel   ="FLQuant",
      harvest        ="FLQuant",
      bycatch.harvest="FLQuant",
      stock.wt       ="FLQuant",
      landings.wt    ="FLQuant",
      discards.wt    ="FLQuant",
      bycatch.wt     ="FLQuant",
      m              ="FLQuant",
      mat            ="FLQuant",
      harvest.spwn   ="FLQuant",
      m.spwn         ="FLQuant",
      availability   ="FLQuant",
      price          ="FLQuant",
      vcost       ="FLQuant",
      fcost       ="FLQuant"
      ),

   prototype=prototype(
      name            =character(0),
      desc            =character(0),
      range           =unlist(list(min=as.numeric(NA), max=as.numeric(NA), plusgroup=as.numeric(NA), minyear=as.numeric(NA), maxyear=as.numeric(NA), minfbar=as.numeric(NA), maxfbar=as.numeric(NA))),
      sr.model        =formula(rec~a),
      sr.params       =FLPar(as.numeric(unlist(list(a=as.double(NA))))),
      refpts          =FLPar(array(as.numeric(NA),dim=c(1,5,5),dimnames=list(iter=1,val=c("harvest","yield","rec","ssb","profit"),refpt=c("f0.1","fmax","spr.30","msy","mey")))),
      fbar            =new("FLQuant"),
      landings.sel    =new("FLQuant"),
      fbar.obs        =new("FLQuant"),
      landings.obs    =new("FLQuant"),
      discards.obs    =new("FLQuant"),
      rec.obs         =new("FLQuant"),
      ssb.obs         =new("FLQuant"),
      profit.obs      =new("FLQuant"),
      stock.n         =new("FLQuant"),
      landings.n      =new("FLQuant"),
      discards.n      =new("FLQuant"),
      landings.sel    =new("FLQuant"),
      discards.sel    =new("FLQuant"),
      harvest         =new("FLQuant"),
      bycatch.harvest =new("FLQuant"),
      stock.wt        =new("FLQuant"),
      landings.wt     =new("FLQuant"),
      discards.wt     =new("FLQuant"),
      bycatch.wt      =new("FLQuant"),
      m               =new("FLQuant"),
      mat             =new("FLQuant"),
      harvest.spwn    =new("FLQuant"),
      m.spwn          =new("FLQuant"),
      availability    =new("FLQuant"),
      price           =new("FLQuant"),
      vcost           =new("FLQuant"),
      fcost           =new("FLQuant"),
      validity        =validFLBRP
      ))

setValidity("FLBRP", validFLBRP)
remove(validFLBRP)# We do not need this function any more

invisible(createFLAccesors(new("FLBRP"), exclude=c("range","name","desc","harvest")))
### End class ##################################################################

## harvest		{{{
setMethod("harvest", signature(object="FLBRP", catch="missing"),
	function(object)
		return(slot(object, "harvest"))
)

## harvest<-
setMethod("harvest<-", signature(object="FLBRP", value="FLQuant"),
	function(object, value) {
		slot(object, "harvest") <- value
		return(object)
	}
)
setMethod("harvest<-", signature(object="FLBRP", value="numeric"),
	function(object, value) {
		slot(object, "harvest")[] <- value
		return(object)
	}
) # }}}

