setGeneric('kobePhase',  function(object,...)         standardGeneric('kobePhase'))
setGeneric('kobeShade',  function(object,...)         standardGeneric('kobeShade'))
setGeneric('kobe2sm',    function(object,...)         standardGeneric('kobe2sm'))
  
setGeneric('kobeP',      function(stock,harvest,...)  standardGeneric('kobeP'))
setGeneric('kobeSmry',   function(stock,harvest,...)  standardGeneric('kobeSmry'))
setGeneric('kobeTrks',   function(stock,harvest,...)  standardGeneric('kobeTrks'))
  
  

