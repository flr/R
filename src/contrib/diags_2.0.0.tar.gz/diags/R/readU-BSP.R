utils::globalVariables(c("read.csv"))

iUBSP=function(file) read.csv(file,header=FALSE,col.names     =c("name",   "year",   "index",  "cv"),
                                                    colClasses=c("integer","integer","numeric","numeric"))
         
                  

