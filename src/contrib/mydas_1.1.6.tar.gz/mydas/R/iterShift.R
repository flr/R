iterShift<-function(i,n) c(i:n,1:i)[1:n]
#iterShift(sr_deviances,fn(i,dim(om)[6]))
