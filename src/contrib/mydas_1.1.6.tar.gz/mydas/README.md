# mydas-pkg
R package for evaluation of data-limited methods 
