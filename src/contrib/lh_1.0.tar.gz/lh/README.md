lh
==

R package that uses life history theory to generate fish stocks with particular characteristics
