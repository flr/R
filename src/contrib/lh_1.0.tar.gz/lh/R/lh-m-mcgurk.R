mcgurk=function(wt) #(wt)
   0.00526*wt-0.25
