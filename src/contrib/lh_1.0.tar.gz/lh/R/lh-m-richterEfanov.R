richterEfanov=function(par) #(amat)
   1.52/(par["amat"]^0.72)-0.16 
 