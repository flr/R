petersonWroblewski=function(data) #(wt)
   1.29*data-0.25
