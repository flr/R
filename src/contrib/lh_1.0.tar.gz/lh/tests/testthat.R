library(testthat)
library(lh)

test_check("lh")
