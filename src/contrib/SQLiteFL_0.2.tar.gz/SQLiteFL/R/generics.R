# allGenerics.R - DESC
# allGenerics.R

# Copyright 2003-2012 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, JRC
# $Id: $


# sql {{{
setGeneric('sql', function(object, ...)
  standardGeneric('sql'))
# }}}

# unsql {{{
setGeneric('unsql', function(object, ...)
  standardGeneric('unsql'))
# }}}
