moments<-function(x,n,p=1) (sum(x^p*n)/sum(n))^(1/p)
