# testthat.R - DESC
# /testthat.R

# Copyright 2015 Iago Mosqueira (EC JRC) <iago.mosqueira@jrc.ec.europa.eu>
#
# Distributed under terms of the European Union Public Licence (EUPL) 1.1.
#
# Notes:

library(testthat)
library(FLCore)

test_check("FLCore")
