# FLFishery

Draft of classes and methods for simpler fleet/fishery modelling


## 

## 

## 
