biodyn
======

biomass dynamic model based on ADMB, includes ref pts and HCR