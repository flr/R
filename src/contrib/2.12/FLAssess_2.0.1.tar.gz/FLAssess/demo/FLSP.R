# FLSP - «Short one line description»
# FLSP

# Copyright 2003-2008 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, Cefas
# Last Change: 19 Jun 2008 18:31
# $Id: FLSP.R 134 2009-03-03 14:25:24Z imosqueira $

# Reference:
# Notes:

# TODO Thu 19 Jun 2008 06:24:56 PM CEST IM:

library(FLAssess)

data(nhke)

summary(nhke)


