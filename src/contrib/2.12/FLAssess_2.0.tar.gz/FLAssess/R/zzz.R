# zzz - «Short one line description»

# Author: Iago Mosqueira, AZTI Tecnalia
# Maintainer: FLR Team 
# Additions:
# Last Change: 03 Apr 2008 10:40
# $Id: zzz.R 134 2009-03-03 14:25:24Z imosqueira $

.onLoad <- function(lib,pkg) {
	require(methods)
}
