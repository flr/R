.onLoad <- function(lib,pkg) {
	require(methods)
	cat("FLEDA 2.0 \"The Swordfish hobnobber\"\n")
  cat("------------------------------------\n")
}

