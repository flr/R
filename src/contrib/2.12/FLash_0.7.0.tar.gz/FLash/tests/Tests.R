################################################################################

#### TestHarvest.R              Estimates F from different FLR objects

#### TestFwdFLStock.R:          Basis of automated tests
#### TestFwdFLStockTargets.R    Check Targets
#### TestFwdFLStockSR.R         Check SRs
#### TestFwdFLStockDims.R       Check unit/season/area
#### TestFwdFLStockRVersion.R   Independent R based projection

#### TestFwdFLBiol.R:           Basis of automated tests
