library(testthat)

library(bbm)

# test_check(bbm)
