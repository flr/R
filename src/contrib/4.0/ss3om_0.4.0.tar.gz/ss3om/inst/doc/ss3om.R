## ---- pkgs, echo=FALSE, message=FALSE-----------------------------------------
library(knitr)
opts_chunk$set(echo=FALSE, message=FALSE, warning=FALSE,
  fig.width=5, fig.height=4.5)

## ----loadpkg------------------------------------------------------------------
library(ss3om)

## ----setpwd-------------------------------------------------------------------
dir <- system.file("ext-data/alb", package="ss3om")

## ----readfls------------------------------------------------------------------
simp324 <- readFLSss3(dir, name="alb",
  repfile="Report.sso.bz2", compfile="CompReport.sso.bz2")

## ----ssout--------------------------------------------------------------------
out <- r4ss::SS_output(dir, verbose=FALSE, hidewarn=TRUE, warn=FALSE,
  printstats=FALSE, covar=FALSE, forecast=FALSE,
  repfile="Report.sso.bz2", compfile="CompReport.sso.bz2")
  
format(object.size(out), units='Mb')


