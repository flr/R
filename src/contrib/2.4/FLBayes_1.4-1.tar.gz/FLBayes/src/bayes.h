/*
 * bayes.h = Header file of common functions
 *
 * $Id: bayes.h,v 1.4 2005/02/02 13:46:56 iagoazti Exp $
 */

#define TINY 1.e-300;

double beta_trunc(double,double,double);
double uform(double,double,double);
