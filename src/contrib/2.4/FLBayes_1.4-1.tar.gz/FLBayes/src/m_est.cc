// code for estimating natural mortality (single-valued)
// using formula for mean life-span
// ::
// Richard Hillary <r.hillary@imperial.ac.uk>, Jan 2007
//$Id: m_est.cc,v 1.1 2007/01/15 14:19:18 rmh1977 Exp $

#include <R.h>
#include <Rdefines.h>
#include <Rinternals.h>
#include <Rmath.h>

double lfunc(double,double);
double dlfunc(double,double);

extern "C" SEXP mest(SEXP lbar,SEXP linit) {

	int i,n,itmax=1000,nits=LENGTH(lbar);
	double *lfs,x,xold,tol=1.0e-4;
	
	lfs = REAL(lbar);

	// R return stuff
	
	SEXP Rval = R_NilValue;

	PROTECT(Rval = allocVector(REALSXP, nits)); 

	for(n=0;n<nits;n++) {
		
		// Newton-Raphson loop to solve for rm

		x = REAL(linit)[0]; 
		xold = x;
		for(i=1;i<=itmax;i++) {
		
			xold = x;
			x -= lfunc(xold,lfs[n])/dlfunc(xold,lfs[n]);

			// convergence check
	
			if(fabs(x-xold) <= tol)
				break;
		
			if(i == itmax) 
				Rprintf("Maximum iterations reached\n"); 
		}

		if(x <= 0.)
			Rprintf("Error: estimated value of x is negative!\n");
		else 
			REAL(Rval)[n] = x; 
	}

	UNPROTECT(1);

	return (Rval);
}

// functions

double lfunc(double x,double lfs) {
	
	int t;
	double ans;

	ans = 0.;
	for(t=1;t<=1000;t++)
		ans += exp(-t * x);
	ans -= lfs;

	return ans;
}

double dlfunc(double x,double lfs) {
	
	int t;
	double ans;

	ans = 0.;
	for(t=1;t<=1000;t++)
		ans += -t * exp(-t * x);
	
	return ans;
}
