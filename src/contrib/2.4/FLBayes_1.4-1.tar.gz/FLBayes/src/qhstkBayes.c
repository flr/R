/* quadhstk.c = Bayesian quadratic hockey-stick stock recruit qhfunction
 * using Metropolis-within-Gibbs sampling: parameters are the 
 * gradient at the origin (alpha), the degree of uncertainty in the density-dependent 
 * turning point (rho), the point at which the density-dependence shift occurs (beta),
 * and the recruitment variance (sigmar)
 *
 * Author: Richard Hillary (Imperial College) 
 * Last change: 4/1/05
 * $Id: qhstkBayes.c,v 1.4 2006/07/04 12:31:04 rmh1977 Exp $
 *
 */

#include <R.h>
#include <Rdefines.h>
#include <Rmath.h>
#include "bayes.h"

/* function prototypes */

double qhfunc(double *,double *,double *,double,double,double,double,double);
double qhsr(double,double,double,double);
double qhf0(double,double,double);

/* Function SEXP foo(SEXP x, y, priors, nIter, chains) {{{ */

SEXP qhstkBayes(SEXP Rrec, SEXP Rssb, SEXP Rpriors, SEXP Rinit, SEXP RnIter, SEXP Rburnin, SEXP Rthin, SEXP Rchains, SEXP Rmvar)
{
  
  /* initialise external variables */

  SEXP Rval = R_NilValue;
  SEXP Rlist = R_NilValue;
  GetRNGstate();
  
  int i=0,c,t;
  int ni = INTEGER(RnIter)[0]*INTEGER(Rthin)[0];
  int nj = 4;
  int T = LENGTH(Rrec);
  int nc = INTEGER(Rchains)[0]; 
  int nt = INTEGER(Rthin)[0];
  int nb = INTEGER(Rburnin)[0];
  int ntemp,nk;
  
  double *R,*S,*priors,lalpha,alpha,beta,rho,sigmar;
  double sbarnew,delnew,sbarvar,delvar;
  double dummy1,dummy2,res,pival1,pival2,uvar,accpt,acp;

  PROTECT(Rlist = NEW_LIST(nc));

  /* data */

  R = REAL(Rrec);
  S = REAL(Rssb);
  priors = REAL(Rpriors); 

  /* random walk variances */

  sbarvar = REAL(Rmvar)[0];
  delvar = REAL(Rmvar)[1];
 
  /* chains */
  
  for (c=0;c<nc;c++) {

	  ntemp = (int)(ni/nt);
	  nk=0;
	  PROTECT(Rval = allocMatrix(REALSXP, ntemp, nj)); 

	  /* initialise the chain */

	  beta = REAL(Rinit)[1] + rnorm(0,0.01);
	  alpha = REAL(Rinit)[0] + rnorm(0,0.01);
	  lalpha = log(alpha);
	  rho = REAL(Rinit)[2] + rnorm(0,0.01);
	  sigmar = REAL(Rinit)[3] + rnorm(0,0.01);

	  /* iterate the markov chains */

	  for (acp=0.,i=0; i<ni+nb; i++) { 

		  /* update log alpha from its conditional posterior */

		  for(res=0.,t=0;t<T;t++) res += log(R[t])-qhf0(S[t],beta,rho);
		  dummy1 = 1./(priors[0]/priors[1] + (double)T/sigmar);
		  dummy2 = (priors[0]/priors[1] + res/sigmar)*dummy1; 
		  lalpha = rnorm(dummy2,sqrt(dummy1));
		  alpha = exp(lalpha); 

		  /* update rho and beta using Metropolis-Hastings */
		  
		  for(;;) {
			  sbarnew = beta + rnorm(0.0,sqrt(sbarvar));
			  delnew = rho + rnorm(0.0,sqrt(delvar));
			  if(sbarnew > 0. && delnew >= 0. && delnew <= 1.) break;
		  }
           		  
		  pival1 = qhfunc(R,S,priors,beta,alpha,rho,sigmar,T);
		  pival2 = qhfunc(R,S,priors,sbarnew,alpha,delnew,sigmar,T);
		  accpt = pival2-pival1 < 0. ? pival2-pival1 : 0.;
    
		  /* generate a random U[0,1] variate */
    
		  uvar=log(runif(0.0,1.0));
    
		  if(accpt > uvar) {
			  if(i >= nb)
				  acp++;
			  beta = sbarnew;
			  rho = delnew;
		  }

		  /* update sigmar from its conditional posterior */

		  for(res=0.,t=0;t<T;t++) res += 0.5*(log(R[t])-qhsr(S[t],beta,alpha,rho))*(log(R[t])-qhsr(S[t],beta,alpha,rho));
		  dummy1 = rgamma(priors[6]+(double)T/2.0,priors[7]/(1.0+priors[7]*res));
		  sigmar = 1./dummy1; 
	
		  /* update the markov chain */
	
		  if(i >= nb && i % nt == 0) {
			  REAL(Rval)[nk + 0*ntemp] = alpha;
			  REAL(Rval)[nk + 1*ntemp] = rho;
			  REAL(Rval)[nk + 2*ntemp] = beta;
			  REAL(Rval)[nk + 3*ntemp] = sigmar;
			  nk++;
		  }
	  }

	acp/=(double)(ni-1);
	Rprintf("Acceptance probability for (beta,h) = %8.6f\n",acp);

	SET_ELEMENT(Rlist, c, Rval);
	
	UNPROTECT(1);
	   
  }
	
  PutRNGstate(); 
  
  UNPROTECT(1);

  return (Rlist);
  
}

/* function prototypes */

double qhfunc(double R[],double S[],double priors[],double beta,double alpha,double rho,double sigmar,double T)
{
  int t;
  double retval;

  /* likelihood */

  retval = -0.5*(double)T*log(2.*M_PI*sigmar);
  for(t=0;t<T;t++) retval -= 1./(2.*sigmar)*(log(R[t])-qhsr(S[t],beta,alpha,rho))*(log(R[t])-qhsr(S[t],beta,alpha,rho));

  /* priors for beta and rho */

  retval += log(dbeta(rho,priors[2],priors[3],FALSE));
  retval += log(dlnorm(beta,priors[4],sqrt(priors[5]),FALSE));
  
  return retval;
}

double qhsr(double S,double beta,double alpha,double rho)
{
  double retval;

  /* this default only in place to ensure the source code compiles... */

  retval = 1.;
  
  if(S <= beta*(1.-rho)) retval = log(alpha*S);
  if(S > beta*(1.-rho) && S < beta*(1.+rho)) retval = log(alpha*(S-(S-beta*(1.-rho))*(S-beta*(1.-rho))/(4.*rho*beta)));
  if(S >= beta*(1.+rho)) retval = log(alpha*beta);

  return retval;
}

double qhf0(double S,double beta,double rho)
{
  double retval;

  /* this default only in place to ensure the source code compiles... */

  retval = 1.; 
	
  if(S <= beta*(1.-rho)) retval = log(S);
  if(S > beta*(1.-rho) && S < beta*(1.+rho)) retval = log(S-(S-beta*(1.-rho))*(S-beta*(1.-rho))/(4.*rho*beta));
  if(S >= beta*(1.+rho)) retval = log(beta);

  return retval;
}
