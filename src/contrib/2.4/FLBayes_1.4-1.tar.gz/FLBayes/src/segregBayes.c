/* segregBayes.c = Bayesian hockey-stick stock recruit qhfunction
 * using Metropolis-within-Gibbs sampling: parameters are the 
 * gradient at the origin (alpha), the point at which the density-dependence 
 * shift occurs (beta), and the recruitment variance (sigmar)
 *
 * Author: Richard Hillary (Imperial College) 
 * Last change: 4/1/05
 * $Id: segregBayes.c,v 1.2 2006/07/04 12:31:04 rmh1977 Exp $
 *
 */

#include <R.h>
#include <Rdefines.h>
#include <Rmath.h>
#include "bayes.h"

/* function prototypes */

double sgfunc(double *,double *,double *,double,double,double,double);
double sgsr(double,double,double);
double sgf0(double,double);

/* Function SEXP foo(SEXP x, y, priors, nIter, chains) {{{ */

SEXP segregBayes(SEXP Rrec, SEXP Rssb, SEXP Rpriors, SEXP Rinit, SEXP RnIter, SEXP Rburnin, SEXP Rthin, SEXP Rchains, SEXP Rmvar)
{
  
  /* initialise external variables */

  SEXP Rval = R_NilValue;
  SEXP Rlist = R_NilValue;
  GetRNGstate();
  
  int i=0,c,t;
  int ni = INTEGER(RnIter)[0]*INTEGER(Rthin)[0];
  int nj = 3;
  int T = LENGTH(Rrec);
  int nc = INTEGER(Rchains)[0]; 
  int nt = INTEGER(Rthin)[0];
  int nb = INTEGER(Rburnin)[0];
  int ntemp,nk;
  
  double *R,*S,*priors,lalpha,alpha,beta,sigmar;
  double betanew,betavar;
  double dummy1,dummy2,res,pival1,pival2,uvar,accpt,acp;

  PROTECT(Rlist = NEW_LIST(nc));

  /* data */

  R = REAL(Rrec);
  S = REAL(Rssb);
  priors = REAL(Rpriors); 

  /* random walk variances */

  betavar = REAL(Rmvar)[0];
 
  /* chains */
  
  for (c=0;c<nc;c++) {

	  ntemp = (int)(ni/nt);
	  nk=0;
	  PROTECT(Rval = allocMatrix(REALSXP, ntemp, nj)); 

	  /* initialise the chain */

	  for(;;) {
		  beta = REAL(Rinit)[1] + rnorm(0,0.01);
	  	  alpha = REAL(Rinit)[0] + rnorm(0,0.01);
	  	  lalpha = log(alpha);
	 	  sigmar = REAL(Rinit)[2] + rnorm(0,0.01);
		  if(beta > 0. && sigmar > 0.) break;
	  }

	  /* iterate the markov chains */

	  for (acp=0.,i=0; i<ni+nb; i++) { 

		  /* update log alpha from its conditional posterior */

		  for(res=0.,t=0;t<T;t++) res += log(R[t])-sgf0(S[t],beta);
		  dummy1 = 1./(priors[0]/priors[1] + (double)T/sigmar);
		  dummy2 = (priors[0]/priors[1] + res/sigmar)*dummy1; 
		  lalpha = rnorm(dummy2,sqrt(dummy1));
		  alpha = exp(lalpha); 

		  /* update rho and beta using Metropolis-Hastings */
		  
		  for(;;) {
			  betanew = beta + rnorm(0.0,sqrt(betavar));
			  if(betanew > 0.) break;
		  }
           		  
		  pival1 = sgfunc(R,S,priors,beta,alpha,sigmar,T);
		  pival2 = sgfunc(R,S,priors,betanew,alpha,sigmar,T);
		  accpt = pival2-pival1 < 0. ? pival2-pival1 : 0.;
    
		  /* generate a random U[0,1] variate */
    
		  uvar=log(runif(0.0,1.0));
    
		  if(accpt > uvar) {
			  if(i >= nb)
				  acp++;
			  beta = betanew;
		  }

		  /* update sigmar from its conditional posterior */

		  for(res=0.,t=0;t<T;t++) res += 0.5*(log(R[t])-sgsr(S[t],beta,alpha))*(log(R[t])-sgsr(S[t],beta,alpha));
		  dummy1 = rgamma(priors[4]+(double)T/2.0,priors[5]/(1.0+priors[5]*res));
		  sigmar = 1./dummy1; 
	
		  /* update the markov chain */
	
		  if(i >= nb && i % nt == 0) {
			  REAL(Rval)[nk + 0*ntemp] = alpha;
			  REAL(Rval)[nk + 1*ntemp] = beta;
			  REAL(Rval)[nk + 2*ntemp] = sigmar;
			  nk++;
		  }
	  }

	acp/=(double)(ni);
	Rprintf("Acceptance probability for (beta) = %8.6f\n",acp);

	SET_ELEMENT(Rlist, c, Rval);
	
	UNPROTECT(1);
	   
  }
	
  PutRNGstate(); 
  
  UNPROTECT(1);

  return (Rlist);
  
}

/* function prototypes */

double sgfunc(double R[],double S[],double priors[],double beta,double alpha,double sigmar,double T)
{
  int t;
  double retval;

  /* likelihood */

  retval = -0.5*(double)T*log(2.*M_PI*sigmar);
  for(t=0;t<T;t++) retval -= 1./(2.*sigmar)*(log(R[t])-sgsr(S[t],beta,alpha))*(log(R[t])-sgsr(S[t],beta,alpha));

  /* prior for beta */

  retval += dlnorm(beta,priors[2],sqrt(priors[3]),TRUE);
  
  return retval;
}

double sgsr(double S,double beta,double alpha)
{
  double retval;

  /* this default only in place to ensure the source code compiles... */

  retval = 1.;
  
  if(S < beta) retval = log(alpha*S);
  if(S >= beta) retval = log(alpha*beta);

  return retval;
}

double sgf0(double S,double beta)
{
  double retval;

  /* this default only in place to ensure the source code compiles... */

  retval = 1.; 
	
  if(S < beta) retval = log(S);
  if(S >= beta) retval = log(beta);

  return retval;
}
