# Front end to the rmest C++ code, used for (Monte Carlo) estimation
# of the intrinsic growth rate parameter, rm, from the Pella-Tomlinson model
# Richard Hillary <r.hillary@imperial.ac.uk>
# ::
# $Id: estrm.R,v 1.1 2006/07/04 10:14:58 rmh1977 Exp $

estrm <- function(M,amat,alpha,rho,rinit) {

	# coerce everything to vectors

	M <- as.vector(M)
	amat <- as.vector(amat)
	alpha <- as.vector(alpha)
	rho <- as.vector(rho)

	# check that the dimensionality is all the same

	dm <- length(M)
	tmp <- list(m=M,am=amat,alpha=alpha,rho=rho)
	if(!all(lapply(tmp,length) == dm))
		stop("Error in estrm: vector inputs not all of same length")
	
	# check for negative values...

	tmp <- cbind(M,amat,alpha,rho)
	if(!all(apply(tmp,1:2,function(x){ifelse(x<0,FALSE,TRUE)})))
		stop("Error in estrm: some of the inputs are negative")

	if(rinit <= 0)
		stop("Error in estrm: initial estimate is not positive")

	# call the C++ solver code

	rm <- .Call("rmest",M,amat,alpha,rho,as.double(rinit))
	
	return (rm)
}
