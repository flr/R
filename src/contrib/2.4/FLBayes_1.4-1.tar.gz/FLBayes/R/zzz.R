.onLoad <- function(lib,pkg) {
    require(methods)
    cat("FLBayes 1.4-1\n")
}
