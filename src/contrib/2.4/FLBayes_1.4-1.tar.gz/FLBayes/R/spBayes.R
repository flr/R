# spBayes = Bayesian surplus production Schaefer model.

# Author: Richard Hillary, Imperial College
#         Iago Mosqueira, AZTI Fundazioa 
# Last Change: 06 jul 2006 14:00
# Reference:
# $Id: spBayes.R,v 1.18 2007/01/24 16:00:20 imosqueira Exp $

# Notes:

spBayes <- function(catch, index, eps, mpar, delta, mclist, plot=TRUE, conv=TRUE)
{
	# check the inputs
	
	if(!is.vector(catch)) 	
		catch <- as.vector(catch)
	if(!is.vector(index)) 	
		index <- as.vector(index)
	
	if(!is.list(mclist))
		stop("Control list not a list")
	
	# priors and MCMC information

	if(!is.na(mclist$pinit[['Q']]))
		Qinit <- mclist$pinit[['Q']]
	else stop("Initial Q missing")

	if(!is.na(mclist$pinit[['r']]))
		rinit <- mclist$pinit[['r']]
	else stop("Initial r missing") 

	if(!is.na(mclist$pinit[['K']]))
		Kinit <- mclist$pinit[['K']]
	else stop("Initial K missing") 
	 
	if(!is.na(mclist$pinit[['sigmas']]))
		siginit <- mclist$pinit[['sigmas']]
	else stop("Initial sigmas missing") 

	if(!is.na(mclist$logQ.mean))
		logQ.mean <- mclist$logQ.mean
	else stop("Prior for mean log(Q) missing") 

	if(!is.na(mclist$logQ.var))
		logQ.var <- mclist$logQ.var
	else stop("Prior for var log(Q) missing")

 	if(!is.na(mclist$r.mean))
		r.mean <- mclist$r.mean
	else stop("Prior for mean log(r) missing")
	
	if(!is.na(mclist$r.var))
		r.var <- mclist$r.var
	else stop("Prior for var log(r) missing") 

	if(!is.na(mclist$K.mean))
		K.mean <- mclist$K.mean
	else stop("Prior for mean log(K) missing")
	
	if(!is.na(mclist$K.var))
		K.var <- mclist$K.var
	else stop("Prior for var log(K) missing") 

	if(!is.na(mclist$sigma.shape))
		sigma.shape <- mclist$sigma.shape
	else stop("Prior for sigma shape missing")

	if(!is.na(mclist$sigma.rate))
		sigma.rate <- mclist$sigma.rate
	else stop("Prior for sigma rate missing") 
	
	if(!is.na(mclist$nIter)) 
		nIter <- mclist$nIter
	else stop("Number of iterations missing")

	if(!is.na(mclist$burnin)) 
		burnin <- mclist$burnin
	else stop("Number of burn-in iterations missing") 
	
	if(!is.na(mclist$nChains)) 
		nChains <- mclist$nChains
	else stop("Number of chains missing") 

	if(!is.na(mclist$thin))
		thin <- mclist$thin
	else stop("Thinning factor missing")

	if(!is.na(mclist$MCvar[1]) && !is.na(mclist$MCvar[2])) 
		MCvar <- mclist$MCvar
	else stop("MC chain variances missing") 
	
	# call spBayes
	res <- .Call("spBayes", catch, index, c(Qinit,rinit,Kinit,siginit), 
		c(logQ.mean, logQ.var, r.mean, r.var, K.mean, K.var, sigma.shape, sigma.rate), 
		as.real(eps), as.real(mpar), as.real(delta), as.integer(nIter), as.integer(burnin), as.integer(thin),
		as.integer(nChains), MCvar)

	# standard plot for 1st chain only
	if (plot == TRUE) {
		par(mfrow=c(4,2))
		ts.plot(res[[1]][,1],ylab="Q")
		hist(res[[1]][,1],yaxt="n",xlab="Q",main=" ")
		ts.plot(res[[1]][,2],ylab="r")
		hist(res[[1]][,2],yaxt="n",xlab="r",main=" ")
		ts.plot(res[[1]][,3],ylab="K")
		hist(res[[1]][,3],yaxt="n",xlab=expression("K"),main=" ") 
		ts.plot(res[[1]][,4],ylab=expression(sigma[s]^2))
		hist(res[[1]][,4],yaxt="n",xlab=expression(sigma[s]^2),main=" ") 
		for(i in 1:length(res)) {
			dm <- length(catch)+4
			cn <- array('bm',dim=c(dm))
			cn[1:4] <- c('Q','r','K','sigmas')
			colnames(res[[i]]) <- cn
		}
	}

	# convergence diagnostic check on the K parameter if requested

	if(conv==TRUE) {
		conv <- list(length=length(res))
		for(i in 1:length(res))
			conv[[i]] <- res[[i]][,'K']
		convstat <- convdiag(conv)
		cat("Convgergence statistic:\n")
		print(convstat) 
	} 

    	# output object

	return(res) 
}


# mclist.spBayes
mclist.spBayes <- function(...) {

	args <- list(...)

	res <- list(pinit=unlist(list(Q=NA, r=NA, K=NA, sigmas=NA)),
		logQ.mean=NA,
		logQ.var=NA,
		r.mean=NA,
		r.var=NA,
		K.mean=NA,
		K.var=NA,
		sigma.shape=NA,
		sigma.rate=NA,
		nIter=1,
		burnin=1,
		nChains=1,
		thin=1,
		MCvar=c(0.5,0.5))
	if (length(args) > 0)
		for (i in 1:length(args)) {
			if (names(args)[i] == "pinit")
				res[[names(args)[i]]][]  <- args[[i]]
			else
				res[[names(args)[i]]]  <- args[[i]]
		}

	return(res)
}
