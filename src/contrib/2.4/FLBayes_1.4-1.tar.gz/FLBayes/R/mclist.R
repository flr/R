# mclist - �Short one line description�

# Author: Iago Mosqueira, AZTI Fundazioa
# Additions:
# Last Change: 13 Mai 2005 14:49
# $Id: mclist.R,v 1.3 2006/05/08 10:07:33 iagoazti Exp $

# Reference:
# Notes:

mclist <- function(fun=NULL, ...) {

	if(is.null(fun))
		stop("A Bayesian model function must be specified")

	args <- list(...)

	# deparse if function
	if (is.function(fun))
		fun <- deparse(substitute(fun))
	
	# generate function call
	call <- c(list(as.symbol(paste("mclist",fun,sep="."))))
    res <- try(eval(as.call(call)), silent=TRUE)

	# check error
    if(inherits(res, "try-error")) {
        stop(res)
    }

	# load specified priors
	if(length(args) > 0)
		for (i in 1:length(args))
			res[[names(args[i])]] <- args[[i]]

	return(res)
}
