# segregBayes = 

# Author: Richard Hillary, Imperial College
#         Iago Mosqueira, AZTI Fundazioa 
# Last Change: 01 feb 2007 11:51
# $Id: segregBayes.R,v 1.2.2.1 2007/02/01 11:26:54 ejardim Exp $

# Notes:

segregBayes <- function(rec,ssb,mclist,plot=TRUE,conv=TRUE) {

	# coerce rec and ssb into vectors

	if(!is.vector(rec)) rec <- as.vector(rec)
	if(!is.vector(ssb)) ssb <- as.vector(ssb)
	
	# check the required elements in mclist for bevholtBayes
	# are not NA

	if(!is.list(mclist))
		stop("Control list not a list")

	if(!is.na(mclist$pinit[['alpha']]))
		alphinit <- mclist$pinit[['alpha']]
	else stop("Initial alpha estimate missing")

	if(!is.na(mclist$pinit[['beta']]))
		betinit <- mclist$pinit[['beta']]
	else stop("Initial beta estimate missing") 

	if(!is.na(mclist$pinit[['sigma']]))
		siginit <- mclist$pinit[['sigma']]
	else stop("Initial sigma estimate missing")
	
	if(!is.na(mclist$logalp.mean))
		logalp.mean <- mclist$logalp.mean	
	else stop("Prior logalp.mean missing")
		
	if(!is.na(mclist$logalp.var))
		logalp.var <- mclist$logalp.var
	else stop("Prior logalp.var missing") 

	if(!is.na(mclist$beta.mean))
		beta.mean <- mclist$beta.mean
	else stop("Prior beta.mean missing")

	if(!is.na(mclist$beta.var))
		beta.var <- mclist$beta.var
	else stop("Prior beta.var missing")

	if(!is.na(mclist$sigma.shape)) 
		sigma.shape <- mclist$sigma.shape
	else stop("Prior sigma.shape missing") 

	if(!is.na(mclist$sigma.rate)) 
		sigma.rate <- mclist$sigma.rate
	else stop("Prior sigma.rate missing") 

	if(!is.na(mclist$nIter)) 
		nIter <- mclist$nIter
	else stop("Number of iterations missing")

 	if(!is.na(mclist$nChains)) 
		nChains <- mclist$nChains
	else stop("Number of Chains missing") 
	
	if(!is.na(mclist$MCvar[1]))
		MCvar <- mclist$MCvar
	else stop("Random walk variance(s) missing")
	
	if(!is.na(mclist$burnin))
		burnin <- mclist$burnin
	else stop("Burn-in length missing") 

	if(!is.na(mclist$thin))
		thin <- mclist$thin
	else stop("Thinning factor missing") 
	
	# call rickerBayes
	res <- .Call("segregBayes", rec, ssb, c(logalp.mean,logalp.var,beta.mean,beta.var,sigma.shape,sigma.rate),
		c(alphinit,betinit,siginit), as.integer(nIter), as.integer(burnin), as.integer(thin), 
		as.integer(nChains), MCvar)

	names(res) <- 'params'

	# standard plot for first chain

	if(plot == TRUE) {
		par(mfrow=c(3,2))
		ts.plot(res[[1]][,1],ylab=expression(alpha))
		hist(res[[1]][,1],yaxt="n",xlab=expression(alpha),main=" ")
		ts.plot(res[[1]][,2],ylab=expression(beta))
		hist(res[[1]][,2],yaxt="n",xlab=expression(beta),main=" ")
		ts.plot(res[[1]][,3],ylab=expression(sigma[r]^2))
		hist(res[[1]][,3],yaxt="n",xlab=expression(sigma[r]^2),main=" ") 
		for(i in 1:length(res))
			colnames(res[[i]]) <- c("alpha", "beta", "sigma") 
	}
	
	# convergence diagnostic check on the beta parameter if requested

	if(conv==TRUE) {
		conv <- list(length=length(res))
		for(i in 1:length(res))
			conv[[i]] <- res[[i]][,'beta']
		convstat <- convdiag(conv)
		cat("Convgergence statistic:\n")
		print(convstat) 
	} 

	return(res) 
}
