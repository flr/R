.onLoad <- function(lib,pkg) {
	require(methods)
	cat("FLEDA 1.4-2 - \"The Jackal's Associate\" \n")
}
