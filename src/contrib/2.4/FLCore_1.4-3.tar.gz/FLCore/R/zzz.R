.onLoad <- function(lib,pkg) {
	require(methods)
	cat("FLCore 1.4-3 - \"Golden Jackal\" \n")
}
