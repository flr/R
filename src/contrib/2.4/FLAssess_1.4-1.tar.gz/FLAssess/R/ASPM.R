# ASPM - Age Structured Production Method

# Author: Laurie Kell, CEFAS
# Maintainer: Laurie Kell, Iago Mosqueira
# Additions:
# Last Change: 27 oct 2006 14:51
# $Id: ASPM.R,v 1.1 2006/10/29 23:10:53 iagoazti Exp $

# Reference:
# Notes:

# ASPM  {{{
ASPM <- function(obj,catch,catch.sel,discard.sel,sr,ssb.ratio,rec.dev,virgin.dev) 
    {
    ##Internal functions
    find.initial.ssb<-function(fmult,obj,target,catch.sel,sr)
        (ssb-initial.ssb(fmult=fmult,obj=obj,catch.sel=catch.sel,sr=sr))^2
        
    find.yield<-function(fmult,obj,target,catch.sel,sr)
        (target-yield(fmult=fmult,obj=obj,catch.sel=catch.sel,sr=sr))^2   

    ## Initial population
    # find fmult for initial ssb
    v.ssb    <-initial.ssb(stock,catch.sel,sr,0.0)
    fmult    <-0.01
    ssb.val  <-initial.ssb(stock,catch.sel,sr,fmult)/v.ssb
    while (ssb.ratio > ssb.val)   
       {
       fmult   <-fmult*2.0
       ssb.val <-initial.ssb(stock,catch.sel,sr,fmult)/v.ssb
       }
    fmult<-optimise(f=find.initial.ssb,interval=c(ifelse(fmult==0.02,0.0,fmult/2.0),fmult),
                    catch.sel=catch.sel,sr=sr,maximum=FALSE)
    
    obj<-initial.popln(fmult,obj,catch.sel,sr.model,sr.param)

    for (iyr in dimnames(obj@stock.n)$year) {
        fmult<-optimise(f=find.yield,target=yield[iyr],catch.sel,sr.model,sr.param,maximum=FALSE)
        obj<-project(obj,catch.sel,fmult,iyr,sr.model,sr.param)
        } 
    }

initial.popln<-function(fmult,obj,catch.sel,sr.model,sr.param){
      if (!inherits(obj, "FLStock"))
         stop("obj must be an 'FLStock' object!")
      if (!validObject(obj))
         stop("obj is not a valid object!")

     m            <-obj@m[           ,1,drop=TRUE]
     m.spwn       <-obj@m.spwn[      ,1,drop=TRUE]
     harvest.spwn <-obj@harvest.spwn[,1,drop=TRUE]
     sel          <-catch.sel[          ,1,drop=TRUE]
     stock.wt     <-obj@stock.wt[    ,1,drop=TRUE]
     mat          <-obj@mat[         ,1,drop=TRUE]
     pg           <- length(sel)

     expCumZ     <-c(1.0,exp(cumsum(-fmult*sel[-pg]-m[-pg])))
     #expCumZ     <-FLQuant(array(expCumZ, dim = c(length(expCumZ),1,1,1,1), dimnames = dimnames(sel)))

     #Plus Group
     expZ        <- exp(-fmult*sel[pg]-m[pg])
     expCumZ[pg] <- expCumZ[pg]*(-1/(expZ-1))

     ssb<-initial.ssb(fmult,obj,catch.sel,sr.model,sr.param)
      
     obj@stock.n[,1]<-expCumZ*recruits(ssb,sr.model,sr.param)
     obj@harvest[,1]<-sel*fmult
     
     return(obj)
     }

recruits<-function(ssb,sr.model,sr.param){
    res<-switch(tolower(sr.model),
                "mean"      =sr.param["alpha"],
                "bevholt"   =sr.param["alpha"] * ssb / (ssb + sr.param["beta"]),
                "ricker"    =sr.param["alpha"] * ssb * exp(-sr.param["beta"] * ssb),
                "qhstk"     =if(ssb. <= sr.param["beta"]) sr.param["alpha"]*ssb else sr.param["alpha"]*sr.param["beta"],
                "shepherd"  =pow((SPR-param["alpha"])/param["beta"], 1/(Param[3]+1)),
                cat("sr.model must be 'mean', 'bevholt', 'ricker' 'shepherd' or 'qhstk'!\n")
                )
   return(as.numeric(res))
   }

yield <-function(fmult,obj,catch.sel,sr.model,sr.param)
   {
   F      <- fmult*catch.sel[,year,drop=TRUE]
   Z      <- F+obj@m[,year,drop=TRUE]

   return(sum(obj@stock.n[,drop=TRUE]*obj@catch.wt[,drop=TRUE]*F*(1-exp(-Z))/Z,na.rm=TRUE))
   }
   
project <-function(obj,catch.sel,fmult,year,sr.model,sr.param){
     pg    <-length(catch.sel[,year,drop=TRUE])
     expZ  <-exp(-fmult*catch.sel[,year,drop=TRUE]-obj@m[,year,drop=TRUE])
     
     harvest <-fmult*catch.sel[,year,drop=TRUE]
     obj@harvest[,year]<-harvest
     Z       <-fmult*catch.sel[,year,drop=TRUE]+obj@m[,year,drop=TRUE]
     catch.n <-obj@stock.n[,year,drop=TRUE]*harvest*(1.0-exp(Z))/(Z)

     yearPlus1<-as.character(as.integer(year)+1)
     if (yearPlus1<=dims(obj@stock.n)$maxyear)
        {
        obj@stock.n[-1,yearPlus1]<-obj@stock.n[-pg,year,drop=TRUE]*expZ[-pg]
        
        year.rec<-as.integer(year)-dims(obj@stock.n)$min
        if (year.rec < dims(obj@stock.n)$minyear)
           ssb<-initial.ssb(fmult,obj,catch.sel,sr.model,sr.param)
        else
           ssb<-ssb(obj)[,as.character(year.rec)]
     
        obj@stock.n[1, yearPlus1]<-recruits(ssb,sr.model,sr.param)
        obj@stock.n[pg,yearPlus1]<-obj@stock.n[pg,yearPlus1,drop=TRUE]
                                  +obj@stock.n[pg,year,drop=TRUE]*exp(-fmult*catch.sel[pg,year,drop=TRUE]
                                  -obj@m[pg,year,drop=TRUE])             
        }        
     return(obj)
     }
     
initial.ssb<-function(fmult,obj,catch.sel,sr.model,sr.param){
   if (!inherits(obj, "FLStock")) stop("obj not of type FLStock")

   m            <-obj@m[           ,1,drop=TRUE]
   m.spwn       <-obj@m.spwn[      ,1,drop=TRUE]
   harvest.spwn <-obj@harvest.spwn[,1,drop=TRUE]
   catch.sel    <-catch.sel[       ,1,drop=TRUE]
   stock.wt     <-obj@stock.wt[    ,1,drop=TRUE]
   mat          <-obj@mat[         ,1,drop=TRUE]

   ##internal function
   spr  <-function(fmult,m,catch.sel,stock.wt,mat,m.spwn,harvest.spwn){
       
       pg <- length(catch.sel)
    
       expCumZ     <-c(1.0,exp(cumsum(-fmult*catch.sel[-pg]-m[-pg])))
       expCumZ     <-FLQuant(array(expCumZ, dim = c(length(expCumZ),1,1,1,1), dimnames = dimnames(catch.sel)))
    
       #Plus Group
       expZ        <- exp(-fmult*catch.sel[pg]-m[pg])
       expCumZ[pg] <- expCumZ[pg]*(-1/(expZ-1))
    
       return(as.numeric(sum(stock.wt*mat*expCumZ*exp(-fmult*catch.sel*harvest.spwn-m*m.spwn))))
       }   

   SPR<-spr(fmult,m,catch.sel,stock.wt,mat,m.spwn,harvest.spwn)

   res<-switch(tolower(sr.model),
			            "mean"      =SPR*sr.param[1],
			            "bevholt"   =SPR*sr.param["alpha"]-sr.param["beta"],
			            "ricker"    =log(SPR*sr.param["alpha"])/sr.param["beta"],
			            "qhstk"     =if (SPR < 1/sr.param["beta"]) 0.0 else SPR*sr.param["alpha"]*sr.param["beta"],
			            "shepherd"  =pow((SPR-sr.param["alpha"])/sr.param["beta"], 1/(sr.param[3]+1)),
			            cat("type must be 'mean', 'bevholt', 'ricker' 'shepherd' or 'qhstk'!\n"))

   return(as.numeric(res))
   }    # }}}
