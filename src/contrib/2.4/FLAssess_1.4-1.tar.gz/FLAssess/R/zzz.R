# zzz - «Short one line description»

# Author: Iago Mosqueira, AZTI Tecnalia
# Maintainer: FLR Team 
# Additions:
# Last Change: 26 oct 2006 17:02
# $Id: zzz.R,v 1.1 2006/10/29 23:10:53 iagoazti Exp $

# Reference:
# Notes:

# TODO jue 26 oct 2006 17:02:19 CEST iagoazti:

.onLoad <- function(lib,pkg) {
	require(methods)
}
