FLFleet
=======

The FLFleet package for modelling of fishing fleet dynamics