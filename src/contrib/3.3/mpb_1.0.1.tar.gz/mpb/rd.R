#' @title control<- 
#' 
#' @description 
#' 
#' @name 
#' @param 
#' 
#' @aliases
#' 
#' @docType method
#' 
#' @rdname 
#' @seealso 
#' 
#' @examples
#' \dontrun{
#' }

#' @title eql
#' 
#' @description 
#' 

#' @title feasible 
#' 
#' @description 
#' 

#' @title fwd
#' 
#' @description 
#' 

#' @title hcr
#' 
#' @description 
#' 

#' @title nll 
#' 
#' @description 
#' 

#' @title oem 
#' 
#' @description 
#' 

#' @title plotEql
#' 
#' @description 
#' 

#' @title plotHcr 
#' 
#' @description 
#' 

#' @title plotProduction 
#' 
#' @description 
#' 

#' @title refptSD
#' 
#' @description 
#' 

#' @title resample 
#' 
#' @description 
#' 

#' @title setControl<- 
#' 
#' @description 
#' 

#' @title sim
#' 
#' @description 
#' 

#' @title xval
#' 
#' @description 
#' 
