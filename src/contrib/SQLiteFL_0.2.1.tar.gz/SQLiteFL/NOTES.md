# Improving SQLite performance

- <http://stackoverflow.com/questions/784173/what-are-the-performance-characteristics-of-sqlite-with-very-large-database-file?>

- <http://web.utk.edu/~jplyon/sqlite/SQLite_optimization_FAQ.html#pragmas>

- <http://stackoverflow.com/questions/1711631/how-do-i-improve-insert-per-second-performance-of-sqlite?rq=1>

# Move to C++/RCpp

- <https://srombauts.github.io/SQLiteCpp/>
